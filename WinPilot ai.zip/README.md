# WinPilot — AI Agent for Windows

A Tkinter desktop app that controls your Windows PC through natural-language
chat. Chat on the left, live tool activity on the right. The agent runs on a
background thread, so the window never freezes.

**v0.8** adds three integration layers on top of the v0.5 plugin system:
- **MCP** — connect to Model Context Protocol servers; their tools appear
  automatically (v0.6)
- **Voice** — speak to WinPilot, have it read answers aloud (v0.7)
- **Local models** — manage Ollama models from the GUI (v0.8)

## Quick start

```bat
setup.bat
```

Or manually:

```
python -m pip install -r requirements.txt
python -m winpilot.selftest
python winpilot_gui.py
```

First launch opens Settings: pick a backend, paste an API key. Config is saved
to `%USERPROFILE%\.winpilot\config.json`.

## What it can do

| Capability ↕▾ | How ↕▾ |
|---|---|
| −Chat with an LLM | Type in the box, press Enter |
| −File operations | "organize my Downloads folder by file type" |
| −Shell commands | "what is my IP address?" (asks first) |
| −Scheduled tasks | "run backup.py every day at 9am" |
| −Web search | "search for the latest Python version" |
| −Document Q&A | Click **Index folder**, then **Ask docs** |
| −Plugins | Drop a file in `~/.winpilot/plugins/`, click **Reload plugins** |
| −MCP tools | Add a server to `~/.winpilot/mcp_servers.json`, click **Reload MCP** |
| −Voice | Click the mic button, or enable "Speak responses" |
| −Local models | Click **Models** to pull/list/delete Ollama models |
⚙

## Supported LLM backends

All OpenAI-compatible. Switch in Settings.

| Name ↕▾ | Default model ↕▾ |
|---|---|
| −deepseek | `deepseek-chat` |
| −gemini | `gemini-2.0-flash` |
| −qwen | `qwen-plus` |
| −zai | `glm-4-plus` |
| −ollama | `qwen2.5:7b` |
⚙

## Safety model

1. **Workspace root** — every filesystem tool is confined to this folder
(default: your home). Paths outside are rejected. Change in Settings.
2. **Confirmations** — delete, shell, move, write, and scheduled tasks ask
first via a native dialog.
3. **Plugins are safe-only** — a plugin can only do what a built-in tool can.
See `PLUGIN_GUIDE.md`.
4. **MCP servers are explicit** — you list them in a config file. Their tools
go through the same confirmation gates as built-in tools. A server is
never auto-discovered from the network.
5. **Voice models run locally** — no audio leaves your machine unless you
configure a cloud STT/TTS endpoint.

## Files

```
winpilot_gui.py          Entry point (25 lines)
setup.bat                Windows installer
requirements.txt
README.md                This file
DEVELOPER_GUIDE.md       How the code is organised; how to edit it
PLUGIN_GUIDE.md          How to write a plugin
INTEGRATION_GUIDE.md     How to add an MCP server, voice, or local model
MCP_SETUP.md             Copy-paste MCP server configs
FIXES.md                 v0.1 → v0.2 changelog
DEBUG_REPORT.md          v0.2 static trace
CHANGELOG.md             All versions
winpilot/
  config.py              Settings + backend defaults
  paths.py               Workspace-root safety
  llm.py                 OpenAI-compatible client
  tools.py               Built-in tools
  plugins.py             Plugin loader + sandbox
  mcp_client.py          MCP connection + tool discovery
  mcp_registry.py        MCP server config load/save
  voice.py               STT/TTS engine
  local_models.py        Ollama model management
  rag.py                 Persistent document index
  agent.py               The ReAct loop
  gui.py                 Tkinter app
  ui_theme.py            Colours and fonts
  widgets.py             Small reusable widgets
  selftest.py            Run this before committing
plugins_examples/        Ready-to-copy example plugins
mcp_examples/            Ready-to-copy MCP server configs
```

## Testing

```
python -m winpilot.selftest        REM full smoke test (~120 checks)
python winpilot_gui.py --fake-llm  REM run the GUI without an API key
```

## Notes

- Tool calls do not stream tokens; the **tool log** streams live.
- Ollama must be running before selecting it.
- MCP servers must be reachable (or startable) before clicking Reload MCP.
- Voice requires `faster-whisper` (STT) and `piper-tts` (TTS) — both pip-
installable and CPU-friendly.

