# v0.1 → v0.2 Fixes

Every bug from the CLI review is addressed below.

| # | Severity | File | Issue | Status |
|---|----------|------|-------|--------|
| 1 | High | llm.py | `stream` param ignored | Fixed — removed |
| 2 | High | config.py | Fabricated model IDs | Fixed — real IDs |
| 3 | Low | tools.py | Unused import | Fixed |
| 4 | High | tools.py | `_within_root` never enforced | Fixed — `paths.py` |
| 5 | High | agent.py | Unbounded history | Fixed — rolling window |
| 6 | High | rag.py | Chunker can loop | Fixed — hard-split |
| 7 | Med | rag.py | IDF computed per chunk | Fixed — per document |
| 8 | Med | rag.py | Silent skips | Fixed — counted |
| 9 | High | tools.py | `schtasks` not quoted | Fixed |
| 10 | High | config.py | API key plaintext | Mitigated — icacls |
| 11 | Med | ui.py | Console mode clobbered | N/A — GUI |
| 12 | Med | agent.py | Silent truncation | Fixed — marker |
| 13 | Med | winpilot.py | `--backend` kept old model | Fixed |
| 14 | Low | winpilot.py | Dispatch style | N/A — GUI |
| 15 | Low | agent.py | Loop style | Fixed |
