"""
Plugin loader and sandbox.

A plugin is a Python file (or folder with plugin.json + code.py) that defines
one class inheriting PluginBase, with methods decorated by @tool.

DESIGN GOALS
  - Plugins are SAFE: they can only do what a built-in tool can do.
  - One bad plugin never breaks the app.
  - Reloading is a fresh reload, no stale state.

HOW IT WORKS
  1. load_plugins() scans ~/.winpilot/plugins/.
  2. For each file/folder it reads the source and compiles it.
  3. Before exec, the module namespace is pre-seeded with a restricted
     __builtins__ and a safe __import__.
  4. After exec, the PluginBase subclass is instantiated and its @tool
     methods are registered.

The sandbox is a guardrail, not a bulletproof jail. It stops accidental and
casual misuse, matching the "safe only" design decision.
"""

from __future__ import annotations

import builtins
import json
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from .config import PLUGIN_DIR, Config, ensure_plugin_dir
from .paths import safe_relative

# ---------------------------------------------------------------------------
# What plugins are allowed to do
# ---------------------------------------------------------------------------

ALLOWED_IMPORTS: frozenset[str] = frozenset({
    "json", "re", "math", "datetime", "collections", "itertools",
    "functools", "textwrap", "uuid", "hashlib", "base64", "csv",
    "io", "typing", "dataclasses", "enum", "random", "string",
    "statistics", "decimal", "fractions", "operator", "copy",
    "heapq", "bisect", "array", "struct", "binascii", "unicodedata",
})

FORBIDDEN_IMPORTS: dict[str, str] = {
    "os": "use self.workspace and the file helpers instead",
    "sys": "system access is blocked",
    "subprocess": "use self.run_powershell() if you truly need a command",
    "socket": "network access is blocked",
    "shutil": "use the file helpers",
    "pathlib": "use self.workspace (already a Path)",
    "ctypes": "native calls are blocked; use self.run_powershell()",
    "winreg": "registry access is blocked",
    "multiprocessing": "process spawning is blocked",
    "threading": "threads are blocked",
    "requests": "network access is blocked",
    "urllib": "network access is blocked",
    "http": "network access is blocked",
    "ftplib": "network access is blocked",
    "telnetlib": "network access is blocked",
    "smtplib": "network access is blocked",
    "pickle": "unsafe deserialisation; use json",
    "marshal": "unsafe deserialisation; use json",
    "importlib": "dynamic imports are blocked",
    "builtins": "direct builtins access is blocked",
    "gc": "interpreter internals are blocked",
    "inspect": "interpreter internals are blocked",
}

class PluginSecurityError(RuntimeError):
    """Raised when a plugin tries something the sandbox forbids."""

class PluginLoadError(RuntimeError):
    """Raised when a plugin file cannot be loaded."""

# ---------------------------------------------------------------------------
# The sandbox
# ---------------------------------------------------------------------------

class PluginSandbox:
    """Restricted builtins and file helpers for one plugin."""

    def __init__(self, workspace: Path, config: Config,
                 logger: Optional[Callable[[str], None]] = None):
        self.workspace = workspace
        self.config = config
        self._log = logger or (lambda msg: None)
        self._imported: set[str] = set()

    # -- import hook -------------------------------------------------------

    def safe_import(self, name: str, globals_=None, locals_=None,
                    fromlist=(), level=0):
        """Replacement for __import__. Allows only ALLOWED_IMPORTS."""
        root = name.split(".")[0]

        if root in FORBIDDEN_IMPORTS:
            raise PluginSecurityError(
                f"Import of '{root}' is not allowed: {FORBIDDEN_IMPORTS[root]}"
            )
        if root not in ALLOWED_IMPORTS:
            raise PluginSecurityError(
                f"Import of '{root}' is not allowed. "
                f"Allowed modules: {', '.join(sorted(ALLOWED_IMPORTS))}"
            )

        self._imported.add(root)
        return builtins.__import__(name, globals_, locals_, fromlist, level)

    # -- file helpers ------------------------------------------------------

    def read_text(self, relative_path: str) -> str:
        p = safe_relative(self.workspace, relative_path)
        if not p.exists():
            raise FileNotFoundError(f"Not found: {relative_path}")
        return p.read_text(encoding="utf-8", errors="replace")

    def write_text(self, relative_path: str, content: str) -> None:
        p = safe_relative(self.workspace, relative_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")

    def exists(self, relative_path: str) -> bool:
        return safe_relative(self.workspace, relative_path).exists()

    def list_files(self, relative_dir: str = ".") -> list[Path]:
        d = safe_relative(self.workspace, relative_dir)
        if not d.is_dir():
            return []
        return sorted(p for p in d.iterdir())

    def delete_file(self, relative_path: str) -> None:
        from .tools import _confirm
        p = safe_relative(self.workspace, relative_path)
        if not p.exists():
            raise FileNotFoundError(f"Not found: {relative_path}")
        _confirm("Delete file (plugin)",
                 f"A plugin wants to delete:\n{p}", self.config)
        if p.is_dir():
            import shutil as _shutil
            _shutil.rmtree(p)
        else:
            p.unlink()

    def run_powershell(self, script: str, timeout: int = 10) -> str:
        """
        Run a PowerShell snippet.

        This is the ONLY way a plugin reaches the OS. It goes through the
        same confirmation gate as the built-in run_command tool.
        """
        import subprocess
        from .tools import _confirm

        _confirm("Run PowerShell (plugin)",
                 f"A plugin wants to run:\n\n{script}", self.config)

        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            proc = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
                capture_output=True, text=True, timeout=timeout,
                creationflags=creationflags,
            )
        except subprocess.TimeoutExpired:
            return f"Error: PowerShell timed out after {timeout}s"
        except Exception as e:
            return f"Error running PowerShell: {e}"

        out = (proc.stdout or "").strip()
        err = (proc.stderr or "").strip()
        if proc.returncode != 0:
            return f"Error (exit {proc.returncode}): {err or out}"
        return out

    # -- build the namespace ----------------------------------------------

    def make_builtins(self) -> dict:
        """Return a __builtins__ dict for the plugin's module namespace."""
        safe: dict[str, Any] = {}
        allowed_builtin_names = (
            "abs", "all", "any", "ascii", "bin", "bool", "bytearray",
            "bytes", "callable", "chr", "classmethod", "complex", "dict",
            "divmod", "enumerate", "filter", "float", "format", "frozenset",
            "getattr", "hasattr", "hash", "hex", "id", "int", "isinstance",
            "issubclass", "iter", "len", "list", "map", "max", "min",
            "next", "object", "oct", "ord", "pow", "print", "property",
            "range", "repr", "reversed", "round", "set", "setattr", "slice",
            "sorted", "staticmethod", "str", "sum", "super", "tuple",
            "type", "vars", "zip", "True", "False", "None",
            "Exception", "ValueError", "TypeError", "KeyError",
            "IndexError", "RuntimeError", "StopIteration", "AttributeError",
            "NotImplementedError", "ZeroDivisionError", "FileNotFoundError",
            "ArithmeticError", "LookupError", "OSError",
        )
        for bname in allowed_builtin_names:
            if hasattr(builtins, bname):
                safe[bname] = getattr(builtins, bname)

        safe["__import__"] = self.safe_import
        safe["__build_class__"] = builtins.__build_class__
        safe["__name__"] = "winpilot_plugin"
        return safe

# ---------------------------------------------------------------------------
# Plugin base class and decorator
# ---------------------------------------------------------------------------

@dataclass
class ToolSpec:
    """Everything the loader needs to know about one @tool method."""

    plugin_name: str
    method_name: str
    full_name: str
    description: str
    parameters: dict
    required: list[str]
    destructive: bool
    func: Callable
    schema: dict

class PluginBase:
    """
    Base class for all plugins.

    Subclass it, set name/version/description, and decorate methods with
    @tool. The loader fills in `workspace`, `config`, and `_sandbox` before
    any tool runs.
    """

    name: str = ""
    version: str = "1.0.0"
    author: str = ""
    description: str = ""

    # Set by the loader:
    workspace: Path = Path(".")          # type: ignore[assignment]
    config: Optional[Config] = None
    _sandbox: Optional[PluginSandbox] = None
    _source: str = ""

    # -- helpers the plugin author calls ----------------------------------

    def log(self, message: str) -> None:
        """Write a line to the tool activity log."""
        if self._sandbox is not None:
            self._sandbox._log(f"[{self.name}] {message}")

    def read_text(self, relative_path: str) -> str:
        return self._require_sandbox().read_text(relative_path)

    def write_text(self, relative_path: str, content: str) -> None:
        self._require_sandbox().write_text(relative_path, content)

    def exists(self, relative_path: str) -> bool:
        return self._require_sandbox().exists(relative_path)

    def list_files(self, relative_dir: str = ".") -> list[Path]:
        return self._require_sandbox().list_files(relative_dir)

    def delete_file(self, relative_path: str) -> None:
        self._require_sandbox().delete_file(relative_path)

    def run_powershell(self, script: str, timeout: int = 10) -> str:
        return self._require_sandbox().run_powershell(script, timeout)

    # -- internal ----------------------------------------------------------

    def _require_sandbox(self) -> PluginSandbox:
        if self._sandbox is None:
            raise RuntimeError("Plugin was not initialised by the loader.")
        return self._sandbox

    # -- tool discovery ----------------------------------------------------

    @classmethod
    def collect_tools(cls, instance: "PluginBase") -> list[ToolSpec]:
        """Find every @tool-decorated method on the instance."""
        specs: list[ToolSpec] = []
        for attr_name in dir(instance):
            if attr_name.startswith("_"):
                continue
            method = getattr(instance, attr_name)
            meta = getattr(method, "__winpilot_tool__", None)
            if meta is None:
                continue

            full_name = f"{instance.name}__{attr_name}"
            schema = {
                "type": "function",
                "function": {
                    "name": full_name,
                    "description": meta["description"],
                    "parameters": {
                        "type": "object",
                        "properties": meta["parameters"],
                        "required": meta["required"],
                    },
                },
            }
            specs.append(ToolSpec(
                plugin_name=instance.name,
                method_name=attr_name,
                full_name=full_name,
                description=meta["description"],
                parameters=meta["parameters"],
                required=meta["required"],
                destructive=meta["destructive"],
                func=method,
                schema=schema,
            ))
        return specs

def tool(description: str,
         parameters: Optional[dict] = None,
         required: Optional[list[str]] = None,
         destructive: bool = False) -> Callable:
    """
    Decorator that marks a PluginBase method as a callable tool.

    Args:
        description: One sentence the LLM reads to decide when to call it.
        parameters: JSON-schema property dict.
        required: List of parameter names that must be supplied.
        destructive: If True, the user is asked to confirm before it runs.
    """
    def decorator(func: Callable) -> Callable:
        func.__winpilot_tool__ = {
            "description": description,
            "parameters": parameters or {},
            "required": required or [],
            "destructive": destructive,
        }
        return func
    return decorator

# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

@dataclass
class LoadedPlugin:
    name: str
    version: str
    source: str
    tools: list[ToolSpec] = field(default_factory=list)

_loaded_plugins: list[LoadedPlugin] = []
_plugin_tools: dict[str, ToolSpec] = {}
_load_errors: list[str] = []

def get_plugin_tools() -> dict[str, ToolSpec]:
    return dict(_plugin_tools)

def get_plugin_tool(full_name: str) -> Optional[Callable]:
    """Return a callable suitable for tools.execute_tool."""
    spec = _plugin_tools.get(full_name)
    if spec is None:
        return None

    def wrapper(**kwargs):
        cfg = kwargs.pop("cfg")
        if spec.destructive:
            from .tools import _confirm
            _confirm(f"Plugin: {spec.plugin_name}",
                     f"Run '{spec.full_name}'?\n\n{spec.description}", cfg)
        allowed = set(spec.parameters.keys())
        clean = {k: v for k, v in kwargs.items() if k in allowed}
        result = spec.func(**clean)
        return result if isinstance(result, str) else str(result)

    wrapper.__name__ = full_name
    return wrapper

def get_plugin_schemas() -> list[dict]:
    return [spec.schema for spec in _plugin_tools.values()]

def get_loaded_plugins() -> list[LoadedPlugin]:
    return list(_loaded_plugins)

def get_load_errors() -> list[str]:
    return list(_load_errors)

# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def load_plugins(cfg: Config,
                 logger: Optional[Callable[[str], None]] = None
                 ) -> list[LoadedPlugin]:
    """
    Scan the plugin directory and load everything valid.

    Safe to call repeatedly: each call starts from a clean registry.
    """
    _loaded_plugins.clear()
    _plugin_tools.clear()
    _load_errors.clear()

    log = logger or (lambda msg: None)

    if not cfg.plugins_enabled:
        log("Plugins are disabled in settings.")
        return []

    plugin_dir = ensure_plugin_dir()
    workspace = cfg.effective_workspace()

    try:
        entries = sorted(plugin_dir.iterdir())
    except OSError as e:
        log(f"Could not read plugin folder: {e}")
        return []

    for entry in entries:
        if entry.name.startswith("_") or entry.name.startswith("."):
            continue
        try:
            if entry.is_file() and entry.suffix == ".py":
                _load_single_file(entry, cfg, workspace, log)
            elif entry.is_dir():
                _load_folder(entry, cfg, workspace, log)
        except Exception as e:
            msg = f"{entry.name}: {type(e).__name__}: {e}"
            _load_errors.append(msg)
            log(f"Plugin failed: {msg}")

    if _loaded_plugins:
        names = ", ".join(p.name for p in _loaded_plugins)
        log(f"Loaded {len(_loaded_plugins)} plugin(s): {names}")
    else:
        log("No plugins loaded.")

    return list(_loaded_plugins)

def _load_single_file(path: Path, cfg: Config, workspace: Path,
                      log: Callable[[str], None]) -> None:
    source = path.read_text(encoding="utf-8")
    _execute_plugin_source(source, str(path), cfg, workspace, log)

def _load_folder(path: Path, cfg: Config, workspace: Path,
                 log: Callable[[str], None]) -> None:
    manifest_path = path / "plugin.json"
    if not manifest_path.exists():
        log(f"Skipping folder (no plugin.json): {path.name}")
        return

    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise PluginLoadError(f"plugin.json is not valid JSON: {e}") from e

    if not isinstance(manifest, dict):
        raise PluginLoadError("plugin.json must be a JSON object.")

    entry_name = manifest.get("entry", "code.py")
    code_path = path / entry_name
    if not code_path.exists():
        raise PluginLoadError(f"Entry file not found: {entry_name}")

    source = code_path.read_text(encoding="utf-8")
    _execute_plugin_source(source, str(code_path), cfg, workspace, log)

def _execute_plugin_source(source: str, source_label: str,
                           cfg: Config, workspace: Path,
                           log: Callable[[str], None]) -> None:
    """
    Compile and run a plugin's source in a sandboxed namespace, then
    register its tools.
    """
    sandbox = PluginSandbox(workspace, cfg, logger=log)

    namespace: dict[str, Any] = {
        "__builtins__": sandbox.make_builtins(),
        "__name__": "winpilot_plugin",
        "__file__": source_label,
        "PluginBase": PluginBase,
        "tool": tool,
    }

    try:
        code = compile(source, source_label, "exec")
    except SyntaxError as e:
        raise PluginLoadError(f"Syntax error on line {e.lineno}: {e.msg}") from e

    try:
        exec(code, namespace)
    except PluginSecurityError:
        raise
    except Exception as e:
        tb = traceback.format_exc(limit=2)
        raise PluginLoadError(f"{type(e).__name__}: {e}\n{tb}") from e

    plugin_classes = [
        obj for obj in namespace.values()
        if isinstance(obj, type)
        and issubclass(obj, PluginBase)
        and obj is not PluginBase
    ]
    if not plugin_classes:
        raise PluginLoadError(
            "No class inheriting PluginBase found. "
            "Did you `from winpilot.plugins import PluginBase`?"
        )
    if len(plugin_classes) > 1:
        names = ", ".join(c.__name__ for c in plugin_classes)
        raise PluginLoadError(
            f"Found {len(plugin_classes)} PluginBase subclasses "
            f"({names}). A plugin file must define exactly one."
        )

    plugin_cls = plugin_classes[0]

    if not plugin_cls.name or not isinstance(plugin_cls.name, str):
        raise PluginLoadError(
            f"{plugin_cls.__name__} must set a non-empty `name` attribute."
        )
    if not plugin_cls.name.isidentifier():
        raise PluginLoadError(
            f"Plugin name {plugin_cls.name!r} must be a valid identifier."
        )

    try:
        instance = plugin_cls()
    except Exception as e:
        raise PluginLoadError(f"Could not instantiate plugin: {e}") from e

    instance.workspace = workspace
    instance.config = cfg
    instance._sandbox = sandbox
    instance._source = source_label

    specs = PluginBase.collect_tools(instance)
    if not specs:
        raise PluginLoadError(
            f"{plugin_cls.__name__} has no @tool-decorated methods."
        )

    from .tools import BUILTIN_TOOLS
    for spec in specs:
        if spec.full_name in BUILTIN_TOOLS:
            raise PluginLoadError(
                f"Tool name {spec.full_name!r} clashes with a built-in tool. "
                f"Rename the plugin or the method."
            )
        if spec.full_name in _plugin_tools:
            raise PluginLoadError(
                f"Tool name {spec.full_name!r} is already registered by "
                f"another plugin."
            )
        _plugin_tools[spec.full_name] = spec

    _loaded_plugins.append(LoadedPlugin(
        name=plugin_cls.name,
        version=plugin_cls.version,
        source=source_label,
        tools=specs,
    ))
    log(f"Loaded plugin '{plugin_cls.name}' v{plugin_cls.version} "
        f"({len(specs)} tool(s)).")
