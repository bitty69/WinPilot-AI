"""
WinPilot — an AI agent for Windows with a Tkinter GUI.

Package layout (see DEVELOPER_GUIDE.md for the full tour):

    config.py        — settings and backend definitions
    paths.py         — workspace-root safety
    llm.py           — OpenAI-compatible API client
    tools.py         — built-in tools + provider dispatch
    plugins.py       — plugin loader and sandbox
    mcp_client.py    — MCP connection and tool discovery
    mcp_registry.py  — MCP server config
    voice.py         — STT / TTS engines
    local_models.py  — Ollama model management
    rag.py           — persistent document index for /ask
    agent.py         — the ReAct loop
    gui.py           — the Tkinter application
    ui_theme.py      — colours and fonts
    widgets.py       — small reusable widgets
    selftest.py      — smoke tests; run before committing
"""

__version__ = "0.8.0"
