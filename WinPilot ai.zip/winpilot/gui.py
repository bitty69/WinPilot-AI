"""
WinPilot GUI — Tkinter application.

Layout:
  ┌─────────────────────────────────────┬──────────────────┐
  │ Chat (scrollable)                   │ Tool activity    │
  ├─────────────────────────────────────┤                  │
  │ input + Send + Mic                  │ status footer    │
  │ toolbar: Index / Ask / Reload / ... │ Cancel button    │
  └─────────────────────────────────────┴──────────────────┘

The agent runs on a worker thread. All UI updates go through a queue polled
by the main thread, so no widget is ever touched from another thread.

TO EDIT THE GUI:
  - colours and fonts        → ui_theme.py
  - layout                   → _build_layout()
  - menu items               → _build_menu()
  - reactions to the agent   → _handle_event()
"""

import queue
import threading
import traceback
import webbrowser
from pathlib import Path
from tkinter import (
    BOTH, END, LEFT, RIGHT, VERTICAL, X, Y,
    BooleanVar, Frame, Label, Menu, Scrollbar, StringVar, Text,
    Tk, Toplevel, filedialog, messagebox,
)
from tkinter import ttk

from . import __version__
from .agent import (
    Agent, EVENT_ERROR, EVENT_FINAL, EVENT_THINKING,
    EVENT_TOOL_CALL, EVENT_TOOL_RESULT,
)
from .config import (
    BACKEND_DEFAULTS, PLUGIN_DIR, Config, backup_and_reset_config,
    ensure_plugin_dir, load_config, save_config,
)
from .ui_theme import (
    ACCENT, ACCENT_SOFT, BG, BORDER, ERR, FONT_MONO, FONT_TITLE,
    FONT_UI, FONT_UI_B, FONT_UI_SM, GAP, OK, PAD, TEXT, TEXT_MUTED, WARN,
)

WORKER_DONE = "__worker_done__"

class WinPilotApp(Tk):
    def __init__(self) -> None:
        super().__init__()

        self.title(f"WinPilot — AI Agent for Windows  v{__version__}")
        self.configure(bg=BG)
        self.minsize(1000, 600)

        self._events: "queue.Queue[tuple[str, dict]]" = queue.Queue()
        self._worker: threading.Thread | None = None
        self._worker_gen = 0
        self._busy = False
        self._recording_stop: threading.Event | None = None

        self.cfg: Config | None = None
        self.agent: Agent | None = None
        self._first_run = False

        if not self._bootstrap_config():
            self.destroy()
            return

        self._install_ttk_styles()
        self._build_menu()
        self._build_layout()
        self._bind_shortcuts()

        self.agent = self._make_agent()
        self._load_plugins_at_startup()
        self._load_mcp_at_startup()
        self._refresh_status()

        self._append_bot(
            "Hi! I'm WinPilot.\n\n"
            "Try:\n"
            "  • organize my Downloads folder by file type\n"
            "  • what is my IP address?\n"
            "  • save a note saying \"buy milk\"     (if the example plugin is loaded)\n\n"
            "Index folder → Ask docs, for document Q&A.\n"
            "Reload plugins / Reload MCP after editing config."
        )

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self._poll_events()

        if self._first_run:
            self.after(150, self._first_run_prompt)

    # ------------------------------------------------------------------
    # Bootstrap
    # ------------------------------------------------------------------

    def _bootstrap_config(self) -> bool:
        try:
            cfg = load_config()
        except Exception as e:
            if not messagebox.askyesno(
                    "Config problem",
                    f"The config file could not be read:\n\n{e}\n\n"
                    "Reset it to defaults? (A backup will be kept.)"):
                return False
            try:
                backup = backup_and_reset_config()
                messagebox.showinfo("Config reset", f"Backup saved to:\n{backup}")
            except Exception as be:
                messagebox.showerror("Reset failed", str(be))
                return False
            cfg = None

        if cfg is None:
            self.cfg = Config()
            self._first_run = True
        else:
            self.cfg = cfg
            self.geometry(cfg.window_geometry)
        return True

    def _first_run_prompt(self) -> None:
        self._open_settings(initial=True)
        self._refresh_status()

    # ------------------------------------------------------------------
    # Agent wiring
    # ------------------------------------------------------------------

    def _make_agent(self) -> Agent:
        from . import tools
        tools.confirm_callback = self._confirm_on_main_thread
        return Agent(self.cfg, event_cb=self._enqueue_event)

    def _enqueue_event(self, kind: str, data: dict) -> None:
        self._events.put((kind, data))

    def _confirm_on_main_thread(self, title: str, message: str) -> bool:
        """
        Called from a worker thread; blocks it until the user answers.
        The dialog is shown on the main thread via self.after.
        """
        done = threading.Event()
        box: dict[str, bool] = {"value": False}

        def show() -> None:
            try:
                box["value"] = messagebox.askyesno(title, message)
            finally:
                done.set()

        self.after(0, show)
        done.wait()
        return box["value"]

    # ------------------------------------------------------------------
    # Plugins
    # ------------------------------------------------------------------

    def _load_plugins_at_startup(self) -> None:
        if not self.cfg.plugins_enabled:
            self._log_line("Plugins are disabled in Settings.", "err")
            return
        self._reload_plugins(announce=False)

    def _reload_plugins(self, announce: bool = True) -> None:
        from . import plugins

        def logger(msg: str) -> None:
            self._log_line(msg, "preview")

        try:
            ensure_plugin_dir()
            loaded = plugins.load_plugins(self.cfg, logger=logger)
            errors = plugins.get_load_errors()
        except Exception as e:
            self._log_line(f"Plugin load failed: {e}", "err")
            return

        if announce:
            if loaded:
                self._append_note(
                    f"Reloaded {len(loaded)} plugin(s): "
                    + ", ".join(p.name for p in loaded)
                    + (f"  ({len(errors)} failed)" if errors else ""))
            else:
                self._append_note(
                    "No plugins loaded."
                    + (f"  ({len(errors)} failed — see the tool log)"
                       if errors else ""))
        self._refresh_status()

    def _open_plugin_folder(self) -> None:
        import os
        try:
            ensure_plugin_dir()
            if os.name == "nt":
                os.startfile(str(PLUGIN_DIR))  # type: ignore[attr-defined]
            else:
                webbrowser.open(f"file://{PLUGIN_DIR}")
        except Exception as e:
            messagebox.showerror("Could not open folder", str(e))

    def _list_plugins(self) -> None:
        from . import plugins
        loaded = plugins.get_loaded_plugins()
        errors = plugins.get_load_errors()

        if not loaded and not errors:
            self._append_bot(
                "No plugins loaded.\n\n"
                f"Drop a .py file into:\n{PLUGIN_DIR}\n\n"
                "then click Reload plugins.")
            return

        lines = []
        for p in loaded:
            tool_names = ", ".join(s.method_name for s in p.tools)
            lines.append(f"• {p.name} v{p.version} — "
                         f"{len(p.tools)} tool(s): {tool_names}")
        for e in errors:
            lines.append(f"✗ {e}")
        self._append_bot("Plugins:\n" + "\n".join(lines))

    # ------------------------------------------------------------------
    # MCP
    # ------------------------------------------------------------------

    def _load_mcp_at_startup(self) -> None:
        if not self.cfg.mcp_enabled:
            self._log_line("MCP is disabled in Settings.", "err")
            return
        self._reload_mcp(announce=False)

    def _reload_mcp(self, announce: bool = True) -> None:
        """
        Reconnect to every configured MCP server.

        Runs on a background thread because some servers take seconds to
        start (npx/uvx may download packages on first run).
        """
        if self._busy:
            self._append_note("Busy — try again in a moment.")
            return

        from . import mcp_client

        ok, reason = mcp_client.is_available()
        if not ok:
            self._log_line(reason, "err")
            if announce:
                self._append_note(reason)
            return

        self._set_busy(True)
        self._append_note("Connecting to MCP servers...")

        def logger(msg: str) -> None:
            self._log_line(msg, "preview")

        def job():
            try:
                conns = mcp_client.load_mcp(self.cfg, logger=logger)
            except Exception as e:
                self._enqueue_event(EVENT_ERROR,
                                    {"text": f"MCP load failed: {e}"})
                self._events.put((WORKER_DONE, {}))
                return

            connected = [c for c in conns if c.connected]
            failed = [c for c in conns if not c.connected]

            if announce:
                if connected:
                    lines = [f"Connected to {len(connected)} MCP server(s):"]
                    for c in connected:
                        lines.append(f"  • {c.config.name} ({len(c.tools)} tools)")
                    if failed:
                        lines.append(f"Failed: {len(failed)}")
                    self._enqueue_event(EVENT_FINAL,
                                        {"text": "\n".join(lines)})
                else:
                    self._enqueue_event(
                        EVENT_FINAL,
                        {"text": "No MCP servers connected. "
                                 "Check the tool log for details."})
            else:
                self._events.put((EVENT_TOOL_RESULT,
                                  {"name": "mcp-reload",
                                   "ok": bool(connected),
                                   "preview": f"{len(connected)} connected, "
                                              f"{len(failed)} failed"}))

            self._events.put((WORKER_DONE, {}))

        self._worker = threading.Thread(target=job, name="winpilot-mcp",
                                        daemon=True)
        self._worker.start()

    def _open_mcp_config(self) -> None:
        from . import mcp_registry
        import os
        try:
            path = mcp_registry.ensure_mcp_config()
            if os.name == "nt":
                os.startfile(str(path.parent))  # type: ignore[attr-defined]
            else:
                webbrowser.open(f"file://{path.parent}")
            self._append_note(f"MCP config: {path}")
        except Exception as e:
            messagebox.showerror("Could not open MCP config", str(e))

    def _list_mcp(self) -> None:
        from . import mcp_client, mcp_registry

        ok, reason = mcp_client.is_available()
        if not ok:
            self._append_bot(reason)
            return

        try:
            servers = mcp_registry.load_servers()
        except ValueError as e:
            self._append_bot(f"MCP config error:\n{e}")
            return

        conns = {c.config.name: c for c in mcp_client.get_connections()}

        if not servers:
            self._append_bot(
                "No MCP servers configured.\n\n"
                "Click 'Open MCP config' to add some. "
                "See MCP_SETUP.md for copy-paste examples.")
            return

        lines = []
        for s in servers:
            conn = conns.get(s.name)
            if conn is None:
                status = "not connected"
            elif conn.connected:
                status = f"connected ({len(conn.tools)} tools)"
            else:
                status = f"failed: {conn.error}"
            flag = "" if s.enabled else " [disabled]"
            lines.append(f"• {s.name}{flag}: {status}")
        self._append_bot("MCP servers:\n" + "\n".join(lines))

    # ------------------------------------------------------------------
    # Voice
    # ------------------------------------------------------------------

    def _toggle_recording(self) -> None:
        """Start or stop a push-to-talk recording."""
        if self._recording_stop is not None:
            self._recording_stop.set()
            self._recording_stop = None
            self.mic_btn.configure(text="🎤")
            return

        from . import voice
        ok, reason = voice.STT_ENGINES[self.cfg.voice_stt_engine].is_available() \
            if self.cfg.voice_stt_engine in voice.STT_ENGINES else (False, "")

        if not ok:
            self._append_note(f"Voice input unavailable. {reason}")
            return

        self._recording_stop = threading.Event()
        self.mic_btn.configure(text="⏹")

        def job():
            try:
                path = voice.record_to_wav(
                    duration=15.0,
                    stop_event=self._recording_stop,
                )
                self._events.put((EVENT_TOOL_RESULT,
                                  {"name": "record",
                                   "ok": True,
                                   "preview": f"Recorded to {path.name}"}))
                self._enqueue_event("__transcribe__", {"path": str(path)})
            except Exception as e:
                self._enqueue_event(EVENT_ERROR,
                                    {"text": f"Recording failed: {e}"})
            finally:
                self._events.put((WORKER_DONE, {}))

        self._set_busy(True)
        self._worker = threading.Thread(target=job, name="winpilot-record",
                                        daemon=True)
        self._worker.start()

    def _handle_transcribe(self, path: str) -> None:
        """Transcribe a recorded WAV and put the text in the input box."""
        from . import voice

        engine = voice.VoiceEngine(voice.VoiceConfig(
            stt_engine=self.cfg.voice_stt_engine,
            stt_model=self.cfg.voice_stt_model,
            tts_engine=self.cfg.voice_tts_engine,
            tts_voice=self.cfg.voice_tts_voice,
        ))

        text = engine.transcribe_file(Path(path))
        self.mic_btn.configure(text="🎤")
        if text.startswith("Error"):
            self._append_note(text)
            return
        self.entry.delete("1.0", END)
        self.entry.insert("1.0", text)
        self.entry.focus_set()
        self._append_note(f"(transcribed) {text[:120]}")

    def _speak_text(self, text: str) -> None:
        """Speak text on a worker thread. Fire-and-forget."""
        if not self.cfg.voice_speak_responses or not text.strip():
            return

        from . import voice

        def job():
            engine = voice.VoiceEngine(voice.VoiceConfig(
                stt_engine=self.cfg.voice_stt_engine,
                stt_model=self.cfg.voice_stt_model,
                tts_engine=self.cfg.voice_tts_engine,
                tts_voice=self.cfg.voice_tts_voice,
            ))
            err = engine.speak(text[:1000])
            if err:
                self._log_line(err, "err")

        threading.Thread(target=job, name="winpilot-speak",
                         daemon=True).start()

    # ------------------------------------------------------------------
    # Local models
    # ------------------------------------------------------------------

    def _open_models(self) -> None:
        _ModelsDialog(self, self.cfg)

    # ------------------------------------------------------------------
    # Styles
    # ------------------------------------------------------------------

    def _install_ttk_styles(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("Primary.TButton", padding=(12, 6),
                        background=ACCENT, foreground="#ffffff",
                        borderwidth=0, focusthickness=0)
        style.map("Primary.TButton",
                  background=[("active", ACCENT), ("disabled", "#9db8f0")],
                  foreground=[("disabled", "#f0f4ff")])
        style.configure("Secondary.TButton", padding=(10, 5),
                        background="#ffffff", foreground=TEXT,
                        borderwidth=1, relief="solid")
        style.map("Secondary.TButton",
                  background=[("active", ACCENT_SOFT), ("disabled", "#f2f2f2")])
        style.configure("TCheckbutton", background=BG, foreground=TEXT)
        style.configure("TLabel", background=BG, foreground=TEXT)
        style.configure("TEntry", fieldbackground="#ffffff")

    # ------------------------------------------------------------------
    # Menu
    # ------------------------------------------------------------------

    def _build_menu(self) -> None:
        menubar = Menu(self)

        m_file = Menu(menubar, tearoff=0)
        m_file.add_command(label="Settings…", accelerator="Ctrl+,",
                           command=self._open_settings)
        m_file.add_command(label="Open config folder",
                           command=self._open_config_folder)
        m_file.add_separator()
        m_file.add_command(label="Exit", command=self._on_close)
        menubar.add_cascade(label="File", menu=m_file)

        m_chat = Menu(menubar, tearoff=0)
        m_chat.add_command(label="Clear conversation", command=self._clear_chat)
        m_chat.add_command(label="Cancel current task", command=self._cancel_task)
        menubar.add_cascade(label="Chat", menu=m_chat)

        m_rag = Menu(menubar, tearoff=0)
        m_rag.add_command(label="Index folder…", command=self._index_folder)
        m_rag.add_command(label="Index file…", command=self._index_file)
        m_rag.add_command(label="Ask about indexed docs…", command=self._ask_docs)
        m_rag.add_separator()
        m_rag.add_command(label="Clear index", command=self._clear_index)
        menubar.add_cascade(label="Documents", menu=m_rag)

        m_plugins = Menu(menubar, tearoff=0)
        m_plugins.add_command(
            label="Reload plugins",
            command=lambda: self._reload_plugins(announce=True))
        m_plugins.add_command(label="List loaded plugins",
                              command=self._list_plugins)
        m_plugins.add_command(label="Open plugins folder",
                              command=self._open_plugin_folder)
        menubar.add_cascade(label="Plugins", menu=m_plugins)

        m_mcp = Menu(menubar, tearoff=0)
        m_mcp.add_command(label="Reload MCP servers",
                          command=lambda: self._reload_mcp(announce=True))
        m_mcp.add_command(label="List MCP servers", command=self._list_mcp)
        m_mcp.add_command(label="Open MCP config", command=self._open_mcp_config)
        menubar.add_cascade(label="MCP", menu=m_mcp)

        m_models = Menu(menubar, tearoff=0)
        m_models.add_command(label="Manage local models…",
                             command=self._open_models)
        menubar.add_cascade(label="Models", menu=m_models)

        m_help = Menu(menubar, tearoff=0)
        m_help.add_command(label="About", command=self._about)
        menubar.add_cascade(label="Help", menu=m_help)

        self.config(menu=menubar)

    # ------------------------------------------------------------------
    # Layout
    # ------------------------------------------------------------------

    def _build_layout(self) -> None:
        outer = Frame(self, bg=BG)
        outer.pack(fill=BOTH, expand=True, padx=PAD, pady=PAD)

        # ---- left: chat ----
        left = Frame(outer, bg=BG)
        left.pack(side=LEFT, fill=BOTH, expand=True)

        chat_card = Frame(left, bg=BORDER, highlightthickness=1,
                          highlightbackground=BORDER)
        chat_card.pack(fill=BOTH, expand=True)

        self.chat = Text(chat_card, wrap="word", bg=BG, fg=TEXT, bd=0,
                         font=FONT_UI, padx=14, pady=12, state="disabled",
                         cursor="arrow", spacing1=2, spacing3=6)
        chat_scroll = Scrollbar(chat_card, orient=VERTICAL,
                                command=self.chat.yview)
        self.chat.configure(yscrollcommand=chat_scroll.set)
        chat_scroll.pack(side=RIGHT, fill=Y)
        self.chat.pack(side=LEFT, fill=BOTH, expand=True)

        self.chat.tag_configure("user_label", foreground=ACCENT,
                                font=FONT_UI_B, spacing1=8)
        self.chat.tag_configure("bot_label", foreground=TEXT,
                                font=FONT_UI_B, spacing1=8)
        self.chat.tag_configure("body", foreground=TEXT, font=FONT_UI,
                                rmargin=6)
        self.chat.tag_configure("muted", foreground=TEXT_MUTED,
                                font=FONT_UI_SM)

        input_row = Frame(left, bg=BG)
        input_row.pack(fill=X, pady=(GAP, 0))

        entry_border = Frame(input_row, bg=BORDER, highlightthickness=1,
                             highlightbackground=BORDER)
        entry_border.pack(side=LEFT, fill=X, expand=True)
        self.entry = Text(entry_border, height=3, wrap="word", bd=0,
                          bg="#ffffff", fg=TEXT, font=FONT_UI,
                          padx=10, pady=8, insertbackground=ACCENT)
        self.entry.pack(fill=BOTH, expand=True)
        self.entry.bind("<Return>", self._on_entry_return)
        self.entry.bind("<Escape>", self._on_entry_escape)
        self.entry.focus_set()

        self.mic_btn = ttk.Button(input_row, text="🎤", width=3,
                                  command=self._toggle_recording,
                                  style="Secondary.TButton")
        self.mic_btn.pack(side=LEFT, padx=(GAP, 0), anchor="n")

        self.send_btn = ttk.Button(input_row, text="Send", width=8,
                                   command=self._on_send,
                                   style="Primary.TButton")
        self.send_btn.pack(side=LEFT, padx=(6, 0), anchor="n")

        # toolbar (two rows so it fits)
        bar = Frame(left, bg=BG)
        bar.pack(fill=X, pady=(GAP, 0))
        ttk.Button(bar, text="Index folder", command=self._index_folder,
                   style="Secondary.TButton").pack(side=LEFT)
        ttk.Button(bar, text="Ask docs", command=self._ask_docs,
                   style="Secondary.TButton").pack(side=LEFT, padx=(6, 0))
        ttk.Button(bar, text="Reload plugins",
                   command=lambda: self._reload_plugins(announce=True),
                   style="Secondary.TButton").pack(side=LEFT, padx=(6, 0))
        ttk.Button(bar, text="Reload MCP",
                   command=lambda: self._reload_mcp(announce=True),
                   style="Secondary.TButton").pack(side=LEFT, padx=(6, 0))
        ttk.Button(bar, text="Models", command=self._open_models,
                   style="Secondary.TButton").pack(side=LEFT, padx=(6, 0))
        ttk.Button(bar, text="Settings", command=self._open_settings,
                   style="Secondary.TButton").pack(side=RIGHT)

        # ---- right: tool log ----
        right = Frame(outer, bg=BG, width=380)
        right.pack(side=RIGHT, fill=Y, padx=(PAD, 0))
        right.pack_propagate(False)

        log_card = Frame(right, bg=BORDER, highlightthickness=1,
                         highlightbackground=BORDER)
        log_card.pack(fill=BOTH, expand=True)

        log_header = Frame(log_card, bg="#ffffff")
        log_header.pack(fill=X)
        Label(log_header, text="Tool activity", bg="#ffffff", fg=TEXT,
              font=FONT_TITLE, padx=12, pady=10).pack(side=LEFT)

        self.log = Text(log_card, wrap="word", bg="#ffffff", fg=TEXT, bd=0,
                        font=FONT_MONO, padx=12, pady=8, state="disabled",
                        cursor="arrow")
        log_scroll = Scrollbar(log_card, orient=VERTICAL,
                               command=self.log.yview)
        self.log.configure(yscrollcommand=log_scroll.set)
        log_scroll.pack(side=RIGHT, fill=Y)
        self.log.pack(side=LEFT, fill=BOTH, expand=True)

        self.log.tag_configure("call", foreground=ACCENT, font=FONT_MONO)
        self.log.tag_configure("ok", foreground=OK, font=FONT_MONO)
        self.log.tag_configure("err", foreground=ERR, font=FONT_MONO)
        self.log.tag_configure("warn", foreground=WARN, font=FONT_MONO)
        self.log.tag_configure("preview", foreground=TEXT, font=FONT_MONO)

        footer = Frame(right, bg=BG)
        footer.pack(fill=X, pady=(GAP, 0))
        self.status_var = StringVar(value="")
        Label(footer, textvariable=self.status_var, bg=BG, fg=TEXT_MUTED,
              font=FONT_UI_SM, justify="left", anchor="w").pack(fill=X)

        self.cancel_btn = ttk.Button(footer, text="Cancel task",
                                     command=self._cancel_task,
                                     style="Secondary.TButton")
        self.cancel_btn.pack(fill=X, pady=(6, 0))
        self.cancel_btn.state(["disabled"])

    def _bind_shortcuts(self) -> None:
        self.bind_all("<Control-Return>", self._shortcut_send)
        self.bind_all("<Control-comma>", self._shortcut_settings)
        self.bind_all("<Control-l>", self._shortcut_clear)
        self.bind_all("<Control-r>", self._shortcut_reload_plugins)
        self.bind_all("<Control-m>", self._shortcut_reload_mcp)
        self.bind_all("<Control-space>", self._shortcut_mic)

    def _shortcut_send(self, _e):
        self._on_send()
        return "break"

    def _shortcut_settings(self, _e):
        self._open_settings()
        return "break"

    def _shortcut_clear(self, _e):
        self._clear_chat()
        return "break"

    def _shortcut_reload_plugins(self, _e):
        self._reload_plugins(announce=True)
        return "break"

    def _shortcut_reload_mcp(self, _e):
        self._reload_mcp(announce=True)
        return "break"

    def _shortcut_mic(self, _e):
        self._toggle_recording()
        return "break"

    # ------------------------------------------------------------------
    # Chat helpers
    # ------------------------------------------------------------------

    def _append_user(self, text: str) -> None:
        self.chat.configure(state="normal")
        self.chat.insert(END, "You\n", "user_label")
        self.chat.insert(END, text + "\n", "body")
        self.chat.configure(state="disabled")
        self.chat.see(END)

    def _append_bot(self, text: str) -> None:
        self.chat.configure(state="normal")
        self.chat.insert(END, "WinPilot\n", "bot_label")
        self.chat.insert(END, text + "\n", "body")
        self.chat.configure(state="disabled")
        self.chat.see(END)

    def _append_note(self, text: str) -> None:
        self.chat.configure(state="normal")
        self.chat.insert(END, text + "\n", "muted")
        self.chat.configure(state="disabled")
        self.chat.see(END)

    # ------------------------------------------------------------------
    # Tool log
    # ------------------------------------------------------------------

    def _log_line(self, text: str, tag: str = "preview") -> None:
        self.log.configure(state="normal")
        self.log.insert(END, text + "\n", tag)
        self.log.configure(state="disabled")
        self.log.see(END)

    def _log_tool_call(self, name: str, args: dict) -> None:
        arg_str = ", ".join(f"{k}={self._short(v)}" for k, v in args.items())
        self._log_line(f"→ {name}({arg_str})", "call")

    def _log_tool_result(self, name: str, ok: bool, preview: str) -> None:
        mark = "✓" if ok else "✗"
        tag = "ok" if ok else "err"
        first = preview.strip().splitlines()[0] if preview.strip() else "(no output)"
        self._log_line(f"  {mark} {self._short(first, 100)}", tag)

    @staticmethod
    def _short(value, limit: int = 60) -> str:
        s = str(value).replace("\n", " ")
        return s if len(s) <= limit else s[: limit - 1] + "…"

    # ------------------------------------------------------------------
    # Status footer
    # ------------------------------------------------------------------

    def _refresh_status(self) -> None:
        if self.cfg is None:
            return
        label = BACKEND_DEFAULTS.get(self.cfg.backend, {}).get(
            "label", self.cfg.backend)

        if self.agent is not None:
            try:
                idx = self.agent.rag.index.stats()
            except Exception:
                idx = "(unavailable)"
        else:
            idx = "(not initialised)"

        try:
            from . import plugins
            n_plugins = len(plugins.get_loaded_plugins())
            n_ptools = len(plugins.get_plugin_tools())
        except Exception:
            n_plugins, n_ptools = 0, 0

        try:
            from . import mcp_client
            conns = mcp_client.get_connections()
            n_mcp = sum(1 for c in conns if c.connected)
            n_mtools = sum(len(c.tools) for c in conns if c.connected)
        except Exception:
            n_mcp, n_mtools = 0, 0

        self.status_var.set("\n".join([
            f"Backend: {label}",
            f"Model:   {self.cfg.model}",
            f"Root:    {self.cfg.effective_workspace()}",
            f"Index:   {idx}",
            f"Plugins: {n_plugins} ({n_ptools} tools)",
            f"MCP:     {n_mcp} server(s) ({n_mtools} tools)",
        ]))

    # ------------------------------------------------------------------
    # Event pump
    # ------------------------------------------------------------------

    def _poll_events(self) -> None:
        try:
            while True:
                kind, data = self._events.get_nowait()
                if kind == WORKER_DONE:
                    self._set_busy(False)
                    continue
                if kind == "__transcribe__":
                    self._handle_transcribe(data.get("path", ""))
                    continue
                self._handle_event(kind, data)
        except queue.Empty:
            pass
        finally:
            self.after(60, self._poll_events)

    def _handle_event(self, kind: str, data: dict) -> None:
        if kind == EVENT_THINKING:
            self._set_busy(True)
        elif kind == EVENT_TOOL_CALL:
            self._log_tool_call(data.get("name", "?"), data.get("args", {}))
        elif kind == EVENT_TOOL_RESULT:
            self._log_tool_result(data.get("name", "?"),
                                  bool(data.get("ok")),
                                  str(data.get("preview", "")))
        elif kind == EVENT_FINAL:
            text = data.get("text", "")
            self._append_bot(text)
            self._set_busy(False)
            self._refresh_status()
            self._speak_text(text)
        elif kind == EVENT_ERROR:
            self._append_note(f"[error] {data.get('text', '')}")
            self._log_line(f"✗ {data.get('text', '')}", "err")
            self._set_busy(False)

    # ------------------------------------------------------------------
    # Input
    # ------------------------------------------------------------------

    def _on_entry_return(self, event):
        if event.state & 0x0001:
            return None
        self._on_send()
        return "break"

    def _on_entry_escape(self, _event):
        self.entry.delete("1.0", END)
        return "break"

    def _on_send(self) -> None:
        if self._busy:
            return
        text = self.entry.get("1.0", END).strip()
        if not text:
            return
        self.entry.delete("1.0", END)

        if text.startswith("/") and self._handle_slash(text):
            return

        self._append_user(text)
        self._start_worker(text)

    def _handle_slash(self, text: str) -> bool:
        parts = text.split(maxsplit=1)
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        if cmd == "/help":
            self._append_bot(
                "Commands:\n"
                "  /index <path>      Index a file or folder\n"
                "  /ask <question>    Ask about indexed documents\n"
                "  /plugins           List loaded plugins\n"
                "  /reload            Reload plugins\n"
                "  /mcp               List MCP servers\n"
                "  /reload-mcp        Reload MCP servers\n"
                "  /models            Manage local models\n"
                "  /backend <name>    deepseek | gemini | qwen | zai | ollama\n"
                "  /model <name>      Change the model\n"
                "  /clear             Clear the conversation\n")
            return True
        if cmd == "/clear":
            self._clear_chat()
            return True
        if cmd == "/plugins":
            self._list_plugins()
            return True
        if cmd == "/reload":
            self._reload_plugins(announce=True)
            return True
        if cmd == "/mcp":
            self._list_mcp()
            return True
        if cmd == "/reload-mcp":
            self._reload_mcp(announce=True)
            return True
        if cmd == "/models":
            self._open_models()
            return True
        if cmd == "/index":
            if not arg:
                self._append_note("Usage: /index <path>")
                return True
            self._append_user(text)
            self._start_worker_index(arg)
            return True
        if cmd == "/ask":
            if not arg:
                self._append_note("Usage: /ask <question>")
                return True
            self._append_user(text)
            self._start_worker_ask(arg)
            return True
        if cmd == "/backend":
            if arg in BACKEND_DEFAULTS:
                self._switch_backend(arg)
            else:
                self._append_note(
                    f"Unknown backend. Options: {list(BACKEND_DEFAULTS)}")
            return True
        if cmd == "/model":
            if arg:
                self.cfg.model = arg
                save_config(self.cfg)
                self._rebuild_agent_keep_history()
                self._append_note(f"Model set to {arg}.")
                self._refresh_status()
            else:
                self._append_note("Usage: /model <name>")
            return True
        return False

    def _switch_backend(self, name: str) -> None:
        self.cfg.backend = name
        self.cfg.base_url = BACKEND_DEFAULTS[name]["base_url"]
        self.cfg.model = BACKEND_DEFAULTS[name]["model"]
        save_config(self.cfg)
        self._rebuild_agent_keep_history()
        self._append_note(f"Backend set to {name} ({self.cfg.model}).")
        self._refresh_status()

    def _rebuild_agent_keep_history(self) -> None:
        """Recreate the agent but preserve conversation and index."""
        if self.agent is None:
            self.agent = self._make_agent()
            return
        old_messages = list(self.agent.messages)
        old_index = self.agent.rag.index
        new_agent = self._make_agent()
        new_agent.messages = old_messages
        new_agent.rag.index = old_index
        self.agent = new_agent

    # ------------------------------------------------------------------
    # Workers
    # ------------------------------------------------------------------

    def _start_worker(self, text: str) -> None:
        self._worker_gen += 1
        self._set_busy(True)

        def job():
            try:
                self.agent.run(text)
            except Exception:
                self._enqueue_event(EVENT_ERROR,
                                    {"text": traceback.format_exc(limit=2)})
            finally:
                self._events.put((WORKER_DONE, {}))

        self._worker = threading.Thread(target=job, name="winpilot-agent",
                                        daemon=True)
        self._worker.start()

    def _start_worker_index(self, path: str) -> None:
        self._worker_gen += 1
        gen = self._worker_gen
        self._set_busy(True)
        root = self.cfg.effective_workspace()

        def job():
            try:
                msg = self.agent.rag.index_path(path, root)
            except Exception as e:
                msg = f"Index error: {e}"
            if gen == self._worker_gen:
                self._enqueue_event(EVENT_FINAL, {"text": msg})
            self._events.put((WORKER_DONE, {}))

        self._worker = threading.Thread(target=job, name="winpilot-index",
                                        daemon=True)
        self._worker.start()

    def _start_worker_ask(self, question: str) -> None:
        self._worker_gen += 1
        gen = self._worker_gen
        self._set_busy(True)

        def job():
            try:
                answer = self.agent.rag.answer(question,
                                               top_k=self.cfg.rag_top_k)
            except Exception as e:
                answer = f"Error: {e}"
            if gen == self._worker_gen:
                self._enqueue_event(EVENT_FINAL, {"text": answer})
            self._events.put((WORKER_DONE, {}))

        self._worker = threading.Thread(target=job, name="winpilot-ask",
                                        daemon=True)
        self._worker.start()

    def _set_busy(self, busy: bool) -> None:
        self._busy = busy
        try:
            self.send_btn.state(["disabled"] if busy else ["!disabled"])
            self.cancel_btn.state(["!disabled"] if busy else ["disabled"])
        except Exception:
            pass

    def _cancel_task(self) -> None:
        """
        Cooperative cancel. Bump the generation so stale events are ignored,
        clear busy immediately, and let the in-flight worker finish in the
        background.
        """
        if not self._busy:
            return
        self._worker_gen += 1
        self._set_busy(False)
        self._append_note("(task cancelled — the current tool call will "
                          "finish in the background; its result is discarded)")

    # ------------------------------------------------------------------
    # Document actions
    # ------------------------------------------------------------------

    def _index_folder(self) -> None:
        folder = filedialog.askdirectory(
            initialdir=str(self.cfg.effective_workspace()),
            title="Choose a folder to index")
        if not folder:
            return
        self._append_user(f"/index {folder}")
        self._start_worker_index(folder)

    def _index_file(self) -> None:
        path = filedialog.askopenfilename(
            initialdir=str(self.cfg.effective_workspace()),
            title="Choose a file to index")
        if not path:
            return
        self._append_user(f"/index {path}")
        self._start_worker_index(path)

    def _ask_docs(self) -> None:
        from tkinter.simpledialog import askstring
        q = askstring("Ask about indexed docs", "Question:", parent=self)
        if not q:
            return
        self._append_user(f"/ask {q}")
        self._start_worker_ask(q)

    def _clear_index(self) -> None:
        if not messagebox.askyesno("Clear index",
                                   "Remove all indexed documents?"):
            return
        self.agent.rag.index.clear()
        try:
            self.agent.rag.index.save()
        except Exception:
            pass
        self._append_note("Index cleared.")
        self._refresh_status()

    # ------------------------------------------------------------------
    # Settings
    # ------------------------------------------------------------------

    def _open_settings(self, initial: bool = False) -> bool:
        dlg = _SettingsDialog(self, self.cfg, initial=initial)
        self.wait_window(dlg)
        if not dlg.saved:
            return False
        save_config(self.cfg)
        self._rebuild_agent_keep_history()
        self._refresh_status()
        return True

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    def _clear_chat(self) -> None:
        self.chat.configure(state="normal")
        self.chat.delete("1.0", END)
        self.chat.configure(state="disabled")
        if self.agent is not None:
            self.agent.clear_history()
        self.log.configure(state="normal")
        self.log.delete("1.0", END)
        self.log.configure(state="disabled")
        self._append_note("Chat cleared.")

    def _open_config_folder(self) -> None:
        from .config import CONFIG_DIR
        import os
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            if os.name == "nt":
                os.startfile(str(CONFIG_DIR))  # type: ignore[attr-defined]
            else:
                webbrowser.open(f"file://{CONFIG_DIR}")
        except Exception as e:
            messagebox.showerror("Could not open folder", str(e))

    def _about(self) -> None:
        messagebox.showinfo(
            "About WinPilot",
            f"WinPilot v{__version__}\n\n"
            "An AI agent for Windows.\n"
            "Chat on the left, live tool activity on the right.\n\n"
            "Plugins: drop a .py file in the plugins folder, then reload.\n"
            "MCP: add a server to mcp_servers.json, then reload.\n"
            "Voice: install faster-whisper and piper-tts.",
        )

    def _on_close(self) -> None:
        try:
            if self.cfg is not None:
                self.cfg.window_geometry = self.geometry()
                save_config(self.cfg)
        except Exception:
            pass
        try:
            from . import mcp_client
            client = mcp_client.get_client()
            if client is not None:
                client.disconnect_all()
        except Exception:
            pass
        self.destroy()

# ======================================================================
# Settings dialog
# ======================================================================

class _SettingsDialog(Toplevel):
    def __init__(self, parent: Tk, cfg: Config, initial: bool = False):
        super().__init__(parent)
        self.title("WinPilot Settings")
        self.configure(bg=BG)
        self.resizable(False, False)
        self.transient(parent)

        self.cfg = cfg
        self.initial = initial
        self.saved = False

        # Scrollable body — the dialog has grown.
        container = Frame(self, bg=BG)
        container.pack(fill=BOTH, expand=True)

        canvas = self._canvas = __import__("tkinter").Canvas(
            container, bg=BG, highlightthickness=0, bd=0, width=520)
        scroll = Scrollbar(container, orient=VERTICAL, command=canvas.yview)
        body = Frame(canvas, bg=BG)
        body.bind("<Configure>",
                  lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        self._body_win = canvas.create_window((0, 0), window=body, anchor="nw")
        canvas.bind("<Configure>",
                    lambda e: canvas.itemconfigure(self._body_win, width=e.width))
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side=LEFT, fill=BOTH, expand=True)
        scroll.pack(side=RIGHT, fill=Y)

        pad = 16
        inner = Frame(body, bg=BG)
        inner.pack(fill=BOTH, expand=True, padx=pad, pady=pad)

        row = 0

        def section(title: str):
            nonlocal row
            Label(inner, text=title, bg=BG, fg=ACCENT, font=FONT_UI_B,
                  anchor="w").grid(row=row, column=0, sticky="w",
                                   pady=(14, 2))
            row += 1

        def lbl(text: str):
            nonlocal row
            Label(inner, text=text, bg=BG, fg=TEXT_MUTED, font=FONT_UI_SM,
                  anchor="w").grid(row=row, column=0, sticky="w", pady=(8, 0))
            row += 1

        def entry(var, show=None, width=56):
            nonlocal row
            e = ttk.Entry(inner, textvariable=var, width=width)
            if show:
                e.configure(show=show)
            e.grid(row=row, column=0, sticky="we")
            row += 1
            return e

        def combo(var, values, width=54):
            nonlocal row
            c = ttk.Combobox(inner, textvariable=var, state="readonly",
                             values=values, width=width)
            c.grid(row=row, column=0, sticky="we")
            row += 1
            return c

        def check(text, var):
            nonlocal row
            ttk.Checkbutton(inner, text=text, variable=var).grid(
                row=row, column=0, sticky="w", pady=(4, 0))
            row += 1

        # ---- LLM ----
        section("LLM backend")

        lbl("Backend")
        self.backend_var = StringVar(value=cfg.backend)
        cb = combo(self.backend_var, list(BACKEND_DEFAULTS.keys()))
        cb.bind("<<ComboboxSelected>>", self._on_backend_change)

        lbl("API key")
        self.key_var = StringVar(value=cfg.api_key)
        entry(self.key_var, show="*")

        lbl("Model")
        self.model_var = StringVar(value=cfg.model)
        entry(self.model_var)

        lbl("Base URL")
        self.url_var = StringVar(value=cfg.base_url)
        entry(self.url_var)

        lbl("Request timeout (seconds)")
        self.timeout_var = StringVar(value=str(cfg.request_timeout))
        entry(self.timeout_var)

        # ---- Safety ----
        section("Safety")

        lbl("Workspace root (files outside this are blocked)")
        ws_row = Frame(inner, bg=BG)
        ws_row.grid(row=row, column=0, sticky="we")
        row += 1
        self.ws_var = StringVar(value=str(cfg.effective_workspace()))
        ttk.Entry(ws_row, textvariable=self.ws_var, width=44).pack(
            side=LEFT, fill=X, expand=True)
        ttk.Button(ws_row, text="Browse…", command=self._browse_workspace,
                   style="Secondary.TButton").pack(side=LEFT, padx=(6, 0))

        self.confirm_var = BooleanVar(value=cfg.require_confirmation)
        check("Require confirmation for destructive actions", self.confirm_var)

        # ---- Plugins ----
        section("Plugins")
        self.plugins_var = BooleanVar(value=cfg.plugins_enabled)
        check("Enable plugins", self.plugins_var)

        # ---- MCP ----
        section("MCP servers")
        self.mcp_var = BooleanVar(value=cfg.mcp_enabled)
        check("Enable MCP", self.mcp_var)

        lbl("MCP startup timeout (seconds)")
        self.mcp_timeout_var = StringVar(value=str(cfg.mcp_startup_timeout))
        entry(self.mcp_timeout_var)

        # ---- Voice ----
        section("Voice")
        try:
            from . import voice as voice_mod
            stt_names = ["(disabled)"] + voice_mod.get_stt_engine_names()
            tts_names = ["(disabled)"] + voice_mod.get_tts_engine_names()
        except Exception:
            stt_names = ["(disabled)"]
            tts_names = ["(disabled)"]

        lbl("Speech-to-text engine")
        self.stt_engine_var = StringVar(
            value=cfg.voice_stt_engine or "(disabled)")
        combo(self.stt_engine_var, stt_names)

        lbl("Whisper model size (tiny / base / small / medium)")
        self.stt_model_var = StringVar(value=cfg.voice_stt_model)
        entry(self.stt_model_var)

        lbl("Text-to-speech engine")
        self.tts_engine_var = StringVar(
            value=cfg.voice_tts_engine or "(disabled)")
        combo(self.tts_engine_var, tts_names)

        lbl("TTS voice (e.g. en_US-lessac-medium)")
        self.tts_voice_var = StringVar(value=cfg.voice_tts_voice)
        entry(self.tts_voice_var)

        self.speak_var = BooleanVar(value=cfg.voice_speak_responses)
        check("Speak responses aloud", self.speak_var)

        # Voice status line
        try:
            from . import voice as voice_mod
            status = voice_mod.get_engine_status()
            lines = []
            for name, (ok, reason) in status.items():
                lines.append(f"{name}: {'OK' if ok else reason}")
            lbl("Voice engine status")
            Label(inner, text="\n".join(lines), bg=BG, fg=TEXT_MUTED,
                  font=FONT_UI_SM, justify="left", anchor="w").grid(
                row=row, column=0, sticky="w")
            row += 1
        except Exception:
            pass

        # ---- Misc ----
        section("Misc")
        self.verbose_var = BooleanVar(value=cfg.verbose_tool_log)
        check("Verbose tool log", self.verbose_var)

        inner.columnconfigure(0, weight=1)

        # ---- Buttons ----
        btns = Frame(self, bg=BG)
        btns.pack(fill=X, padx=pad, pady=(0, pad))
        if not initial:
            ttk.Button(btns, text="Cancel", command=self._cancel,
                       style="Secondary.TButton").pack(side=RIGHT)
        ttk.Button(btns, text="Save", command=self._save,
                   style="Primary.TButton").pack(side=RIGHT, padx=(0, 6))

        self.update_idletasks()
        self._center(parent)

        self.wait_visibility()
        try:
            self.grab_set()
        except Exception:
            pass

    def _center(self, parent: Tk) -> None:
        try:
            px, py = parent.winfo_rootx(), parent.winfo_rooty()
            pw, ph = parent.winfo_width(), parent.winfo_height()
            w, h = self.winfo_width(), self.winfo_height()
            self.geometry(f"+{px + max(0, (pw - w) // 2)}"
                          f"+{py + max(0, (ph - h) // 3)}")
        except Exception:
            pass

    def _on_backend_change(self, _event=None) -> None:
        d = BACKEND_DEFAULTS.get(self.backend_var.get())
        if d:
            self.model_var.set(d["model"])
            self.url_var.set(d["base_url"])

    def _browse_workspace(self) -> None:
        p = filedialog.askdirectory(
            initialdir=self.ws_var.get() or str(Path.home()))
        if p:
            self.ws_var.set(p)

    def _cancel(self) -> None:
        self.saved = False
        self.destroy()

    def _save(self) -> None:
        backend = self.backend_var.get().strip()
        if backend not in BACKEND_DEFAULTS:
            messagebox.showerror("Invalid backend",
                                 f"Unknown backend: {backend}", parent=self)
            return

        model = self.model_var.get().strip()
        if not model:
            messagebox.showerror("Invalid model", "Model cannot be empty.",
                                 parent=self)
            return

        url = self.url_var.get().strip()
        if not url.startswith(("http://", "https://")):
            messagebox.showerror("Invalid URL",
                                 "Base URL must start with http:// or https://",
                                 parent=self)
            return

        ws = self.ws_var.get().strip()
        ws_path = Path(ws).expanduser() if ws else Path.home()
        try:
            ws_path = ws_path.resolve()
        except Exception:
            pass
        if not ws_path.is_dir():
            messagebox.showerror("Invalid workspace",
                                 f"Not a directory:\n{ws_path}", parent=self)
            return

        try:
            timeout = int(self.timeout_var.get())
            if not (5 <= timeout <= 600):
                raise ValueError
        except Exception:
            messagebox.showerror("Invalid timeout",
                                 "Timeout must be an integer between 5 and 600.",
                                 parent=self)
            return

        try:
            mcp_timeout = int(self.mcp_timeout_var.get())
            if not (1 <= mcp_timeout <= 120):
                raise ValueError
        except Exception:
            messagebox.showerror("Invalid MCP timeout",
                                 "MCP timeout must be between 1 and 120.",
                                 parent=self)
            return

        api_key = self.key_var.get().strip()
        if backend != "ollama" and not api_key:
            if not messagebox.askyesno(
                    "No API key",
                    f"No API key set for {backend}. Continue anyway?",
                    parent=self):
                return

        # Normalise voice engine names ("(disabled)" -> "")
        def norm_engine(v: str) -> str:
            v = v.strip()
            return "" if v in ("(disabled)", "") else v

        self.cfg.backend = backend
        self.cfg.api_key = api_key
        self.cfg.model = model
        self.cfg.base_url = url
        self.cfg.workspace_root = str(ws_path)
        self.cfg.request_timeout = timeout
        self.cfg.require_confirmation = bool(self.confirm_var.get())
        self.cfg.plugins_enabled = bool(self.plugins_var.get())
        self.cfg.mcp_enabled = bool(self.mcp_var.get())
        self.cfg.mcp_startup_timeout = mcp_timeout
        self.cfg.voice_stt_engine = norm_engine(self.stt_engine_var.get())
        self.cfg.voice_stt_model = self.stt_model_var.get().strip() or "base"
        self.cfg.voice_tts_engine = norm_engine(self.tts_engine_var.get())
        self.cfg.voice_tts_voice = (self.tts_voice_var.get().strip()
                                    or "en_US-lessac-medium")
        self.cfg.voice_speak_responses = bool(self.speak_var.get())
        self.cfg.verbose_tool_log = bool(self.verbose_var.get())

        self.saved = True
        self.destroy()

# ======================================================================
# Local models dialog
# ======================================================================

class _ModelsDialog(Toplevel):
    def __init__(self, parent: Tk, cfg: Config):
        super().__init__(parent)
        self.title("Local Models")
        self.configure(bg=BG)
        self.transient(parent)
        self.geometry("640x480")

        self.cfg = cfg

        from . import local_models

        top = Frame(self, bg=BG)
        top.pack(fill=X, padx=12, pady=(12, 6))

        self.backend_var = StringVar(value="ollama")
        ttk.Combobox(top, textvariable=self.backend_var, state="readonly",
                     values=local_models.get_backend_names(),
                     width=12).pack(side=LEFT)
        ttk.Button(top, text="Refresh", command=self._refresh,
                   style="Secondary.TButton").pack(side=LEFT, padx=(6, 0))
        ttk.Button(top, text="Pull model…", command=self._pull,
                   style="Secondary.TButton").pack(side=LEFT, padx=(6, 0))
        ttk.Button(top, text="Delete selected", command=self._delete,
                   style="Secondary.TButton").pack(side=LEFT, padx=(6, 0))

        # List
        list_frame = Frame(self, bg=BORDER, highlightthickness=1,
                           highlightbackground=BORDER)
        list_frame.pack(fill=BOTH, expand=True, padx=12, pady=6)

        from tkinter import Listbox
        self.listbox = Listbox(list_frame, bg="#ffffff", fg=TEXT, bd=0,
                               font=FONT_MONO, selectbackground=ACCENT_SOFT,
                               selectforeground=TEXT, activestyle="none")
        sb = Scrollbar(list_frame, orient=VERTICAL, command=self.listbox.yview)
        self.listbox.configure(yscrollcommand=sb.set)
        sb.pack(side=RIGHT, fill=Y)
        self.listbox.pack(side=LEFT, fill=BOTH, expand=True)

        self.status_var = StringVar(value="")
        Label(self, textvariable=self.status_var, bg=BG, fg=TEXT_MUTED,
              font=FONT_UI_SM, anchor="w", justify="left").pack(
            fill=X, padx=12)

        ttk.Button(self, text="Close", command=self.destroy,
                   style="Secondary.TButton").pack(pady=10)

        self._models: list = []
        self.after(50, self._refresh)
        self.wait_visibility()
        try:
            self.grab_set()
        except Exception:
            pass

    def _backend(self):
        from . import local_models
        return local_models.get_backend(self.backend_var.get())

    def _refresh(self) -> None:
        backend = self._backend()
        if backend is None:
            self.status_var.set("Unknown backend.")
            return
        if not backend.is_available():
            self.status_var.set(
                f"{backend.name} is not reachable. "
                "Is it running? (For Ollama: ollama serve)")
            self.listbox.delete(0, END)
            return

        self._models = backend.list_models()
        self.listbox.delete(0, END)
        for m in self._models:
            self.listbox.insert(END, f"{m.name}  —  {m.size_human()}")
        self.status_var.set(f"{len(self._models)} model(s) installed.")

    def _pull(self) -> None:
        from tkinter.simpledialog import askstring
        name = askstring("Pull model", "Model name (e.g. qwen2.5:7b):",
                         parent=self)
        if not name:
            return
        backend = self._backend()
        if backend is None:
            return

        self.status_var.set(f"Pulling '{name}'… (this can take minutes)")

        def job():
            ok, msg = backend.pull_model(
                name, progress_cb=lambda s: self.after(
                    0, lambda: self.status_var.set(f"{name}: {s}")))
            self.after(0, lambda: self.status_var.set(msg))
            self.after(200, self._refresh)

        threading.Thread(target=job, daemon=True).start()

    def _delete(self) -> None:
        sel = self.listbox.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx >= len(self._models):
            return
        model = self._models[idx]

        if not messagebox.askyesno(
                "Delete model",
                f"Delete '{model.name}'? This frees {model.size_human()}.",
                parent=self):
            return

        backend = self._backend()
        if backend is None:
            return
        ok, msg = backend.delete_model(model.name)
        self.status_var.set(msg)
        self._refresh()
