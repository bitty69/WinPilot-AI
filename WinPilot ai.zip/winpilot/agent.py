"""
The ReAct loop.

Flow:
  1. Send the conversation plus tool schemas to the LLM.
  2. If the LLM asks for tools, run them and append the results.
  3. Repeat until the LLM replies with text only, or we hit the iteration cap.

The agent emits events through `event_cb` so the GUI can show progress live.
It never touches widgets; the GUI marshals events onto the main thread.
"""

import json
import os
import platform
from datetime import datetime
from typing import Callable, Optional

from .config import Config
from .llm import LLMClient, LLMError
from .rag import RAGEngine
from .tools import execute_tool, tool_schemas

SYSTEM_PROMPT = """You are WinPilot, an AI agent running on the user's Windows computer.

You can call tools to:
- inspect and modify files (list, read, write, move, delete, search)
- run PowerShell commands (the user must confirm)
- get system info and the current time
- create Windows scheduled tasks
- search the web
- use any plugin tools that are loaded (names contain a double underscore)
- use any MCP tools that are connected (names contain a double underscore)

Rules:
- Use tools instead of guessing. Never invent file contents or system state.
- Plan multi-step tasks, then execute them one tool call at a time.
- The user can only access paths inside their workspace root: {workspace}
- Paths outside the workspace will be rejected. Do not try to escape it.
- Keep replies short and concrete. This is a small desktop app.
- If a tool returns an error, report it and propose a fix.
- You do not have a document-search tool; the user runs /ask for that.

Environment:
- CWD: {cwd}
- OS: {os_name}
- Date/time: {now}
- Plugins: {plugin_summary}
- MCP servers: {mcp_summary}
"""

# Event kinds
EVENT_THINKING = "thinking"
EVENT_TOOL_CALL = "tool_call"
EVENT_TOOL_RESULT = "tool_result"
EVENT_FINAL = "final"
EVENT_ERROR = "error"

class Agent:
    def __init__(self, cfg: Config,
                 event_cb: Optional[Callable[[str, dict], None]] = None):
        self.cfg = cfg
        self.llm = LLMClient(cfg)
        self.rag = RAGEngine(self.llm)
        self.event_cb = event_cb or (lambda kind, data: None)
        self.messages: list[dict] = []

    # -- events ------------------------------------------------------------

    def _emit(self, kind: str, **data) -> None:
        try:
            self.event_cb(kind, data)
        except Exception:
            pass

    # -- lifecycle ---------------------------------------------------------

    def clear_history(self) -> None:
        self.messages = []

    def _plugin_summary(self) -> str:
        try:
            from . import plugins
            loaded = plugins.get_loaded_plugins()
        except Exception:
            return "none"
        if not loaded:
            return "none"
        return ", ".join(f"{p.name} v{p.version}" for p in loaded)

    def _mcp_summary(self) -> str:
        try:
            from . import mcp_client
            conns = mcp_client.get_connections()
        except Exception:
            return "none"
        connected = [c for c in conns if c.connected]
        if not connected:
            return "none"
        return ", ".join(f"{c.config.name} ({len(c.tools)} tools)"
                         for c in connected)

    def _build_system_prompt(self) -> str:
        return SYSTEM_PROMPT.format(
            workspace=self.cfg.effective_workspace(),
            cwd=os.getcwd(),
            os_name=f"{platform.system()} {platform.release()}",
            now=datetime.now().strftime("%Y-%m-%d %H:%M"),
            plugin_summary=self._plugin_summary(),
            mcp_summary=self._mcp_summary(),
        )

    def _prune_history(self) -> None:
        """Bound the history and keep it shape-valid for the API."""
        limit = self.cfg.max_history_messages
        if len(self.messages) > limit:
            start = len(self.messages) - limit
            while start < len(self.messages) and self.messages[start]["role"] != "user":
                start += 1
            self.messages = self.messages[start:]

        while self.messages:
            last = self.messages[-1]
            if last["role"] == "assistant" and last.get("tool_calls"):
                self.messages.pop()
            else:
                break

        while self.messages and self.messages[0]["role"] == "tool":
            self.messages.pop(0)

    # -- main loop ---------------------------------------------------------

    def run(self, user_input: str) -> str:
        """Run one task. Returns the final text answer. Never raises."""
        self._emit(EVENT_THINKING, text="Thinking...")

        system = {"role": "system", "content": self._build_system_prompt()}
        convo = ([system] + list(self.messages)
                 + [{"role": "user", "content": user_input}])
        tools = tool_schemas()
        final_text: Optional[str] = None

        for _ in range(self.cfg.max_iterations):
            try:
                msg = self.llm.chat(convo, tools=tools)
            except LLMError as e:
                self._emit(EVENT_ERROR, text=str(e))
                self.messages.append({"role": "user", "content": user_input})
                self._prune_history()
                return f"LLM error: {e}"
            except Exception as e:
                self._emit(EVENT_ERROR, text=f"{type(e).__name__}: {e}")
                self.messages.append({"role": "user", "content": user_input})
                self._prune_history()
                return f"Unexpected error: {e}"

            tool_calls = getattr(msg, "tool_calls", None) or []

            if not tool_calls:
                final_text = (msg.content or "").strip() or "(empty response)"
                convo.append({"role": "assistant", "content": final_text})
                break

            convo.append({
                "role": "assistant",
                "content": msg.content or "",
                "tool_calls": [
                    {"id": tc.id, "type": "function",
                     "function": {"name": tc.function.name,
                                  "arguments": tc.function.arguments}}
                    for tc in tool_calls
                ],
            })

            for tc in tool_calls:
                name = tc.function.name
                try:
                    args = json.loads(tc.function.arguments or "{}")
                    if not isinstance(args, dict):
                        args = {}
                except json.JSONDecodeError:
                    args = {}

                self._emit(EVENT_TOOL_CALL, name=name, args=args)
                result_str = str(execute_tool(name, args, self.cfg))

                ok = (not result_str.startswith(("Error:", "Cancelled:"))
                      and not result_str.startswith("Search failed:"))
                self._emit(EVENT_TOOL_RESULT, name=name, ok=ok,
                           preview=result_str[:400])

                if len(result_str) > 8000:
                    result_str = (result_str[:8000]
                                  + "\n... [truncated by WinPilot]")

                convo.append({"role": "tool", "tool_call_id": tc.id,
                              "content": result_str})
        else:
            final_text = (f"Stopped after {self.cfg.max_iterations} tool-call "
                          "rounds without a final answer. Try a simpler phrasing.")
            self._emit(EVENT_FINAL, text=final_text)

        self.messages = [m for m in convo if m["role"] != "system"]
        self._prune_history()

        if final_text is None:
            final_text = "(no answer)"
        self._emit(EVENT_FINAL, text=final_text)
        return final_text
