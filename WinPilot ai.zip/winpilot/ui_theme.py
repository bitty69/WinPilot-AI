"""Tkinter theme — light, single blue accent. Safe to tweak."""

BG          = "#f7f8fa"
CARD        = "#ffffff"
BORDER      = "#e3e5e8"
TEXT        = "#1a1d21"
TEXT_MUTED  = "#6b7280"
ACCENT      = "#2563eb"
ACCENT_SOFT = "#eff4ff"
OK          = "#16a34a"
ERR         = "#dc2626"
WARN        = "#d97706"

FONT_UI    = ("Segoe UI", 10)
FONT_UI_SM = ("Segoe UI", 9)
FONT_UI_B  = ("Segoe UI", 10, "bold")
FONT_MONO  = ("Consolas", 9)
FONT_TITLE = ("Segoe UI", 12, "bold")

PAD = 10
GAP = 8
