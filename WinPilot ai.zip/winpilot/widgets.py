"""Small reusable Tkinter widgets."""

from tkinter import BOTH, Canvas, Frame, Scrollbar, VERTICAL, Y
from tkinter import ttk

class ScrollableFrame(Frame):
    """A vertically scrollable frame. Reserved for future panes."""

    def __init__(self, parent, bg="#ffffff", **kwargs):
        super().__init__(parent, bg=bg, **kwargs)
        self.canvas = Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self.scroll = Scrollbar(self, orient=VERTICAL, command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas)

        self.inner.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")),
        )
        self._win = self.canvas.create_window((0, 0), window=self.inner,
                                              anchor="nw")
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfigure(self._win, width=e.width),
        )
        self.canvas.configure(yscrollcommand=self.scroll.set)

        self.canvas.pack(side="left", fill=BOTH, expand=True)
        self.scroll.pack(side="right", fill=Y)
