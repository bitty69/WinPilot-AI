"""
Persistent local document Q&A.

  - Unicode-aware tokenizer, with CJK bigrams
  - Chunker that cannot loop and hard-splits giant lines
  - IDF computed per document, not per chunk
  - Index persists to ~/.winpilot/index.pkl
"""

import math
import pickle
import re
from collections import Counter
from pathlib import Path
from typing import Optional

from .config import INDEX_FILE, ensure_config_dir
from .llm import LLMClient
from .paths import resolve_and_check

TEXT_EXTENSIONS = {
    ".txt", ".md", ".rst", ".log", ".csv",
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".c", ".cpp", ".h",
    ".hpp", ".cs", ".go", ".rs", ".rb", ".php", ".swift", ".kt", ".scala",
    ".sh", ".bat", ".ps1", ".sql", ".html", ".css", ".scss", ".xml",
    ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".env",
}

_CJK_RE = re.compile(r"[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]")

def _tokenize(text: str) -> list[str]:
    """
    Unicode-aware tokenizer.

    Word tokens via \\w+, plus CJK character bigrams so CJK text (which has
    no spaces) can still be matched without a full segmenter.
    """
    lowered = text.lower()
    tokens = re.findall(r"\w+", lowered, flags=re.UNICODE)
    extra: list[str] = []
    for tok in tokens:
        if len(tok) >= 2 and _CJK_RE.search(tok):
            for i in range(len(tok) - 1):
                extra.append(tok[i:i + 2])
    return tokens + extra

def _chunk(text: str, chunk_size: int = 800, overlap: int = 100) -> list[str]:
    """
    Split text into chunks that never exceed `chunk_size`.

    Guarantees:
      - overlap < chunk_size (asserted)
      - lines longer than chunk_size are hard-split
      - forward progress every iteration (no infinite loop)
    """
    if chunk_size <= 0:
        raise ValueError("chunk_size must be positive")
    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("overlap must satisfy 0 <= overlap < chunk_size")

    lines: list[str] = []
    for line in text.splitlines(keepends=True):
        while len(line) > chunk_size:
            lines.append(line[:chunk_size])
            line = line[chunk_size:]
        if line:
            lines.append(line)

    chunks: list[str] = []
    current = ""
    for line in lines:
        if current and len(current) + len(line) > chunk_size:
            chunks.append(current)
            current = current[-overlap:] if overlap else ""
        current += line
    if current.strip():
        chunks.append(current)
    return chunks

class RAGIndex:
    """Serializable keyword index. Version-tagged pickle."""

    PICKLE_VERSION = 1

    def __init__(self) -> None:
        self.chunks: list[str] = []
        self.sources: list[str] = []
        self._df: Counter = Counter()
        self._n_docs: int = 0

    # -- building ----------------------------------------------------------

    def add_document(self, path: str, text: str) -> None:
        chunks = _chunk(text)
        if not chunks:
            return
        doc_token_set: set[str] = set()
        for c in chunks:
            self.chunks.append(c)
            self.sources.append(path)
            doc_token_set.update(_tokenize(c))
        for t in doc_token_set:
            self._df[t] += 1
        self._n_docs += 1

    def add_file(self, path: Path) -> str:
        """Return 'indexed', 'unsupported', 'unreadable', or 'skipped'."""
        if path.suffix.lower() not in TEXT_EXTENSIONS:
            return "unsupported"
        try:
            if path.stat().st_size > 5 * 1024 * 1024:
                return "skipped"
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return "unreadable"
        if len(text.strip()) < 20:
            return "skipped"
        self.add_document(str(path), text)
        return "indexed"

    def add_directory(self, root: Path) -> dict[str, int]:
        counts = {"indexed": 0, "unsupported": 0, "unreadable": 0, "skipped": 0}
        try:
            for p in root.rglob("*"):
                if p.is_file():
                    counts[self.add_file(p)] += 1
        except OSError:
            pass
        return counts

    # -- search ------------------------------------------------------------

    def search(self, query: str, top_k: int = 3) -> list[tuple[str, str, float]]:
        if not self.chunks:
            return []
        q_tokens = set(_tokenize(query))
        if not q_tokens:
            return []

        n_docs = max(self._n_docs, 1)
        scored: list[tuple[str, str, float]] = []
        for i, chunk in enumerate(self.chunks):
            c_tokens = _tokenize(chunk)
            if not c_tokens:
                continue
            c_counter = Counter(c_tokens)
            length = len(c_tokens)
            score = 0.0
            for t in q_tokens:
                tf_count = c_counter.get(t, 0)
                if not tf_count:
                    continue
                tf = tf_count / length
                idf = math.log((n_docs + 1) / (self._df.get(t, 0) + 1)) + 1.0
                score += tf * idf
            if score > 0:
                scored.append((self.sources[i], chunk, score))

        scored.sort(key=lambda x: x[2], reverse=True)
        return scored[:top_k]

    # -- introspection -----------------------------------------------------

    def is_empty(self) -> bool:
        return not self.chunks

    def stats(self) -> str:
        return f"{len(self.chunks)} chunks · {self._n_docs} documents"

    def clear(self) -> None:
        self.chunks.clear()
        self.sources.clear()
        self._df.clear()
        self._n_docs = 0

    # -- persistence -------------------------------------------------------

    def save(self, path: Optional[Path] = None) -> None:
        target = path or INDEX_FILE
        ensure_config_dir()
        tmp = target.with_suffix(".pkl.tmp")
        with open(tmp, "wb") as f:
            pickle.dump(
                {
                    "version": self.PICKLE_VERSION,
                    "chunks": self.chunks,
                    "sources": self.sources,
                    "df": self._df,
                    "n_docs": self._n_docs,
                },
                f, protocol=pickle.HIGHEST_PROTOCOL,
            )
        tmp.replace(target)

    @classmethod
    def load(cls, path: Optional[Path] = None) -> "RAGIndex":
        target = path or INDEX_FILE
        idx = cls()
        if not target.exists():
            return idx
        try:
            with open(target, "rb") as f:
                data = pickle.load(f)
        except Exception:
            return idx
        if not isinstance(data, dict) or data.get("version") != cls.PICKLE_VERSION:
            return idx
        idx.chunks = list(data.get("chunks", []))
        idx.sources = list(data.get("sources", []))
        idx._df = Counter(data.get("df", {}))
        idx._n_docs = int(data.get("n_docs", 0))
        if len(idx.sources) != len(idx.chunks):
            idx.clear()
        return idx

class RAGEngine:
    """Combines a persistent index with the LLM for grounded Q&A."""

    def __init__(self, llm: LLMClient, index: Optional[RAGIndex] = None):
        self.llm = llm
        self.index = index if index is not None else RAGIndex.load()

    def index_path(self, path_str: str, workspace_root: Path) -> str:
        try:
            p = resolve_and_check(path_str, workspace_root, must_exist=True)
        except (FileNotFoundError, PermissionError, ValueError) as e:
            return f"Error: {e}"

        if p.is_file():
            status = self.index.add_file(p)
            if status == "indexed":
                self.index.save()
                return f"Indexed {p}. Total: {self.index.stats()}"
            if status == "unsupported":
                return f"Skipped (unsupported file type): {p}"
            if status == "unreadable":
                return f"Could not read: {p}"
            return f"Skipped (empty or too small): {p}"

        if p.is_dir():
            counts = self.index.add_directory(p)
            self.index.save()
            parts = [f"Indexed {counts['indexed']} files under {p}"]
            if counts["unreadable"]:
                parts.append(f"{counts['unreadable']} unreadable")
            if counts["skipped"]:
                parts.append(f"{counts['skipped']} empty/oversized")
            parts.append(f"(ignored {counts['unsupported']} non-text files)")
            parts.append(f"Total: {self.index.stats()}")
            return " — ".join(parts)

        return f"Error: unsupported path: {p}"

    def answer(self, question: str, top_k: int = 3) -> str:
        if self.index.is_empty():
            return "No documents indexed yet. Use Index folder first."
        hits = self.index.search(question, top_k=top_k)
        if not hits:
            return "No relevant passages found for that question."
        blocks = [f"[Source {i}: {src}]\n{chunk}"
                  for i, (src, chunk, _s) in enumerate(hits, 1)]
        context = "\n\n---\n\n".join(blocks)
        messages = [
            {"role": "system", "content": (
                "Answer using ONLY the provided context. "
                "If the answer is not present, say so plainly. "
                "Cite sources as [Source N].")},
            {"role": "user",
             "content": f"Context:\n\n{context}\n\nQuestion: {question}"},
        ]
        msg = self.llm.chat(messages)
        return msg.content or "(no response)"
