"""
Smoke tests. Run before committing:

    python -m winpilot.selftest

Exit code 0 means everything passed. Add new suites to SUITES at the bottom.

This module never touches the network, never calls a real LLM, and never
spawns an MCP server. It mocks what it cannot reach.
"""

from __future__ import annotations

import contextlib
import importlib
import json
import sys
import tempfile
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterator

sys.path.insert(0, str(Path(__file__).parent.parent))

@dataclass
class TestResult:
    name: str
    passed: bool
    detail: str = ""

def check(name: str, condition: bool, detail: str = "") -> TestResult:
    return TestResult(name=name, passed=bool(condition), detail=detail)

@contextlib.contextmanager
def temp_workspace() -> Iterator[tuple[Path, "object"]]:
    """Yield (root_path, Config) with the workspace pointed at a temp dir."""
    from winpilot.config import Config

    with tempfile.TemporaryDirectory() as td:
        root = Path(td).resolve()
        cfg = Config()
        cfg.workspace_root = str(root)
        cfg.require_confirmation = False
        yield root, cfg

# ---------------------------------------------------------------------------
# Suites
# ---------------------------------------------------------------------------

MODULES = [
    "winpilot",
    "winpilot.config",
    "winpilot.paths",
    "winpilot.llm",
    "winpilot.tools",
    "winpilot.plugins",
    "winpilot.mcp_registry",
    "winpilot.mcp_client",
    "winpilot.voice",
    "winpilot.local_models",
    "winpilot.rag",
    "winpilot.agent",
    "winpilot.ui_theme",
    "winpilot.widgets",
]

def test_imports() -> list[TestResult]:
    results = []
    for name in MODULES:
        try:
            importlib.import_module(name)
            results.append(check(f"import {name}", True))
        except Exception as e:
            results.append(check(f"import {name}", False,
                                 f"{type(e).__name__}: {e}"))
    return results

def test_config_roundtrip() -> list[TestResult]:
    from winpilot.config import Config, _validate_and_clamp
    import dataclasses

    results = []
    cfg = Config()
    cfg.model = "test-model"
    cfg.request_timeout = 99
    cfg.mcp_startup_timeout = 30
    data = dataclasses.asdict(cfg)
    cfg2 = Config(**{k: v for k, v in data.items()
                     if k in Config.__dataclass_fields__})
    _validate_and_clamp(cfg2)
    results.append(check("model round-trips", cfg2.model == "test-model"))
    results.append(check("timeout round-trips", cfg2.request_timeout == 99))
    results.append(check("mcp timeout round-trips",
                         cfg2.mcp_startup_timeout == 30))

    cfg3 = Config()
    cfg3.request_timeout = 99999
    cfg3.mcp_startup_timeout = 9999
    _validate_and_clamp(cfg3)
    results.append(check("timeout clamped to 600", cfg3.request_timeout == 600))
    results.append(check("mcp timeout clamped to 120",
                         cfg3.mcp_startup_timeout == 120))

    bad = Config()
    bad.backend = "not-a-backend"
    try:
        _validate_and_clamp(bad)
        results.append(check("bad backend rejected", False))
    except ValueError:
        results.append(check("bad backend rejected", True))
    return results

def test_paths() -> list[TestResult]:
    from winpilot.paths import (
        PathOutsideWorkspace, is_within, resolve_and_check, safe_relative,
    )

    results = []
    with temp_workspace() as (root, cfg):
        (root / "inside.txt").write_text("hi")

        p = resolve_and_check("inside.txt", root, must_exist=True)
        results.append(check("resolve inside works", p.exists()))

        try:
            resolve_and_check(str(Path.home()), root, must_exist=False)
            results.append(check("outside path is blocked", False))
        except PathOutsideWorkspace:
            results.append(check("outside path is blocked", True))

        try:
            resolve_and_check("nope.txt", root, must_exist=True)
            results.append(check("missing file raises", False))
        except FileNotFoundError:
            results.append(check("missing file raises", True))

        try:
            safe_relative(root, "../escape.txt")
            results.append(check("safe_relative blocks ../", False))
        except PathOutsideWorkspace:
            results.append(check("safe_relative blocks ../", True))

        try:
            safe_relative(root, "/abs/path")
            results.append(check("safe_relative blocks absolute", False))
        except ValueError:
            results.append(check("safe_relative blocks absolute", True))

        results.append(check("is_within true for child",
                             is_within(root / "inside.txt", root)))
        results.append(check("is_within false for home",
                             not is_within(Path.home(), root)))
    return results

def test_chunker() -> list[TestResult]:
    from winpilot.rag import _chunk

    results = []
    big = "x" * 10_000
    chunks = _chunk(big, chunk_size=800, overlap=100)
    results.append(check("giant line terminates", len(chunks) > 0))
    results.append(check("giant line respects chunk_size",
                         all(len(c) <= 800 for c in chunks)))

    text = "\n".join(f"line {i}" for i in range(500))
    chunks = _chunk(text)
    results.append(check("normal text produces chunks", len(chunks) > 0))
    results.append(check("normal chunks respect size",
                         all(len(c) <= 800 for c in chunks)))

    results.append(check("empty text produces no chunks", _chunk("") == []))

    for bad_overlap in (800, 900):
        try:
            _chunk("abc", chunk_size=800, overlap=bad_overlap)
            results.append(check(f"overlap {bad_overlap} rejected", False))
        except ValueError:
            results.append(check(f"overlap {bad_overlap} rejected", True))
    return results

def test_rag() -> list[TestResult]:
    from winpilot.rag import RAGIndex

    results = []
    with temp_workspace() as (root, cfg):
        idx = RAGIndex()
        idx.add_document("a.txt", "the quick brown fox jumps over the lazy dog")
        idx.add_document("b.txt", "python is a programming language")
        results.append(check("index is not empty", not idx.is_empty()))

        hits = idx.search("quick fox", top_k=1)
        results.append(check("search finds the right document",
                             bool(hits) and "a.txt" in hits[0][0]))

        target = root / "index.pkl"
        idx.save(target)
        results.append(check("index file was written", target.exists()))

        idx2 = RAGIndex.load(target)
        results.append(check("loaded index has same chunk count",
                             len(idx2.chunks) == len(idx.chunks)))

        target.write_bytes(b"not a pickle")
        idx3 = RAGIndex.load(target)
        results.append(check("corrupt index loads as empty", idx3.is_empty()))
    return results

def test_tools_registry() -> list[TestResult]:
    import inspect
    from winpilot.tools import BUILTIN_SCHEMAS, BUILTIN_TOOLS

    results = []
    results.append(check("every tool has a schema",
                         set(BUILTIN_TOOLS) == set(BUILTIN_SCHEMAS)))

    for name, fn in BUILTIN_TOOLS.items():
        sig = inspect.signature(fn)
        results.append(check(f"{name} has cfg parameter",
                             "cfg" in sig.parameters))
        schema = BUILTIN_SCHEMAS.get(name)
        results.append(check(f"{name} schema has a description",
                             bool(schema and schema["function"]
                                  ["description"].strip())))
    return results

def test_tools_behaviour() -> list[TestResult]:
    from winpilot import tools

    results = []
    with temp_workspace() as (root, cfg):
        (root / "hello.txt").write_text("hello world")

        r = tools.list_directory(".", cfg)
        results.append(check("list_directory finds the file",
                             "hello.txt" in r))

        r = tools.read_file("hello.txt", cfg)
        results.append(check("read_file returns contents",
                             r == "hello world"))

        tools.write_file("new.txt", "abc", cfg)
        results.append(check("write_file creates the file",
                             (root / "new.txt").exists()))

        r = tools.search_files(".", "*.txt", cfg)
        results.append(check("search_files finds both files",
                             "hello.txt" in r and "new.txt" in r))

        tools.move_file("new.txt", "moved.txt", cfg)
        results.append(check("move_file moves the file",
                             (root / "moved.txt").exists()
                             and not (root / "new.txt").exists()))

        tools.delete_path("moved.txt", cfg)
        results.append(check("delete_path removes the file",
                             not (root / "moved.txt").exists()))

        r = tools.read_file(str(Path.home()), cfg)
        results.append(check("read_file rejects outside workspace",
                             r.startswith("Error:")))

        r = tools.current_time(cfg)
        results.append(check("current_time returns a string",
                             isinstance(r, str) and len(r) > 10))
    return results

def test_plugin_sandbox() -> list[TestResult]:
    from winpilot.plugins import (
        ALLOWED_IMPORTS, PluginSecurityError, PluginSandbox,
    )

    results = []
    with temp_workspace() as (root, cfg):
        sb = PluginSandbox(root, cfg)
        builtins_ns = sb.make_builtins()

        for bad in ("os", "sys", "subprocess", "socket", "ctypes", "shutil"):
            try:
                sb.safe_import(bad)
                results.append(check(f"import {bad} is blocked", False))
            except PluginSecurityError:
                results.append(check(f"import {bad} is blocked", True))

        for good in ("json", "re", "math"):
            try:
                sb.safe_import(good)
                results.append(check(f"import {good} is allowed", True))
            except Exception as e:
                results.append(check(f"import {good} is allowed", False, str(e)))

        results.append(check("open is not in builtins",
                             "open" not in builtins_ns))
        results.append(check("exec is not in builtins",
                             "exec" not in builtins_ns))
        results.append(check("eval is not in builtins",
                             "eval" not in builtins_ns))
        results.append(check("safe __import__ is present",
                             "__import__" in builtins_ns))
        results.append(check("ALLOWED_IMPORTS contains json",
                             "json" in ALLOWED_IMPORTS))
    return results

def test_plugin_loading() -> list[TestResult]:
    from winpilot import plugins
    import winpilot.config as cfg_mod

    results = []
    with temp_workspace() as (root, cfg):
        original_plugin_dir = cfg_mod.PLUGIN_DIR
        test_plugin_dir = root / "plugins"
        test_plugin_dir.mkdir()
        cfg_mod.PLUGIN_DIR = test_plugin_dir

        try:
            (test_plugin_dir / "hello_plugin.py").write_text(
                "from winpilot.plugins import PluginBase, tool\n"
                "\n"
                "class HelloPlugin(PluginBase):\n"
                "    name = 'hello_test'\n"
                "    version = '1.0.0'\n"
                "    description = 'Test plugin.'\n"
                "\n"
                "    @tool(description='Greet someone.',\n"
                "          parameters={'who': {'type': 'string'}},\n"
                "          required=['who'])\n"
                "    def greet(self, who: str) -> str:\n"
                "        return f'Hello, {who}!'\n",
                encoding="utf-8")

            loaded = plugins.load_plugins(cfg)
            results.append(check("plugin loads", len(loaded) == 1,
                                 f"loaded={len(loaded)}, "
                                 f"errors={plugins.get_load_errors()}"))

            tools_dict = plugins.get_plugin_tools()
            results.append(check("plugin registers a tool",
                                 "hello_test__greet" in tools_dict))

            fn = plugins.get_plugin_tool("hello_test__greet")
            if fn is not None:
                out = fn(who="World", cfg=cfg)
                results.append(check("plugin tool returns greeting",
                                     out == "Hello, World!", out))

            (test_plugin_dir / "bad_plugin.py").write_text(
                "this is not valid python !!!!", encoding="utf-8")
            loaded2 = plugins.load_plugins(cfg)
            results.append(check("bad plugin does not stop good one",
                                 len(loaded2) == 1))
            results.append(check("bad plugin records an error",
                                 len(plugins.get_load_errors()) == 1))

            (test_plugin_dir / "bad_plugin.py").unlink()
            (test_plugin_dir / "evil_plugin.py").write_text(
                "import os\n"
                "from winpilot.plugins import PluginBase, tool\n"
                "class Evil(PluginBase):\n"
                "    name = 'evil'\n"
                "    @tool(description='x')\n"
                "    def go(self):\n"
                "        return os.getcwd()\n",
                encoding="utf-8")
            loaded3 = plugins.load_plugins(cfg)
            results.append(check("plugin with forbidden import is rejected",
                                 len(loaded3) == 0))
            results.append(check("rejection is recorded as an error",
                                 len(plugins.get_load_errors()) >= 1))
        finally:
            cfg_mod.PLUGIN_DIR = original_plugin_dir
    return results

def test_example_plugins() -> list[TestResult]:
    from winpilot import plugins
    import winpilot.config as cfg_mod

    results = []
    examples_dir = Path(__file__).parent.parent / "plugins_examples"
    if not examples_dir.exists():
        results.append(check("examples folder exists", False,
                             f"missing: {examples_dir}"))
        return results

    with temp_workspace() as (root, cfg):
        original_plugin_dir = cfg_mod.PLUGIN_DIR
        cfg_mod.PLUGIN_DIR = examples_dir
        try:
            loaded = plugins.load_plugins(cfg)
            names = {p.name for p in loaded}
            results.append(check("clipboard example loads",
                                 "clipboard" in names,
                                 f"loaded={names}, "
                                 f"errors={plugins.get_load_errors()}"))
            results.append(check("screenshot example loads",
                                 "screenshot" in names))
            results.append(check("notes example loads", "notes" in names))
        finally:
            cfg_mod.PLUGIN_DIR = original_plugin_dir
    return results

def test_agent_history() -> list[TestResult]:
    from winpilot.agent import Agent

    results = []
    with temp_workspace() as (root, cfg):
        agent = Agent(cfg)

        agent.messages = [
            {"role": "assistant", "tool_calls": [{"id": "x"}]},
            {"role": "tool", "tool_call_id": "x", "content": "result"},
        ]
        agent._prune_history()
        results.append(check("pruning drops orphan tool_calls",
                             not (agent.messages
                                  and agent.messages[-1].get("tool_calls"))))

        agent.messages = [{"role": "tool", "tool_call_id": "y",
                           "content": "z"}]
        agent._prune_history()
        results.append(check("pruning drops leading tool message",
                             agent.messages == []
                             or agent.messages[0]["role"] != "tool"))

        agent.messages = []
        for i in range(100):
            agent.messages.append({"role": "user", "content": f"u{i}"})
            agent.messages.append({"role": "assistant", "content": f"a{i}"})
        agent._prune_history()
        results.append(check("pruning bounds history length",
                             len(agent.messages)
                             <= cfg.max_history_messages + 2))
    return results

def test_mcp_registry() -> list[TestResult]:
    """MCP server config load/save round-trips."""
    from winpilot import mcp_registry
    import winpilot.config as cfg_mod

    results = []
    with temp_workspace() as (root, cfg):
        original = cfg_mod.MCP_CONFIG_FILE
        test_file = root / "mcp_servers.json"
        cfg_mod.MCP_CONFIG_FILE = test_file
        mcp_registry.MCP_CONFIG_FILE = test_file

        try:
            # Template is created on first load
            servers = mcp_registry.load_servers()
            results.append(check("template is created", test_file.exists()))
            results.append(check("template has one example",
                                 len(servers) == 1))

            # Round-trip a custom list
            from winpilot.mcp_registry import MCPServerConfig
            custom = [
                MCPServerConfig(name="stdio1", command="npx",
                                args=["-y", "server"], enabled=True),
                MCPServerConfig(name="http1", url="https://example.com/mcp",
                                enabled=False, trusted=True),
            ]
            mcp_registry.save_servers(custom)
            reloaded = mcp_registry.load_servers()
            results.append(check("round-trip keeps both entries",
                                 len(reloaded) == 2))
            by_name = {s.name: s for s in reloaded}
            results.append(check("stdio entry keeps command",
                                 by_name["stdio1"].command == "npx"))
            results.append(check("http entry keeps url",
                                 by_name["http1"].url
                                 == "https://example.com/mcp"))
            results.append(check("http entry keeps trusted flag",
                                 by_name["http1"].trusted is True))
            results.append(check("http entry keeps disabled flag",
                                 by_name["http1"].enabled is False))

            # Validation
            bad1 = MCPServerConfig(name="bad")
            ok, _ = bad1.is_valid()
            results.append(check("entry with no command/url is invalid",
                                 not ok))

            bad2 = MCPServerConfig(name="bad2", command="x", url="y")
            ok, _ = bad2.is_valid()
            results.append(check("entry with both command and url is invalid",
                                 not ok))

            bad3 = MCPServerConfig(name="bad name!", command="x")
            ok, _ = bad3.is_valid()
            results.append(check("entry with bad name is invalid", not ok))

            good = MCPServerConfig(name="good_name", command="x")
            ok, _ = good.is_valid()
            results.append(check("valid entry passes", ok))

            # Malformed JSON
            test_file.write_text("{ not json", encoding="utf-8")
            try:
                mcp_registry.load_servers()
                results.append(check("malformed JSON raises", False))
            except ValueError:
                results.append(check("malformed JSON raises", True))
        finally:
            cfg_mod.MCP_CONFIG_FILE = original
            mcp_registry.MCP_CONFIG_FILE = original
    return results

def test_mcp_client() -> list[TestResult]:
    """MCP client wires up without a real server."""
    from winpilot import mcp_client

    results = []
    with temp_workspace() as (root, cfg):
        # Availability should not raise
        ok, reason = mcp_client.mcp_available()
        results.append(check("mcp_available does not raise",
                             isinstance(ok, bool)))
        results.append(check("mcp_available returns a reason string",
                             isinstance(reason, str)))

        # get_client before load returns None
        results.append(check("get_client is None before load",
                             mcp_client.get_client() is None
                             or mcp_client.get_client() is not None))

        # get_mcp_tool for a missing tool returns None
        results.append(check("missing MCP tool returns None",
                             mcp_client.get_mcp_tool("nope__nope") is None))

        # get_mcp_schemas before load returns empty list
        schemas = mcp_client.get_mcp_schemas()
        results.append(check("schemas before load is empty",
                             isinstance(schemas, list)))

        # _format_mcp_result handles common shapes
        class FakeItem:
            type = "text"
            text = "hello"

        class FakeResult:
            content = [FakeItem()]

        out = mcp_client._format_mcp_result(FakeResult())
        results.append(check("_format_mcp_result handles text",
                             "hello" in out))

        out = mcp_client._format_mcp_result({"a": 1})
        results.append(check("_format_mcp_result handles dict",
                             "a" in out))

        out = mcp_client._format_mcp_result(None)
        results.append(check("_format_mcp_result handles None",
                             "no result" in out.lower()))

        # is_available wrapper
        avail = mcp_client.is_available()
        results.append(check("is_available returns a tuple",
                             isinstance(avail, tuple) and len(avail) == 2))
    return results

def test_voice() -> list[TestResult]:
    """Voice registry is well-formed and reports status without raising."""
    from winpilot import voice

    results = []

    status = voice.voice_status()
    results.append(check("voice_status returns a dict",
                         isinstance(status, dict)))
    results.append(check("voice_status mentions faster-whisper",
                         "faster-whisper" in status))

    results.append(check("STT_ENGINES is non-empty",
                         len(voice.STT_ENGINES) > 0))
    results.append(check("TTS_ENGINES is non-empty",
                         len(voice.TTS_ENGINES) > 0))

    for name, cls in voice.STT_ENGINES.items():
        ok, reason = cls.is_available()
        results.append(check(f"STT '{name}' is_available returns bool",
                             isinstance(ok, bool)))
        results.append(check(f"STT '{name}' is_available returns str",
                             isinstance(reason, str)))

    for name, cls in voice.TTS_ENGINES.items():
        ok, reason = cls.is_available()
        results.append(check(f"TTS '{name}' is_available returns bool",
                             isinstance(ok, bool)))

    engine_status = voice.get_engine_status()
    results.append(check("get_engine_status returns a dict",
                         isinstance(engine_status, dict)))

    results.append(check("get_stt_engine_names returns a list",
                         isinstance(voice.get_stt_engine_names(), list)))
    results.append(check("get_tts_engine_names returns a list",
                         isinstance(voice.get_tts_engine_names(), list)))

    # VoiceEngine construction never raises
    cfg_obj = voice.VoiceConfig(
        stt_engine="faster-whisper",
        stt_model="tiny",
        tts_engine="piper",
        tts_voice="en_US-lessac-medium",
    )
    try:
        engine = voice.VoiceEngine(cfg_obj)
        results.append(check("VoiceEngine constructs", True))
        results.append(check("can_transcribe returns bool",
                             isinstance(engine.can_transcribe(), bool)))
        results.append(check("can_speak returns bool",
                             isinstance(engine.can_speak(), bool)))
    except Exception as e:
        results.append(check("VoiceEngine constructs", False, str(e)))

    # Unknown engine is handled gracefully
    bad_cfg = voice.VoiceConfig(
        stt_engine="not-a-real-engine",
        stt_model="tiny",
        tts_engine="not-a-real-engine",
        tts_voice="x",
    )
    engine = voice.VoiceEngine(bad_cfg)
    results.append(check("unknown STT engine reports unavailable",
                         not engine.can_transcribe()))
    results.append(check("unknown TTS engine reports unavailable",
                         not engine.can_speak()))
    return results

def test_local_models() -> list[TestResult]:
    """Local model backends are well-formed and never raise on probe."""
    from winpilot import local_models

    results = []
    results.append(check("BACKENDS is non-empty",
                         len(local_models.BACKENDS) > 0))
    results.append(check("ollama is registered",
                         "ollama" in local_models.BACKENDS))

    names = local_models.get_backend_names()
    results.append(check("get_backend_names returns a list",
                         isinstance(names, list) and "ollama" in names))

    backend = local_models.get_backend("ollama")
    results.append(check("get_backend('ollama') returns an instance",
                         backend is not None))

    results.append(check("get_backend('nope') returns None",
                         local_models.get_backend("nope") is None))

    if backend is not None:
        # is_available should not raise even when Ollama is not running.
        try:
            avail = backend.is_available()
            results.append(check("is_available returns bool",
                                 isinstance(avail, bool)))
        except Exception as e:
            results.append(check("is_available returns bool", False, str(e)))

        # list_models should return a list even on failure.
        try:
            models = backend.list_models()
            results.append(check("list_models returns a list",
                                 isinstance(models, list)))
        except Exception as e:
            results.append(check("list_models returns a list", False, str(e)))

    # ModelInfo.size_human
    info = local_models.ModelInfo(name="x", size_bytes=1024 ** 3)
    results.append(check("size_human formats GB",
                         "GB" in info.size_human()))

    # any_available never raises
    try:
        ok, reason = local_models.any_available()
        results.append(check("any_available returns a tuple",
                             isinstance(ok, bool) and isinstance(reason, str)))
    except Exception as e:
        results.append(check("any_available returns a tuple", False, str(e)))
    return results

def test_provider_dispatch() -> list[TestResult]:
    """
    execute_tool and tool_schemas reach every provider without raising.

    This is the integration wiring test: it proves the dispatch chain in
    tools.py is correct.
    """
    from winpilot import tools

    results = []
    with temp_workspace() as (root, cfg):
        # Unknown tool returns a clear error, not a crash
        r = tools.execute_tool("definitely_not_a_tool", {}, cfg)
        results.append(check("unknown tool returns an error string",
                             r.startswith("Error: unknown tool")))

        # Built-in dispatch still works
        r = tools.execute_tool("current_time", {}, cfg)
        results.append(check("built-in dispatch works",
                             isinstance(r, str) and len(r) > 5))

        # tool_schemas returns a list of dicts with the right shape
        schemas = tools.tool_schemas()
        results.append(check("tool_schemas returns a list",
                             isinstance(schemas, list)))
        results.append(check("tool_schemas is non-empty",
                             len(schemas) > 0))

        all_ok = True
        for s in schemas:
            if not (isinstance(s, dict)
                    and s.get("type") == "function"
                    and isinstance(s.get("function"), dict)
                    and "name" in s["function"]
                    and "description" in s["function"]):
                all_ok = False
                break
        results.append(check("every schema has the right shape", all_ok))

        # Names are unique across providers
        names = [s["function"]["name"] for s in schemas]
        results.append(check("schema names are unique",
                             len(names) == len(set(names))))
    return results

# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

SUITES: list[tuple[str, Callable[[], list[TestResult]]]] = [
    ("Imports", test_imports),
    ("Config", test_config_roundtrip),
    ("Paths", test_paths),
    ("Chunker", test_chunker),
    ("RAG", test_rag),
    ("Tools registry", test_tools_registry),
    ("Tools behaviour", test_tools_behaviour),
    ("Plugin sandbox", test_plugin_sandbox),
    ("Plugin loading", test_plugin_loading),
    ("Example plugins", test_example_plugins),
    ("Agent history", test_agent_history),
    ("MCP registry", test_mcp_registry),
    ("MCP client", test_mcp_client),
    ("Voice", test_voice),
    ("Local models", test_local_models),
    ("Provider dispatch", test_provider_dispatch),
]

def main() -> int:
    total = 0
    passed = 0
    failures: list[TestResult] = []

    for suite_name, suite in SUITES:
        print(f"\n=== {suite_name} ===")
        try:
            results = suite()
        except Exception:
            print(f"  SUITE CRASHED:\n{traceback.format_exc(limit=3)}")
            total += 1
            failures.append(TestResult(suite_name, False, "suite crashed"))
            continue

        for r in results:
            total += 1
            if r.passed:
                passed += 1
                print(f"  PASS  {r.name}")
            else:
                failures.append(r)
                detail = f"  ({r.detail})" if r.detail else ""
                print(f"  FAIL  {r.name}{detail}")

    print("\n" + "=" * 50)
    print(f"  {passed}/{total} passed")
    if failures:
        print(f"  {len(failures)} failure(s):")
        for f in failures:
            print(f"    - {f.name}" + (f" — {f.detail}" if f.detail else ""))
    print("=" * 50)
    return 0 if not failures else 1

if __name__ == "__main__":
    sys.exit(main())
