"""
Settings and backend definitions.

Everything the user can change lives in the `Config` dataclass, loaded from
and saved to ~/.winpilot/config.json.

TO ADD A NEW LLM BACKEND: add an entry to BACKEND_DEFAULTS.
"""

import json
import os
import subprocess
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Where files live
# ---------------------------------------------------------------------------

CONFIG_DIR = Path.home() / ".winpilot"
CONFIG_FILE = CONFIG_DIR / "config.json"
INDEX_FILE = CONFIG_DIR / "index.pkl"
PLUGIN_DIR = CONFIG_DIR / "plugins"
MCP_CONFIG_FILE = CONFIG_DIR / "mcp_servers.json"
VOICE_DIR = CONFIG_DIR / "voice"

# ---------------------------------------------------------------------------
# Supported LLM backends
#
# Every backend must speak the OpenAI chat-completions API.
# ---------------------------------------------------------------------------

BACKEND_DEFAULTS: dict[str, dict[str, str]] = {
    "deepseek": {
        "base_url": "https://api.deepseek.com",
        "model": "deepseek-chat",
        "label": "DeepSeek",
    },
    "gemini": {
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai/",
        "model": "gemini-2.0-flash",
        "label": "Google Gemini",
    },
    "qwen": {
        "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "model": "qwen-plus",
        "label": "Qwen (DashScope)",
    },
    "zai": {
        "base_url": "https://api.z.ai/api/paas/v4/",
        "model": "glm-4-plus",
        "label": "Z.AI (GLM)",
    },
    "ollama": {
        "base_url": "http://localhost:11434/v1",
        "model": "qwen2.5:7b",
        "label": "Ollama (local)",
    },
}

# ---------------------------------------------------------------------------
# The Config dataclass
# ---------------------------------------------------------------------------

@dataclass
class Config:
    """User settings. Persisted as JSON."""

    # LLM connection
    backend: str = "deepseek"
    api_key: str = ""
    model: str = "deepseek-chat"
    base_url: str = "https://api.deepseek.com"

    # Safety
    require_confirmation: bool = True
    workspace_root: str = ""

    # Agent behaviour
    max_iterations: int = 12
    max_history_messages: int = 40
    request_timeout: int = 60
    temperature: float = 0.2

    # RAG
    rag_top_k: int = 3

    # Plugins
    plugins_enabled: bool = True

    # MCP
    mcp_enabled: bool = True
    mcp_startup_timeout: int = 20      # seconds to wait for a server to start

    # Voice
    voice_stt_engine: str = "faster-whisper"
    voice_stt_model: str = "base"
    voice_tts_engine: str = "piper"
    voice_tts_voice: str = "en_US-lessac-medium"
    voice_speak_responses: bool = False
    voice_push_to_talk: str = "<ctrl>+<space>"

    # GUI
    window_geometry: str = "1180x740"
    verbose_tool_log: bool = True

    def effective_workspace(self) -> Path:
        """The workspace root as a resolved Path (never empty)."""
        if self.workspace_root:
            return Path(self.workspace_root).expanduser().resolve()
        return Path.home().resolve()

# ---------------------------------------------------------------------------
# Load / save
# ---------------------------------------------------------------------------

def ensure_config_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

def ensure_plugin_dir() -> Path:
    PLUGIN_DIR.mkdir(parents=True, exist_ok=True)
    return PLUGIN_DIR

def ensure_voice_dir() -> Path:
    VOICE_DIR.mkdir(parents=True, exist_ok=True)
    return VOICE_DIR

def load_config() -> Optional[Config]:
    """
    Load config from disk.

    Returns:
        A Config, or None if the file does not exist.

    Raises:
        ValueError: if the file exists but is malformed, with a message
            written for the user.
    """
    if not CONFIG_FILE.exists():
        return None

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        raise ValueError(f"config.json is not valid JSON: {e}") from e

    if not isinstance(data, dict):
        raise ValueError("config.json must contain a JSON object.")

    known = set(Config.__dataclass_fields__)
    filtered = {k: v for k, v in data.items() if k in known}

    cfg = Config(**filtered)
    _validate_and_clamp(cfg)
    return cfg

def save_config(cfg: Config) -> None:
    """Write config atomically and try to lock down file permissions."""
    ensure_config_dir()
    tmp = CONFIG_FILE.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(asdict(cfg), f, indent=2)
    os.replace(tmp, CONFIG_FILE)
    _harden_permissions(CONFIG_FILE)

def backup_and_reset_config() -> Path:
    """Move a corrupt config aside. Returns the backup path."""
    ensure_config_dir()
    backup = CONFIG_FILE.with_suffix(".json.corrupt")
    if backup.exists():
        backup.unlink()
    os.replace(CONFIG_FILE, backup)
    return backup

# ---------------------------------------------------------------------------
# Validation helpers (private)
# ---------------------------------------------------------------------------

def _clamp_int(value: Any, lo: int, hi: int, field: str) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError) as e:
        raise ValueError(f"{field} must be an integer (got {value!r})") from e
    return max(lo, min(n, hi))

def _clamp_float(value: Any, lo: float, hi: float, field: str) -> float:
    try:
        n = float(value)
    except (TypeError, ValueError) as e:
        raise ValueError(f"{field} must be a number (got {value!r})") from e
    return max(lo, min(n, hi))

def _validate_and_clamp(cfg: Config) -> None:
    """Clamp numeric fields and reject impossible string values."""
    cfg.max_iterations = _clamp_int(cfg.max_iterations, 1, 50, "max_iterations")
    cfg.max_history_messages = _clamp_int(
        cfg.max_history_messages, 4, 500, "max_history_messages")
    cfg.request_timeout = _clamp_int(cfg.request_timeout, 5, 600,
                                     "request_timeout")
    cfg.rag_top_k = _clamp_int(cfg.rag_top_k, 1, 10, "rag_top_k")
    cfg.temperature = _clamp_float(cfg.temperature, 0.0, 2.0, "temperature")
    cfg.mcp_startup_timeout = _clamp_int(
        cfg.mcp_startup_timeout, 1, 120, "mcp_startup_timeout")

    if cfg.backend not in BACKEND_DEFAULTS:
        raise ValueError(f"Unknown backend: {cfg.backend!r}")
    if not isinstance(cfg.model, str) or not cfg.model.strip():
        raise ValueError("model must be a non-empty string")
    if not isinstance(cfg.base_url, str) or not cfg.base_url.startswith(
            ("http://", "https://")):
        raise ValueError("base_url must start with http:// or https://")

def _harden_permissions(path: Path) -> None:
    """
    Best-effort: restrict the config file to the current user.

    On Windows this uses icacls. On POSIX it uses chmod 0600. Failures are
    silent — defence in depth, not a guarantee.
    """
    if os.name == "nt":
        user = os.environ.get("USERNAME")
        if not user:
            return
        try:
            subprocess.run(
                ["icacls", str(path), "/inheritance:r", "/grant:r", f"{user}:F"],
                capture_output=True, text=True, timeout=10,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except Exception:
            pass
    else:
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
