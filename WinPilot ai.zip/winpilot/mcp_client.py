"""
MCP client — connect to Model Context Protocol servers and expose their tools.

Two transports are supported:
  - stdio: spawn a subprocess and speak JSON-RPC over stdin/stdout
  - HTTP:  connect to a streamable-HTTP endpoint

DESIGN
  - A connection is made on demand and cached.
  - Tools are prefixed with the server name: `filesystem__read_file`.
  - A tool call goes through the confirmation gate unless the server is
    marked trusted.
  - If a server is unreachable, its tools simply don't appear; the rest work.

The official `mcp` Python SDK is used when available. If it is not
installed, MCP support is disabled cleanly (no import error, no crash).
"""

from __future__ import annotations

import asyncio
import atexit
import json
import subprocess
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from .config import Config
from .mcp_registry import MCPServerConfig, load_servers

# ---------------------------------------------------------------------------
# Capability detection
# ---------------------------------------------------------------------------

def mcp_available() -> tuple[bool, str]:
    """Return (available, reason). Never raises."""
    try:
        import mcp  # noqa: F401
        return True, ""
    except ImportError:
        return False, (
            "MCP support requires the 'mcp' package. "
            "Install with: pip install mcp"
        )

# ---------------------------------------------------------------------------
# A single tool advertised by a server
# ---------------------------------------------------------------------------

@dataclass
class MCPTool:
    server: str
    name: str
    full_name: str
    description: str
    schema: dict
    trusted: bool = False

# ---------------------------------------------------------------------------
# A connection to one server
# ---------------------------------------------------------------------------

@dataclass
class MCPConnection:
    config: MCPServerConfig
    tools: list[MCPTool] = field(default_factory=list)
    error: str = ""
    connected: bool = False

# ---------------------------------------------------------------------------
# The client
# ---------------------------------------------------------------------------

class MCPClient:
    """
    Manages connections to MCP servers.

    Public methods:
        connect_all(cfg)     — (re)connect to every enabled server
        get_tool(full_name)  — return a callable for one tool
        get_schemas()        — list of OpenAI tool schemas
        connections()        — status of every server
        disconnect_all()     — clean shutdown
    """

    def __init__(self, cfg: Config,
                 logger: Optional[Callable[[str], None]] = None):
        self.cfg = cfg
        self._log = logger or (lambda msg: None)
        self._connections: dict[str, MCPConnection] = {}
        self._tools: dict[str, MCPTool] = {}
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._loop_thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()

        atexit.register(self.disconnect_all)

    # -- lifecycle ---------------------------------------------------------

    def connect_all(self, cfg: Optional[Config] = None) -> list[MCPConnection]:
        """
        Connect to every enabled server in the registry.

        Safe to call repeatedly. Each call starts from a clean slate.
        """
        if cfg is not None:
            self.cfg = cfg

        with self._lock:
            self._tools.clear()
            self._connections.clear()

            if not self.cfg.mcp_enabled:
                self._log("MCP is disabled in settings.")
                return []

            ok, reason = mcp_available()
            if not ok:
                self._log(reason)
                return []

            try:
                servers = load_servers()
            except ValueError as e:
                self._log(f"MCP config error: {e}")
                return []

            enabled = [s for s in servers if s.enabled]
            if not enabled:
                self._log("No MCP servers configured (or all disabled).")
                return []

            for server in enabled:
                valid, why = server.is_valid()
                if not valid:
                    conn = MCPConnection(config=server, error=why)
                    self._connections[server.name] = conn
                    self._log(f"MCP '{server.name}' skipped: {why}")
                    continue
                conn = self._connect_one(server)
                self._connections[server.name] = conn

            return list(self._connections.values())

    def disconnect_all(self) -> None:
        """Best-effort clean shutdown of every connection."""
        with self._lock:
            self._connections.clear()
            self._tools.clear()
        # Individual stdio processes are terminated by the SDK's context
        # managers when the event loop shuts down. We do not force-kill here
        # to avoid leaving zombie processes on Windows.

    # -- introspection -----------------------------------------------------

    def connections(self) -> list[MCPConnection]:
        return list(self._connections.values())

    def get_tool(self, full_name: str) -> Optional[Callable]:
        """
        Return a callable for the named tool, or None.

        The callable accepts **kwargs (including `cfg`) and returns a string.
        """
        tool = self._tools.get(full_name)
        if tool is None:
            return None

        def wrapper(**kwargs):
            kwargs.pop("cfg", None)   # the agent passes cfg; MCP doesn't need it
            # Confirmation gate
            if self.cfg.require_confirmation and not tool.trusted:
                from .tools import _confirm
                _confirm(
                    f"MCP: {tool.server}",
                    f"Run MCP tool '{tool.full_name}'?\n\n{tool.description}",
                    self.cfg,
                )
            return self._call_tool(tool, kwargs)

        wrapper.__name__ = full_name
        return wrapper

    def get_schemas(self) -> list[dict]:
        return [self._to_openai_schema(t) for t in self._tools.values()]

    # -- connection internals ----------------------------------------------

    def _connect_one(self, server: MCPServerConfig) -> MCPConnection:
        """Connect to a single server and enumerate its tools."""
        conn = MCPConnection(config=server)
        try:
            if server.is_stdio():
                raw_tools = self._list_tools_stdio(server)
            else:
                raw_tools = self._list_tools_http(server)
        except Exception as e:
            conn.error = f"{type(e).__name__}: {e}"
            self._log(f"MCP '{server.name}' failed: {conn.error}")
            return conn

        conn.connected = True
        for raw in raw_tools:
            name = raw.get("name", "")
            if not name:
                continue
            full = f"{server.name}__{name}"
            tool = MCPTool(
                server=server.name,
                name=name,
                full_name=full,
                description=raw.get("description", "") or f"MCP tool {name}",
                schema=raw.get("inputSchema") or {
                    "type": "object", "properties": {}
                },
                trusted=server.trusted,
            )
            conn.tools.append(tool)
            self._tools[full] = tool

        self._log(
            f"MCP '{server.name}' connected "
            f"({len(conn.tools)} tool(s))."
        )
        return conn

    def _list_tools_stdio(self, server: MCPServerConfig) -> list[dict]:
        """
        Start a stdio server and ask for its tool list.

        Uses the official `mcp` SDK. The SDK is async; we run it in a
        short-lived event loop on the calling thread.
        """
        return _run_async(self._async_list_tools_stdio(server))

    async def _async_list_tools_stdio(self, server: MCPServerConfig) -> list[dict]:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        params = StdioServerParameters(
            command=server.command,
            args=list(server.args),
            env={**dict(server.env)} or None,
        )

        timeout = float(self.cfg.mcp_startup_timeout)
        tools: list[dict] = []

        async def _with_timeout():
            async with stdio_client(params) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.list_tools()
                    return [
                        {
                            "name": t.name,
                            "description": t.description or "",
                            "inputSchema": t.inputSchema or {},
                        }
                        for t in result.tools
                    ]

        try:
            tools = await asyncio.wait_for(_with_timeout(), timeout=timeout)
        except asyncio.TimeoutError:
            raise TimeoutError(
                f"server did not respond within {timeout:.0f}s "
                f"(it may be downloading packages on first run)"
            )
        return tools

    def _list_tools_http(self, server: MCPServerConfig) -> list[dict]:
        """Connect to an HTTP MCP server and list its tools."""
        return _run_async(self._async_list_tools_http(server))

    async def _async_list_tools_http(self, server: MCPServerConfig) -> list[dict]:
        from mcp import ClientSession
        from mcp.client.streamable_http import streamablehttp_client

        timeout = float(self.cfg.mcp_startup_timeout)
        tools: list[dict] = []

        async def _with_timeout():
            async with streamablehttp_client(server.url) as (read, write, _):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.list_tools()
                    return [
                        {
                            "name": t.name,
                            "description": t.description or "",
                            "inputSchema": t.inputSchema or {},
                        }
                        for t in result.tools
                    ]

        try:
            tools = await asyncio.wait_for(_with_timeout(), timeout=timeout)
        except asyncio.TimeoutError:
            raise TimeoutError(
                f"server did not respond within {timeout:.0f}s"
            )
        return tools

    # -- calling -----------------------------------------------------------

    def _call_tool(self, tool: MCPTool, arguments: dict) -> str:
        """Call a tool on a server. Returns a string."""
        try:
            result = _run_async(
                self._async_call_tool(tool, arguments),
                timeout=float(self.cfg.request_timeout),
            )
        except TimeoutError:
            return f"Error: MCP tool '{tool.full_name}' timed out."
        except Exception as e:
            return f"Error calling {tool.full_name}: {type(e).__name__}: {e}"
        return result

    async def _async_call_tool(self, tool: MCPTool, arguments: dict) -> str:
        server = self._connections.get(tool.server)
        if server is None:
            raise RuntimeError(f"server '{tool.server}' is not connected")

        if server.config.is_stdio():
            return await self._async_call_stdio(server.config, tool.name,
                                                arguments)
        return await self._async_call_http(server.config, tool.name, arguments)

    async def _async_call_stdio(self, server: MCPServerConfig,
                                tool_name: str, arguments: dict) -> str:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        params = StdioServerParameters(
            command=server.command,
            args=list(server.args),
            env={**dict(server.env)} or None,
        )
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool(tool_name, arguments)
                return _format_mcp_result(result)

    async def _async_call_http(self, server: MCPServerConfig,
                               tool_name: str, arguments: dict) -> str:
        from mcp import ClientSession
        from mcp.client.streamable_http import streamablehttp_client

        async with streamablehttp_client(server.url) as (read, write, _):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await session.call_tool(tool_name, arguments)
                return _format_mcp_result(result)

    # -- schema conversion -------------------------------------------------

    @staticmethod
    def _to_openai_schema(tool: MCPTool) -> dict:
        """Convert an MCP tool into an OpenAI tool schema."""
        schema = tool.schema if isinstance(tool.schema, dict) else {}
        properties = schema.get("properties", {})
        if not isinstance(properties, dict):
            properties = {}
        required = schema.get("required", [])
        if not isinstance(required, list):
            required = []

        return {
            "type": "function",
            "function": {
                "name": tool.full_name,
                "description": tool.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": [str(r) for r in required],
                },
            },
        }

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _run_async(coro, timeout: Optional[float] = None):
    """
    Run an async coroutine on a fresh event loop in this thread.

    Used because the agent calls tools synchronously from a worker thread.
    Creating a loop per call is cheap for the low call rates here, and it
    avoids cross-thread loop reuse bugs.
    """
    if timeout is not None:
        coro = asyncio.wait_for(coro, timeout=timeout)
    return asyncio.run(coro)

def _format_mcp_result(result: Any) -> str:
    """
    Turn an MCP CallToolResult into a plain string.

    MCP results carry a list of content items; text is concatenated, other
    types are summarised by type.
    """
    if result is None:
        return "(no result)"

    content = getattr(result, "content", None)
    if content is None:
        # Some servers return a plain dict.
        if isinstance(result, dict):
            return json.dumps(result, indent=2, ensure_ascii=False)[:8000]
        return str(result)[:8000]

    parts: list[str] = []
    for item in content:
        item_type = getattr(item, "type", None)
        if item_type == "text":
            parts.append(getattr(item, "text", ""))
        elif item_type == "image":
            parts.append("[image]")
        elif item_type == "resource":
            parts.append(f"[resource: {getattr(item, 'uri', '?')}]")
        else:
            parts.append(f"[{item_type or 'unknown'}]")

    text = "\n".join(p for p in parts if p)
    return text[:8000] if text else "(empty result)"

# ---------------------------------------------------------------------------
# Module-level registry (mirrors the plugin pattern)
# ---------------------------------------------------------------------------

_client: Optional[MCPClient] = None

def get_client() -> Optional[MCPClient]:
    return _client

def load_mcp(cfg: Config,
             logger: Optional[Callable[[str], None]] = None
             ) -> list[MCPConnection]:
    """
    (Re)build the MCP client and connect to all enabled servers.

    Returns the list of connection results.
    """
    global _client
    if _client is None:
        _client = MCPClient(cfg, logger=logger)
    else:
        _client.cfg = cfg
        if logger is not None:
            _client._log = logger
    return _client.connect_all(cfg)

def get_mcp_tool(full_name: str) -> Optional[Callable]:
    """Provider hook: return a callable for an MCP tool, or None."""
    if _client is None:
        return None
    return _client.get_tool(full_name)

def get_mcp_schemas() -> list[dict]:
    """Provider hook: return OpenAI tool schemas for every MCP tool."""
    if _client is None:
        return []
    return _client.get_schemas()

def get_connections() -> list[MCPConnection]:
    if _client is None:
        return []
    return _client.connections()

def is_available() -> tuple[bool, str]:
    return mcp_available()
