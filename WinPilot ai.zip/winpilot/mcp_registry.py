"""
MCP server registry — load, save, and validate the server list.

The list lives in ~/.winpilot/mcp_servers.json. Each entry describes one
server: either a stdio command to spawn, or an HTTP URL to connect to.

No auto-discovery. The user lists servers explicitly. This is a deliberate
safety choice: a server runs with the user's privileges.
"""

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Optional

from .config import MCP_CONFIG_FILE, ensure_config_dir

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

@dataclass
class MCPServerConfig:
    """One MCP server entry."""

    name: str
    # Exactly one of these is set:
    command: str = ""                       # stdio server
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    url: str = ""                           # HTTP server

    enabled: bool = True
    trusted: bool = False                   # skip confirmation for its tools

    def is_stdio(self) -> bool:
        return bool(self.command)

    def is_http(self) -> bool:
        return bool(self.url)

    def is_valid(self) -> tuple[bool, str]:
        """Return (ok, reason). Used by the loader to skip bad entries."""
        if not self.name or not self.name.strip():
            return False, "server name is empty"
        if not self.name.replace("_", "").replace("-", "").isalnum():
            return False, "server name must be alphanumeric, dash, or underscore"
        if self.is_stdio() and self.is_http():
            return False, "server has both command and url; pick one"
        if not self.is_stdio() and not self.is_http():
            return False, "server has neither command nor url"
        if self.is_http() and not self.url.startswith(("http://", "https://")):
            return False, "url must start with http:// or https://"
        return True, ""

# ---------------------------------------------------------------------------
# Load / save
# ---------------------------------------------------------------------------

_TEMPLATE = {
    "servers": {
        "example_filesystem": {
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-filesystem",
                     str(Path.home() / "Documents")],
            "enabled": False,
            "trusted": False,
        }
    }
}

def ensure_mcp_config() -> Path:
    """Create a template config if none exists. Returns the path."""
    ensure_config_dir()
    if not MCP_CONFIG_FILE.exists():
        with open(MCP_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(_TEMPLATE, f, indent=2)
    return MCP_CONFIG_FILE

def load_servers() -> list[MCPServerConfig]:
    """
    Read the server list.

    Missing file → empty list (and a template is written).
    Malformed file → raises ValueError with a user-readable message.
    Invalid entries are skipped silently; use `validate_servers()` to see why.
    """
    ensure_mcp_config()

    try:
        with open(MCP_CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        raise ValueError(
            f"mcp_servers.json is not valid JSON: {e}\n"
            f"Path: {MCP_CONFIG_FILE}"
        ) from e

    if not isinstance(data, dict):
        raise ValueError("mcp_servers.json must contain a JSON object.")

    servers_raw = data.get("servers", {})
    if not isinstance(servers_raw, dict):
        raise ValueError("'servers' must be an object mapping names to configs.")

    servers: list[MCPServerConfig] = []
    for name, spec in servers_raw.items():
        if not isinstance(spec, dict):
            continue
        servers.append(_from_dict(name, spec))
    return servers

def validate_servers() -> list[tuple[str, bool, str]]:
    """
    Return (name, ok, reason) for every entry.

    Useful in the GUI to show which entries are misconfigured.
    """
    out = []
    for s in load_servers():
        ok, reason = s.is_valid()
        out.append((s.name, ok, reason))
    return out

def save_servers(servers: list[MCPServerConfig]) -> None:
    """Write the server list atomically."""
    ensure_config_dir()
    payload = {
        "servers": {s.name: _to_dict(s) for s in servers},
    }
    tmp = MCP_CONFIG_FILE.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    os.replace(tmp, MCP_CONFIG_FILE)

def _from_dict(name: str, spec: dict[str, Any]) -> MCPServerConfig:
    """Build a config from a raw dict, tolerating missing keys."""
    args = spec.get("args", [])
    if not isinstance(args, list):
        args = []
    env = spec.get("env", {})
    if not isinstance(env, dict):
        env = {}

    return MCPServerConfig(
        name=name,
        command=str(spec.get("command", "") or ""),
        args=[str(a) for a in args],
        env={str(k): str(v) for k, v in env.items()},
        url=str(spec.get("url", "") or ""),
        enabled=bool(spec.get("enabled", True)),
        trusted=bool(spec.get("trusted", False)),
    )

def _to_dict(s: MCPServerConfig) -> dict[str, Any]:
    """Serialise a config, omitting empty fields for readability."""
    d: dict[str, Any] = {"enabled": s.enabled, "trusted": s.trusted}
    if s.command:
        d["command"] = s.command
        if s.args:
            d["args"] = list(s.args)
        if s.env:
            d["env"] = dict(s.env)
    if s.url:
        d["url"] = s.url
    return d

def config_path() -> Path:
    return MCP_CONFIG_FILE
