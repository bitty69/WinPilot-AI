"""
OpenAI-compatible LLM client.

Every supported backend speaks the OpenAI chat-completions API, so one client
covers all of them. The per-backend difference is the base URL, which lives
in config.py.

This module knows nothing about tools, agents, plugins, MCP, or the GUI.
"""

from typing import Optional

from openai import OpenAI

from .config import Config

class LLMError(RuntimeError):
    """A request failure worth showing to the user in plain language."""

class LLMClient:
    """Thin wrapper around an OpenAI-compatible endpoint."""

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._client: Optional[OpenAI] = None
        self._client_key: tuple = ()

    # -- public API --------------------------------------------------------

    def chat(self, messages: list[dict],
             tools: Optional[list[dict]] = None):
        """
        Send a chat request.

        Args:
            messages: OpenAI-format message dicts.
            tools: Optional tool schemas. When given, the model may reply with
                tool calls instead of text.

        Returns:
            The assistant message object (`.content` and `.tool_calls`).

        Raises:
            LLMError: on any API failure, with a human-readable message.
        """
        client = self._ensure_client()
        kwargs: dict = {
            "model": self.cfg.model,
            "messages": messages,
            "temperature": self.cfg.temperature,
        }
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"

        try:
            response = client.chat.completions.create(**kwargs)
        except Exception as e:
            raise LLMError(_friendly_error(e)) from e

        if not response.choices:
            raise LLMError("The provider returned no choices.")
        return response.choices[0].message

    # -- internals ---------------------------------------------------------

    def _ensure_client(self) -> OpenAI:
        """Build the client lazily, and rebuild it if settings changed."""
        key = (self.cfg.api_key, self.cfg.base_url, self.cfg.request_timeout)
        if self._client is None or self._client_key != key:
            self._client = OpenAI(
                # Ollama ignores the key but the SDK requires a non-empty one.
                api_key=self.cfg.api_key or "ollama",
                base_url=self.cfg.base_url,
                timeout=float(self.cfg.request_timeout),
                max_retries=2,
            )
            self._client_key = key
        return self._client

def _friendly_error(e: Exception) -> str:
    """Turn a raw API exception into something a user can act on."""
    msg = str(e)
    low = msg.lower()

    if "404" in msg or ("model" in low and "not found" in low):
        return f"Model not found. Check the model name in Settings. ({msg})"
    if "401" in msg or "unauthorized" in low or "invalid api key" in low:
        return f"Authentication failed. Check your API key. ({msg})"
    if "429" in msg or "rate" in low:
        return f"Rate limited by the provider. Try again shortly. ({msg})"
    if "timeout" in low or "timed out" in low:
        return f"Request timed out. ({msg})"
    if "connection" in low or "connect" in low:
        return f"Could not reach the provider. Check your network. ({msg})"
    return msg
