"""
Voice I/O — speech-to-text and text-to-speech.

Two abstract engines, two concrete implementations each are possible; one
of each ships by default:

  STT: faster-whisper  (OpenAI Whisper, CPU-friendly)
  TTS: piper-tts       (fast, small, natural)

Both are OPTIONAL. If a package is not installed, the corresponding engine
reports unavailable and the GUI disables the relevant control.

TO ADD A NEW ENGINE: subclass STTEngine or TTSEngine, register it in the
STT_ENGINES / TTS_ENGINES dict at the bottom. The GUI reads those dicts.
"""

from __future__ import annotations

import importlib.util
import threading
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from .config import VOICE_DIR, ensure_voice_dir

# ---------------------------------------------------------------------------
# Availability probes
# ---------------------------------------------------------------------------

def _module_present(name: str) -> bool:
    """Return True if the named top-level module can be imported."""
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError):
        return False

def voice_status() -> dict[str, tuple[bool, str]]:
    """
    Report which voice packages are installed.

    Returns a dict: {"faster-whisper": (True, ""), "piper-tts": (False, "...")}
    Never raises.
    """
    status: dict[str, tuple[bool, str]] = {}

    if _module_present("faster_whisper"):
        status["faster-whisper"] = (True, "")
    else:
        status["faster-whisper"] = (
            False,
            "Run: pip install faster-whisper sounddevice numpy",
        )

    if _module_present("piper"):
        status["piper-tts"] = (True, "")
    else:
        status["piper-tts"] = (
            False,
            "Run: pip install piper-tts",
        )

    if _module_present("sounddevice"):
        status["sounddevice"] = (True, "")
    else:
        status["sounddevice"] = (
            False,
            "Run: pip install sounddevice numpy",
        )

    return status

# ---------------------------------------------------------------------------
# Abstract engines
# ---------------------------------------------------------------------------

class STTEngine(ABC):
    """Speech-to-text."""

    name: str = "abstract"

    @abstractmethod
    def transcribe(self, audio_path: Path) -> str:
        """Return the transcribed text. Raises on failure."""

    @classmethod
    def is_available(cls) -> tuple[bool, str]:
        """Return (available, reason). Subclasses override."""
        return False, "not implemented"

class TTSEngine(ABC):
    """Text-to-speech."""

    name: str = "abstract"

    @abstractmethod
    def speak(self, text: str) -> None:
        """Speak the text, blocking until playback finishes."""

    @classmethod
    def is_available(cls) -> tuple[bool, str]:
        return False, "not implemented"

# ---------------------------------------------------------------------------
# Concrete STT: faster-whisper
# ---------------------------------------------------------------------------

class FasterWhisperSTT(STTEngine):
    """
    Wraps faster-whisper.

    The model is loaded lazily on first use and cached for the session, so
    the first transcription is slow and subsequent ones are fast.
    """

    name = "faster-whisper"
    _model_cache: dict[str, object] = {}
    _cache_lock = threading.Lock()

    def __init__(self, model_size: str = "base"):
        self.model_size = model_size

    @classmethod
    def is_available(cls) -> tuple[bool, str]:
        if not _module_present("faster_whisper"):
            return False, "Run: pip install faster-whisper"
        return True, ""

    def _get_model(self):
        from faster_whisper import WhisperModel  # type: ignore
        with self._cache_lock:
            model = self._model_cache.get(self.model_size)
            if model is None:
                model = WhisperModel(self.model_size, device="cpu",
                                     compute_type="int8")
                self._model_cache[self.model_size] = model
            return model

    def transcribe(self, audio_path: Path) -> str:
        if not audio_path.exists():
            raise FileNotFoundError(f"Audio file not found: {audio_path}")
        model = self._get_model()
        segments, _info = model.transcribe(str(audio_path), beam_size=1)
        text = " ".join(seg.text.strip() for seg in segments).strip()
        return text or "(no speech detected)"

# ---------------------------------------------------------------------------
# Concrete TTS: piper
# ---------------------------------------------------------------------------

class PiperTTS(TTSEngine):
    """
    Wraps piper-tts.

    Voices are downloaded on demand into ~/.winpilot/voice/. The voice name
    is like 'en_US-lessac-medium'.
    """

    name = "piper"

    def __init__(self, voice: str = "en_US-lessac-medium"):
        self.voice = voice
        self._voice_obj = None

    @classmethod
    def is_available(cls) -> tuple[bool, str]:
        if not _module_present("piper"):
            return False, "Run: pip install piper-tts"
        return True, ""

    def _get_voice(self):
        if self._voice_obj is not None:
            return self._voice_obj

        ensure_voice_dir()

        # piper-tts exposes either piper.voice.PiperVoice or a downloader.
        try:
            from piper.voice import PiperVoice  # type: ignore

            # Look for an already-downloaded model.
            model_path = VOICE_DIR / f"{self.voice}.onnx"
            if not model_path.exists():
                self._download_voice(self.voice, model_path)
            self._voice_obj = PiperVoice.load(str(model_path))
            return self._voice_obj
        except ImportError as e:
            raise RuntimeError(f"piper-tts is not importable: {e}") from e

    def _download_voice(self, voice: str, target: Path) -> None:
        """
        Download a voice model if the package provides a downloader.

        Different piper-tts versions expose this differently, so this is
        best-effort: if no downloader is found, we raise a clear error
        telling the user how to fetch it manually.
        """
        try:
            from piper.download import ensure_voice_exists  # type: ignore
            ensure_voice_exists(voice, [str(VOICE_DIR)], str(VOICE_DIR))
            return
        except ImportError:
            pass

        raise RuntimeError(
            f"Voice '{voice}' is not downloaded. Run this once:\n"
            f"  python -m piper.download_voices {voice} "
            f"--data-dir \"{VOICE_DIR}\"\n"
            f"Then try again."
        )

    def speak(self, text: str) -> None:
        if not text.strip():
            return

        voice = self._get_voice()

        # Synthesise to a temp WAV, then play it.
        out_path = VOICE_DIR / "_last_speech.wav"
        try:
            with open(out_path, "wb") as f:
                voice.synthesize(text, f)  # type: ignore[arg-type]
        except TypeError:
            # Older API: synthesize_stream_raw
            with open(out_path, "wb") as f:
                for chunk in voice.synthesize_stream_raw(text):  # type: ignore
                    f.write(chunk)

        _play_wav(out_path)

# ---------------------------------------------------------------------------
# Playback
# ---------------------------------------------------------------------------

def _play_wav(path: Path) -> None:
    """
    Play a WAV file.

    Uses sounddevice if available, otherwise falls back to the Windows
    winsound module (which only handles WAV, which is what we produce).
    """
    if _module_present("sounddevice"):
        try:
            import numpy as np  # type: ignore
            import sounddevice as sd  # type: ignore
            import wave

            with wave.open(str(path), "rb") as wf:
                frames = wf.readframes(wf.getnframes())
                audio = np.frombuffer(frames, dtype=np.int16)
                sd.play(audio, wf.getframerate())
                sd.wait()
            return
        except Exception:
            pass  # fall through to winsound

    try:
        import winsound  # type: ignore
        winsound.PlaySound(str(path), winsound.SND_FILENAME)
        return
    except Exception as e:
        raise RuntimeError(
            f"Could not play audio. Install sounddevice: {e}"
        ) from e

# ---------------------------------------------------------------------------
# Recording
# ---------------------------------------------------------------------------

def record_to_wav(duration: float = 5.0,
                  samplerate: int = 16000,
                  stop_event: Optional[threading.Event] = None) -> Path:
    """
    Record from the default microphone to a WAV file in the voice dir.

    Args:
        duration: Maximum seconds to record.
        samplerate: Sample rate. Whisper expects 16000.
        stop_event: If given, recording stops as soon as it is set.

    Returns:
        The path to the written WAV file.

    Raises:
        RuntimeError: if sounddevice is not installed or recording fails.
    """
    if not _module_present("sounddevice"):
        raise RuntimeError(
            "Recording requires sounddevice. Run: pip install sounddevice numpy"
        )

    import numpy as np  # type: ignore
    import sounddevice as sd  # type: ignore
    import wave

    ensure_voice_dir()
    out_path = VOICE_DIR / "_recording.wav"

    frames: list[bytes] = []

    def callback(indata, _frames, _time, status):
        if status:
            # Overruns are non-fatal; keep recording.
            pass
        frames.append(bytes(indata))

    with sd.RawInputStream(samplerate=samplerate, channels=1,
                           dtype="int16", callback=callback):
        if stop_event is not None:
            stop_event.wait(timeout=duration)
        else:
            sd.sleep(int(duration * 1000))

    with wave.open(str(out_path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)          # int16
        wf.setframerate(samplerate)
        wf.writeframes(b"".join(frames))

    return out_path

# ---------------------------------------------------------------------------
# Facade
# ---------------------------------------------------------------------------

@dataclass
class VoiceConfig:
    stt_engine: str
    stt_model: str
    tts_engine: str
    tts_voice: str

class VoiceEngine:
    """
    Holds one STT and one TTS engine, built from config.

    Methods return safe defaults when the requested engine is unavailable —
    they never raise on construction.
    """

    def __init__(self, cfg: VoiceConfig):
        self.cfg = cfg
        self.stt: Optional[STTEngine] = None
        self.tts: Optional[TTSEngine] = None
        self.stt_error = ""
        self.tts_error = ""
        self._build()

    def _build(self) -> None:
        # STT
        stt_cls = STT_ENGINES.get(self.cfg.stt_engine)
        if stt_cls is None:
            self.stt_error = f"Unknown STT engine: {self.cfg.stt_engine}"
        else:
            ok, reason = stt_cls.is_available()
            if not ok:
                self.stt_error = reason
            else:
                try:
                    if stt_cls is FasterWhisperSTT:
                        self.stt = stt_cls(model_size=self.cfg.stt_model)
                    else:
                        self.stt = stt_cls()  # type: ignore[call-arg]
                except Exception as e:
                    self.stt_error = f"{type(e).__name__}: {e}"

        # TTS
        tts_cls = TTS_ENGINES.get(self.cfg.tts_engine)
        if tts_cls is None:
            self.tts_error = f"Unknown TTS engine: {self.cfg.tts_engine}"
        else:
            ok, reason = tts_cls.is_available()
            if not ok:
                self.tts_error = reason
            else:
                try:
                    if tts_cls is PiperTTS:
                        self.tts = tts_cls(voice=self.cfg.tts_voice)
                    else:
                        self.tts = tts_cls()  # type: ignore[call-arg]
                except Exception as e:
                    self.tts_error = f"{type(e).__name__}: {e}"

    def can_transcribe(self) -> bool:
        return self.stt is not None

    def can_speak(self) -> bool:
        return self.tts is not None

    def transcribe_file(self, path: Path) -> str:
        if self.stt is None:
            return f"Error: speech-to-text is unavailable ({self.stt_error})"
        try:
            return self.stt.transcribe(path)
        except Exception as e:
            return f"Error transcribing: {type(e).__name__}: {e}"

    def speak(self, text: str) -> str:
        """Speak the text. Returns an error string, or '' on success."""
        if self.tts is None:
            return f"Speech output is unavailable ({self.tts_error})"
        try:
            self.tts.speak(text)
            return ""
        except Exception as e:
            return f"Error speaking: {type(e).__name__}: {e}"

# ---------------------------------------------------------------------------
# Registries
# ---------------------------------------------------------------------------

STT_ENGINES: dict[str, type[STTEngine]] = {
    "faster-whisper": FasterWhisperSTT,
}

TTS_ENGINES: dict[str, type[TTSEngine]] = {
    "piper": PiperTTS,
}

def get_stt_engine_names() -> list[str]:
    return sorted(STT_ENGINES.keys())

def get_tts_engine_names() -> list[str]:
    return sorted(TTS_ENGINES.keys())

def get_engine_status() -> dict[str, tuple[bool, str]]:
    """Status of every registered engine, for the Settings dialog."""
    out: dict[str, tuple[bool, str]] = {}
    for name, cls in STT_ENGINES.items():
        out[f"STT: {name}"] = cls.is_available()
    for name, cls in TTS_ENGINES.items():
        out[f"TTS: {name}"] = cls.is_available()
    return out
