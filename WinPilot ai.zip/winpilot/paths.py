"""
Workspace-root path safety.

Every filesystem tool must call `resolve_and_check()` before touching disk.
It resolves the path (following symlinks) and raises if the result is outside
the workspace root.

Deliberately small, no dependencies on other WinPilot modules.
"""

from pathlib import Path

class PathOutsideWorkspace(PermissionError):
    """Raised when a path escapes the workspace root."""

def resolve_and_check(raw_path: str,
                      workspace_root: Path,
                      must_exist: bool = False) -> Path:
    """
    Resolve a path and verify it lives inside the workspace root.

    Args:
        raw_path: The path string (may contain ~ and environment variables).
        workspace_root: The resolved workspace root.
        must_exist: If True, raise FileNotFoundError when the path is missing.

    Returns:
        The resolved absolute Path.

    Raises:
        ValueError: if the path is empty or malformed.
        PathOutsideWorkspace: if the path is outside the workspace.
        FileNotFoundError: if must_exist and the path does not exist.
    """
    if not raw_path or not str(raw_path).strip():
        raise ValueError("Empty path.")

    try:
        candidate = Path(str(raw_path)).expanduser().resolve(strict=False)
    except (OSError, RuntimeError) as e:
        raise ValueError(f"Invalid path: {raw_path} ({e})") from e

    root = workspace_root.resolve(strict=False)

    try:
        candidate.relative_to(root)
    except ValueError as e:
        raise PathOutsideWorkspace(
            f"Path is outside the workspace root ({root}): {candidate}"
        ) from e

    if must_exist and not candidate.exists():
        raise FileNotFoundError(f"Path does not exist: {candidate}")

    return candidate

def is_within(path: Path, root: Path) -> bool:
    """Non-raising version. Handy for tests."""
    try:
        path.resolve(strict=False).relative_to(root.resolve(strict=False))
        return True
    except (ValueError, OSError):
        return False

def safe_relative(base: Path, relative: str) -> Path:
    """
    Join a relative path onto a base and verify it stays inside base.

    Used by the plugin sandbox for `self.read_text("notes/todo.txt")`.

    Raises:
        PathOutsideWorkspace: if the result escapes base.
        ValueError: if `relative` is absolute.
    """
    if Path(relative).is_absolute():
        raise ValueError(f"Absolute paths are not allowed: {relative}")
    candidate = (base / relative).resolve(strict=False)
    try:
        candidate.relative_to(base.resolve(strict=False))
    except ValueError as e:
        raise PathOutsideWorkspace(
            f"Relative path escapes the workspace: {relative}"
        ) from e
    return candidate
