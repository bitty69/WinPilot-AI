"""
The built-in tools, plus the provider dispatch that ties together built-ins,
plugins, and MCP servers.

Every tool:
  - takes `cfg: Config` as its last parameter
  - returns a string (never raises; execute_tool catches everything)
  - starts its error strings with "Error: "
  - uses resolve_and_check() for any path argument
  - calls _confirm() before destructive actions

TO ADD A TOOL: see DEVELOPER_GUIDE.md, section 3.
TO ADD A PROVIDER: see INTEGRATION_GUIDE.md, part 4.
"""

import os
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Callable

from .config import Config
from .paths import PathOutsideWorkspace, resolve_and_check

# ---------------------------------------------------------------------------
# Confirmation plumbing
# ---------------------------------------------------------------------------

class CancelledByUser(Exception):
    """Raised when the user declines a confirmation prompt."""

# Injected by the GUI: (title: str, message: str) -> bool
confirm_callback: Callable[[str, str], bool] = lambda title, msg: True

def _confirm(title: str, message: str, cfg: Config) -> None:
    """Ask the user before a destructive action. Raises if they decline."""
    if not cfg.require_confirmation:
        return
    if not confirm_callback(title, message):
        raise CancelledByUser("User cancelled the action.")

def _preview(text: str, limit: int = 200) -> str:
    """First `limit` characters of text, with a marker if truncated."""
    text = text.replace("\r\n", "\n")
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n... ({len(text) - limit} more)"

# ---------------------------------------------------------------------------
# Filesystem tools
# ---------------------------------------------------------------------------

def list_directory(path: str, cfg: Config) -> str:
    """List the contents of a directory inside the workspace."""
    root = cfg.effective_workspace()
    p = resolve_and_check(path, root, must_exist=True)
    if not p.is_dir():
        return f"Error: not a directory: {p}"

    try:
        entries = sorted(p.iterdir(),
                         key=lambda x: (not x.is_dir(), x.name.lower()))
    except PermissionError:
        return f"Error: permission denied reading {p}"

    if not entries:
        return f"(empty directory: {p})"

    rows: list[str] = []
    for item in entries[:200]:
        kind = "DIR " if item.is_dir() else "FILE"
        try:
            size = item.stat().st_size
        except OSError:
            size = 0
        rows.append(f"{kind}  {item.name}  ({size} bytes)")

    if len(entries) > 200:
        rows.append(f"... ({len(entries) - 200} more entries)")
    return "\n".join(rows)

def read_file(path: str, cfg: Config, max_chars: int = 8000) -> str:
    """Read a text file inside the workspace."""
    root = cfg.effective_workspace()
    p = resolve_and_check(path, root, must_exist=True)
    if not p.is_file():
        return f"Error: not a file: {p}"
    try:
        text = p.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return f"Error reading file: {e}"
    if len(text) > max_chars:
        return text[:max_chars] + f"\n\n... [truncated, {len(text)} chars total]"
    return text

def write_file(path: str, content: str, cfg: Config) -> str:
    """Write text to a file (creates or overwrites). Asks first."""
    root = cfg.effective_workspace()
    p = resolve_and_check(path, root, must_exist=False)
    _confirm("Write file",
             f"Write {len(content)} chars to:\n{p}\n\nPreview:\n{_preview(content)}",
             cfg)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"Wrote {len(content)} chars to {p}"
    except Exception as e:
        return f"Error writing file: {e}"

def move_file(src: str, dst: str, cfg: Config) -> str:
    """Move or rename a file or folder. Asks first."""
    root = cfg.effective_workspace()
    s = resolve_and_check(src, root, must_exist=True)
    d = resolve_and_check(dst, root, must_exist=False)
    _confirm("Move", f"Move:\n{s}\n→\n{d}", cfg)
    try:
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(s), str(d))
        return f"Moved {s} -> {d}"
    except Exception as e:
        return f"Error moving: {e}"

def delete_path(path: str, cfg: Config) -> str:
    """Delete a file or folder recursively. Asks first."""
    root = cfg.effective_workspace()
    p = resolve_and_check(path, root, must_exist=True)
    _confirm("Delete", f"Permanently delete:\n{p}", cfg)
    try:
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink()
        return f"Deleted {p}"
    except Exception as e:
        return f"Error deleting: {e}"

def search_files(root_path: str, pattern: str, cfg: Config,
                 max_results: int = 50) -> str:
    """Recursively find files matching a glob pattern."""
    root = cfg.effective_workspace()
    base = resolve_and_check(root_path, root, must_exist=True)
    if not base.is_dir():
        return f"Error: not a directory: {base}"

    results: list[str] = []
    try:
        for match in base.rglob(pattern):
            results.append(str(match))
            if len(results) >= max_results:
                break
    except Exception as e:
        return f"Error searching: {e}"

    if not results:
        return f"No files matching '{pattern}' under {base}"
    suffix = (f"\n... (capped at {max_results})"
              if len(results) >= max_results else "")
    return "\n".join(results) + suffix

# ---------------------------------------------------------------------------
# Shell tool (Windows only)
# ---------------------------------------------------------------------------

def run_command(command: str, cfg: Config, timeout: int = 30) -> str:
    """Run a PowerShell command. Asks first. Windows only."""
    if sys.platform != "win32":
        return "Error: shell execution is only supported on Windows."

    _confirm("Run command", f"Run this PowerShell command?\n\n{command}", cfg)

    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        proc = subprocess.Popen(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", command],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            creationflags=creationflags,
        )
    except Exception as e:
        return f"Error launching command: {e}"

    try:
        out, err = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.kill()
        out, err = proc.communicate()
        return f"Error: command timed out after {timeout}s.\n{out}\n{err}"

    parts: list[str] = []
    if out and out.strip():
        parts.append(out.strip())
    if err and err.strip():
        parts.append(f"[stderr]\n{err.strip()}")
    if proc.returncode != 0:
        parts.append(f"[exit code {proc.returncode}]")
    return "\n".join(parts) if parts else "(no output)"

# ---------------------------------------------------------------------------
# System info
# ---------------------------------------------------------------------------

def system_info(cfg: Config) -> str:
    """Get OS, disk, user, and workspace info."""
    import platform
    lines = [
        f"OS: {platform.system()} {platform.release()} ({platform.version()})",
        f"Machine: {platform.machine()}",
        f"Python: {platform.python_version()}",
        f"CWD: {os.getcwd()}",
        f"User: {os.environ.get('USERNAME') or os.environ.get('USER') or 'unknown'}",
        f"Workspace root: {cfg.effective_workspace()}",
    ]
    try:
        total, used, free = shutil.disk_usage(os.getcwd())
        lines.append(
            f"Disk (CWD): {free // (1024 ** 3)} GB free / "
            f"{total // (1024 ** 3)} GB total"
        )
    except Exception:
        pass
    return "\n".join(lines)

def current_time(cfg: Config) -> str:
    """Get the current date and time."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S (%A)")

# ---------------------------------------------------------------------------
# Scheduled tasks (Windows only)
# ---------------------------------------------------------------------------

_TASK_NAME_RE = re.compile(r"^[A-Za-z0-9_\- ]{1,64}$")

def create_scheduled_task(name: str, command: str, schedule: str,
                          cfg: Config) -> str:
    """
    Create a Windows scheduled task.

    `schedule` format:
        'daily HH:MM'
        'weekly DAY HH:MM'
        'once YYYY-MM-DD HH:MM'
    """
    if sys.platform != "win32":
        return "Error: scheduled tasks are only supported on Windows."
    if not _TASK_NAME_RE.match(name):
        return ("Error: task name may only contain letters, digits, spaces, "
                "hyphens, and underscores (max 64 chars).")

    _confirm("Create scheduled task",
             f"Create task '{name}'\nSchedule: {schedule}\nCommand: {command}",
             cfg)

    parts = schedule.strip().split()
    if not parts:
        return "Error: schedule must look like 'daily 09:00'."

    quoted = f'"{command}"'

    if parts[0] == "daily" and len(parts) == 2:
        args = ["schtasks", "/Create", "/TN", name, "/TR", quoted,
                "/SC", "DAILY", "/ST", parts[1], "/F"]
    elif parts[0] == "weekly" and len(parts) == 3:
        args = ["schtasks", "/Create", "/TN", name, "/TR", quoted,
                "/SC", "WEEKLY", "/D", parts[1].upper(), "/ST", parts[2], "/F"]
    elif parts[0] == "once" and len(parts) == 3:
        args = ["schtasks", "/Create", "/TN", name, "/TR", quoted,
                "/SC", "ONCE", "/SD", parts[1], "/ST", parts[2], "/F"]
    else:
        return ("Error: unrecognised schedule. Use 'daily HH:MM', "
                "'weekly DAY HH:MM', or 'once YYYY-MM-DD HH:MM'.")

    try:
        proc = subprocess.run(
            args, capture_output=True, text=True, timeout=20,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if proc.returncode == 0:
            return f"Created scheduled task '{name}' ({schedule})."
        return f"Error: {(proc.stderr or proc.stdout).strip()}"
    except Exception as e:
        return f"Error creating task: {e}"

# ---------------------------------------------------------------------------
# Web search
# ---------------------------------------------------------------------------

def web_search(query: str, cfg: Config, max_results: int = 5) -> str:
    """Search the web. Uses ddgs, falling back to duckduckgo_search."""
    DDGS = None
    try:
        from ddgs import DDGS  # type: ignore
    except ImportError:
        try:
            from duckduckgo_search import DDGS  # type: ignore
        except ImportError:
            return "Error: no search backend installed. Run: pip install ddgs"

    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))
    except Exception as e:
        return f"Search failed: {e}"

    if not results:
        return "No results."

    lines = []
    for r in results:
        title = r.get("title", "")
        href = r.get("href") or r.get("url", "")
        body = (r.get("body") or r.get("description") or "")[:200]
        lines.append(f"- {title}\n  {href}\n  {body}")
    return "\n".join(lines)

# ---------------------------------------------------------------------------
# Tool registry
# ---------------------------------------------------------------------------

def _schema(name: str, description: str, properties: dict,
            required: list[str] | None = None) -> dict:
    """Build an OpenAI tool schema. Keeps the registry below readable."""
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required or [],
            },
        },
    }

BUILTIN_TOOLS: dict[str, Callable] = {
    "list_directory": list_directory,
    "read_file": read_file,
    "write_file": write_file,
    "move_file": move_file,
    "delete_path": delete_path,
    "search_files": search_files,
    "run_command": run_command,
    "system_info": system_info,
    "current_time": current_time,
    "create_scheduled_task": create_scheduled_task,
    "web_search": web_search,
}

BUILTIN_SCHEMAS: dict[str, dict] = {
    "list_directory": _schema(
        "list_directory",
        "List the contents of a directory inside the workspace.",
        {"path": {"type": "string",
                  "description": "Directory path inside the workspace."}},
        ["path"]),
    "read_file": _schema(
        "read_file",
        "Read a text file inside the workspace.",
        {"path": {"type": "string", "description": "File path."}},
        ["path"]),
    "write_file": _schema(
        "write_file",
        "Write text to a file (creates or overwrites). Asks for confirmation.",
        {"path": {"type": "string"},
         "content": {"type": "string"}},
        ["path", "content"]),
    "move_file": _schema(
        "move_file",
        "Move or rename a file or folder. Asks for confirmation.",
        {"src": {"type": "string"},
         "dst": {"type": "string"}},
        ["src", "dst"]),
    "delete_path": _schema(
        "delete_path",
        "Delete a file or folder recursively. Asks for confirmation.",
        {"path": {"type": "string"}},
        ["path"]),
    "search_files": _schema(
        "search_files",
        "Recursively find files matching a glob pattern (e.g. '*.pdf').",
        {"root_path": {"type": "string"},
         "pattern": {"type": "string"}},
        ["root_path", "pattern"]),
    "run_command": _schema(
        "run_command",
        "Run a PowerShell command. Asks for confirmation.",
        {"command": {"type": "string"}},
        ["command"]),
    "system_info": _schema(
        "system_info",
        "Get OS, disk, user, and workspace info.",
        {}),
    "current_time": _schema(
        "current_time",
        "Get the current date and time.",
        {}),
    "create_scheduled_task": _schema(
        "create_scheduled_task",
        ("Create a Windows scheduled task. Schedule formats: "
         "'daily HH:MM', 'weekly DAY HH:MM', 'once YYYY-MM-DD HH:MM'."),
        {"name": {"type": "string"},
         "command": {"type": "string"},
         "schedule": {"type": "string"}},
        ["name", "command", "schedule"]),
    "web_search": _schema(
        "web_search",
        "Search the web for current information.",
        {"query": {"type": "string"}},
        ["query"]),
}

# ---------------------------------------------------------------------------
# Provider dispatch
# ---------------------------------------------------------------------------

def _provider_plugins():
    """Late import; returns the plugins module or None."""
    try:
        from . import plugins
        return plugins
    except Exception:
        return None

def _provider_mcp():
    """Late import; returns the mcp_client module or None."""
    try:
        from . import mcp_client
        return mcp_client
    except Exception:
        return None

def execute_tool(name: str, args: dict, cfg: Config) -> str:
    """
    Run a tool by name. Never raises — returns an error string instead.

    Looks in BUILTIN_TOOLS first, then plugins, then MCP. The order is
    deliberate: built-ins cannot be shadowed.
    """
    func = BUILTIN_TOOLS.get(name)

    if func is None:
        plugins = _provider_plugins()
        if plugins is not None:
            func = plugins.get_plugin_tool(name)

    if func is None:
        mcp = _provider_mcp()
        if mcp is not None:
            func = mcp.get_mcp_tool(name)

    if func is None:
        return f"Error: unknown tool '{name}'."

    try:
        return str(func(**args, cfg=cfg))
    except CancelledByUser as e:
        return f"Cancelled: {e}"
    except PathOutsideWorkspace as e:
        return f"Error: {e}"
    except FileNotFoundError as e:
        return f"Error: {e}"
    except TypeError as e:
        return f"Error: bad arguments to {name}: {e}"
    except Exception as e:
        return f"Error running {name}: {type(e).__name__}: {e}"

def tool_schemas() -> list[dict]:
    """Return schemas for all built-in tools plus plugins plus MCP."""
    schemas = list(BUILTIN_SCHEMAS.values())

    plugins = _provider_plugins()
    if plugins is not None:
        try:
            schemas.extend(plugins.get_plugin_schemas())
        except Exception:
            pass

    mcp = _provider_mcp()
    if mcp is not None:
        try:
            schemas.extend(mcp.get_mcp_schemas())
        except Exception:
            pass

    return schemas
