"""
Local model management.

Currently wraps the Ollama HTTP API for listing, pulling, and deleting
models. To add another backend (LM Studio, llama.cpp server), subclass
`LocalModelBackend` and register it in BACKENDS.

All calls are best-effort: if the server is unreachable, methods return
empty results or error strings rather than raising.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Callable, Optional

# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------

@dataclass
class ModelInfo:
    name: str
    size_bytes: int = 0
    modified: str = ""
    digest: str = ""

    def size_human(self) -> str:
        """Human-readable size, e.g. '4.1 GB'."""
        n = float(self.size_bytes)
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if n < 1024:
                return f"{n:.1f} {unit}"
            n /= 1024
        return f"{n:.1f} PB"

# ---------------------------------------------------------------------------
# Abstract backend
# ---------------------------------------------------------------------------

class LocalModelBackend(ABC):
    """A local model server (Ollama, LM Studio, ...)."""

    name: str = "abstract"
    base_url: str = ""

    @abstractmethod
    def is_available(self) -> bool:
        """Return True if the server is reachable."""

    @abstractmethod
    def list_models(self) -> list[ModelInfo]:
        """Return the installed models. Empty on failure."""

    @abstractmethod
    def pull_model(self, name: str,
                   progress_cb: Optional[Callable[[str], None]] = None
                   ) -> tuple[bool, str]:
        """Download a model. Returns (ok, message)."""

    @abstractmethod
    def delete_model(self, name: str) -> tuple[bool, str]:
        """Delete a model. Returns (ok, message)."""

# ---------------------------------------------------------------------------
# Ollama
# ---------------------------------------------------------------------------

class OllamaBackend(LocalModelBackend):
    name = "ollama"
    base_url = "http://localhost:11434"

    def __init__(self, base_url: str = ""):
        if base_url:
            self.base_url = base_url.rstrip("/")

    # -- helpers -----------------------------------------------------------

    def _get_json(self, path: str, timeout: float = 5.0) -> Optional[dict]:
        """GET and parse JSON. Returns None on any failure."""
        try:
            req = urllib.request.Request(
                f"{self.base_url}{path}",
                headers={"Accept": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except (urllib.error.URLError, json.JSONDecodeError, OSError,
                ValueError):
            return None

    def _post_json(self, path: str, payload: dict,
                   timeout: float = 300.0) -> Optional[dict]:
        """POST JSON and parse the response. Returns None on failure."""
        try:
            body = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                f"{self.base_url}{path}",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except (urllib.error.URLError, json.JSONDecodeError, OSError,
                ValueError):
            return None

    def _delete(self, path: str, payload: dict,
                timeout: float = 30.0) -> bool:
        try:
            body = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                f"{self.base_url}{path}",
                data=body,
                headers={"Content-Type": "application/json"},
                method="DELETE",
            )
            with urllib.request.urlopen(req, timeout=timeout):
                return True
        except (urllib.error.URLError, OSError, ValueError):
            return False

    # -- API ---------------------------------------------------------------

    def is_available(self) -> bool:
        return self._get_json("/api/tags", timeout=2.0) is not None

    def list_models(self) -> list[ModelInfo]:
        data = self._get_json("/api/tags")
        if not data:
            return []
        models = data.get("models", [])
        if not isinstance(models, list):
            return []

        out: list[ModelInfo] = []
        for m in models:
            if not isinstance(m, dict):
                continue
            out.append(ModelInfo(
                name=m.get("name", ""),
                size_bytes=int(m.get("size", 0) or 0),
                modified=m.get("modified_at", "") or "",
                digest=m.get("digest", "") or "",
            ))
        out.sort(key=lambda x: x.name)
        return out

    def pull_model(self, name: str,
                   progress_cb: Optional[Callable[[str], None]] = None
                   ) -> tuple[bool, str]:
        """
        Pull a model.

        Ollama streams progress as newline-delimited JSON. We read it line
        by line and forward the status field to progress_cb if given.
        """
        if not name.strip():
            return False, "Model name is empty."

        payload = {"name": name.strip(), "stream": True}
        try:
            body = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                f"{self.base_url}/api/pull",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=3600.0) as resp:
                for raw_line in resp:
                    line = raw_line.decode("utf-8", errors="replace").strip()
                    if not line:
                        continue
                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if progress_cb:
                        status = event.get("status", "")
                        if status:
                            progress_cb(status)
                    if event.get("error"):
                        return False, str(event["error"])
            return True, f"Pulled '{name}'."
        except urllib.error.URLError as e:
            return False, f"Could not reach Ollama: {e}"
        except Exception as e:
            return False, f"{type(e).__name__}: {e}"

    def delete_model(self, name: str) -> tuple[bool, str]:
        if not name.strip():
            return False, "Model name is empty."
        ok = self._delete("/api/delete", {"name": name.strip()})
        if ok:
            return True, f"Deleted '{name}'."
        return False, f"Could not delete '{name}'."

# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

BACKENDS: dict[str, type[LocalModelBackend]] = {
    "ollama": OllamaBackend,
}

def get_backend(name: str = "ollama") -> Optional[LocalModelBackend]:
    """Instantiate a backend by name. Returns None for unknown names."""
    cls = BACKENDS.get(name)
    if cls is None:
        return None
    try:
        return cls()
    except Exception:
        return None

def get_backend_names() -> list[str]:
    return sorted(BACKENDS.keys())

def any_available() -> tuple[bool, str]:
    """Return (available, reason). Checks every registered backend."""
    for name, cls in BACKENDS.items():
        try:
            backend = cls()
            if backend.is_available():
                return True, name
        except Exception:
            continue
    return False, (
        "No local model server found. Is Ollama running? "
        "Start it with: ollama serve"
    )
