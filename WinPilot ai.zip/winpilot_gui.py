#!/usr/bin/env python3
"""
WinPilot GUI — entry point.

Checks Tkinter exists, then starts the app. All real code lives in the
`winpilot` package.
"""

import sys
from pathlib import Path

# Allow running this file directly from any directory.
sys.path.insert(0, str(Path(__file__).parent))

def _check_tkinter() -> bool:
    try:
        import tkinter  # noqa: F401
        return True
    except ImportError:
        print(
            "Tkinter is not available in this Python build.\n"
            "On Windows: reinstall Python and tick 'tcl/tk and IDLE'.",
            file=sys.stderr,
        )
        return False

def main() -> int:
    if not _check_tkinter():
        return 1

    from winpilot.gui import WinPilotApp
    app = WinPilotApp()
    app.mainloop()
    return 0

if __name__ == "__main__":
    sys.exit(main())
