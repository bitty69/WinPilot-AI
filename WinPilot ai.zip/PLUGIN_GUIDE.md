# WinPilot Plugin Guide

A plugin adds new tools the agent can call. If you can write a Python class
with a method, you can write a plugin.

**Read the safety section first.** Plugins are sandboxed on purpose.

---

## 1. The 60-second version

Create `~/.winpilot/plugins/hello_plugin.py`:

```python
from winpilot.plugins import PluginBase, tool

class HelloPlugin(PluginBase):
    name = "hello"
    version = "1.0.0"
    author = "your name"
    description = "A tiny greeting plugin."

    @tool(
        description="Say hello to a person by name.",
        parameters={
            "who": {"type": "string", "description": "The name to greet."}
        },
        required=["who"],
    )
    def say_hello(self, who: str) -> str:
        return f"Hello, {who}!"
```

Save it. In WinPilot, click **Reload plugins**. The agent can now call
`hello__say_hello`. Ask it: *"say hello to Alice"*.

---

## 2. Single file vs folder

**Single file** — just `my_plugin.py`. Fast to write.

**Folder** — for plugins with data files or a manifest:

```
~/.winpilot/plugins/my_plugin/
    plugin.json
    code.py
```

`plugin.json`:

```
{
  "name": "my_plugin",
  "version": "1.0.0",
  "author": "your name",
  "description": "What it does.",
  "entry": "code.py"
}
```

---

## 3. The `@tool` decorator

```
@tool(
    description="One sentence the LLM reads to decide when to call it.",
    parameters={
        "arg_name": {
            "type": "string",          # string | integer | number | boolean | array | object
            "description": "What this argument means.",
        },
    },
    required=["arg_name"],
    destructive=False,                 # if True, the user confirms first
)
def my_method(self, arg_name: str) -> str:
    ...
```

### Rules

- **Return a string.** Always.
- Start with `"Error: "` on failure.
- Don't raise exceptions — catch them and return an error string.
- Keep it fast. There is a 10-second timeout per call.
- Write a specific `description`. Vague ones never get called.

---

## 4. Naming

`{plugin.name}__{method_name}`, e.g. `hello__say_hello`. The double
underscore avoids collisions with built-ins and MCP tools.

---

## 5. Safety: what you CAN and CANNOT do

### You CAN

- Import: `json`, `re`, `math`, `datetime`, `collections`, `itertools`,
`functools`, `textwrap`, `uuid`, `hashlib`, `base64`, `csv`, `io`,
`typing`, `dataclasses`, `enum`, `random`, `string`, plus a few more
- Use `self.workspace` (a `Path`) and `self.config`
- Read/write files **inside the workspace** via the helpers
- Call `self.run_powershell(...)` (asks the user first)
- Call `self.log("...")`

### You CANNOT

- Import `os`, `sys`, `subprocess`, `socket`, `shutil`, `pathlib`,
`ctypes`, `winreg`, `threading`, `requests`, `urllib`, `http`, ...
- Use `open()` directly
- Access the network
- Spawn processes
- Read or write outside the workspace

### Workspace helpers

```
self.read_text("notes/todo.txt")
self.write_text("notes/todo.txt", "hi")
self.exists("notes/todo.txt")
self.list_files("notes")
self.delete_file("notes/old.txt")       # asks the user first
self.run_powershell("Get-Date")         # asks the user first
```

All paths are relative to the workspace root and checked. `../` escapes are
rejected.

### When to ask the user

Set `destructive=True` in the decorator for anything that modifies or
deletes data. The user gets a Yes/No dialog before your method runs.

---

## 6. Three complete examples

See `plugins_examples/`:

- `clipboard_plugin.py` — PowerShell clipboard
- `screenshot_plugin.py` — capture the screen to a PNG
- `notes_plugin/` — folder format, JSON storage

---

## 7. Hot reload

The plugin folder is scanned at startup and whenever you click
**Reload plugins** (or `Ctrl+R`, or `/reload`). Reloading unloads all
plugins and re-imports them fresh. A broken plugin is skipped, the error
appears in the tool log, and the others still load.

---

## 8. Debugging

**The plugin doesn't appear:** check the file is in
`~/.winpilot/plugins/`, ends in `.py`, defines exactly one `PluginBase`
subclass with at least one `@tool` method, and check the tool log for load
errors.

**The tool appears but the LLM never calls it:** rewrite the `description`.
Make it specific.

**The tool raises:** catch your own exceptions and return `"Error: ..."`.
Use `self.log(...)` to trace values. Run `python -m winpilot.selftest` — it
loads every plugin and reports.

**Timeout:** calls are limited to 10 seconds. Do long work in chunks.

---

## 9. Limitations

- **No cross-file imports in folder plugins.** Keep everything in
`code.py`.
- **No network.**
- **No background work.** No timers, threads, or callbacks.
- **No persistent in-memory state** you can rely on across reloads.
Persist to a file in the workspace.
- **No GUI.** Return text; the agent shows it.

---

## 10. Checklist

- □  
Class inherits `PluginBase`
- □  
`name`, `version`, `description` set
- □  
Every tool has a clear one-sentence `description`
- □  
Every tool returns a string
- □  
Every tool catches its own errors
- □  
Destructive tools use `destructive=True`
- □  
No forbidden imports
- □  
Tested with `python -m winpilot.selftest`
- □  
Tried in the app with **Reload plugins**

---

## 11. API reference

```
class PluginBase:
    name: str = ""
    version: str = "1.0.0"
    author: str = ""
    description: str = ""

    # Set by the loader:
    workspace: Path
    config: Config

    # Helpers:
    def log(self, message: str) -> None: ...
    def read_text(self, relative_path: str) -> str: ...
    def write_text(self, relative_path: str, content: str) -> None: ...
    def exists(self, relative_path: str) -> bool: ...
    def list_files(self, relative_dir: str = ".") -> list[Path]: ...
    def delete_file(self, relative_path: str) -> None: ...
    def run_powershell(self, script: str, timeout: int = 10) -> str: ...

def tool(description, parameters=None, required=None, destructive=False):
    """Decorator. Marks a method as a callable tool."""
```

