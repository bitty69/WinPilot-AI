# WinPilot Integration Guide

How to add MCP servers, voice engines, and local model backends.

---

## Part 1 — MCP servers

### What MCP is

Model Context Protocol is a standard for exposing tools to an LLM. An MCP
server is a small program that advertises a list of tools and runs them when
asked. WinPilot acts as an MCP *client*: it connects to servers, lists their
tools, and makes them available to the agent.

### The config file

`~/.winpilot/mcp_servers.json`:

```json
{
  "servers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "C:\\Users\\me\\Documents"],
      "enabled": true
    },
    "remote-docs": {
      "url": "https://example.com/mcp",
      "enabled": true
    }
  }
}
```

**Stdio servers** have a `command` and optional `args` and `env`. WinPilot
spawns them as subprocesses and talks over stdin/stdout.

**HTTP servers** have a `url`. WinPilot connects over streamable HTTP.

Both can set `"enabled": false` to be skipped without deleting the entry.

### How tools appear

An MCP server's tools are prefixed with the server name:

```
filesystem__read_file
filesystem__write_file
remote-docs__search
```

The double underscore avoids collisions with built-ins and plugins.

### The confirmation gate

MCP tools run through the same confirmation system as built-in tools. If the
agent tries to call an MCP tool that modifies state, the user sees a dialog.
You can mark specific servers as `"trusted": true` to skip confirmation for
their tools (use this only for servers you wrote yourself).

### Adding a server

1. Edit `~/.winpilot/mcp_servers.json` (the app creates a template on first
launch if the file is missing).
2. In WinPilot, click **Reload MCP** (or `Ctrl+M`, or `/reload-mcp`).
3. Check the tool log for the connection result.
4. Ask the agent to use the new tool.

### Debugging a server

- **"command not found"** — the `command` is not on PATH. Use an absolute
path, or install the prerequisite (Node, Python, etc.).
- **"connection timed out"** — the server started but didn't respond. Test it
manually outside WinPilot first.
- **"no tools advertised"** — the server connected but returned an empty tool
list. Check the server's own logs.
- **Tools appear but calls fail** — the server's tool schemas may not match
its actual behaviour. Report it upstream.

### Writing your own MCP server

Any language works. The official Python SDK is
`pip install mcp`. A minimal server:

```
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

app = Server("my-server")

@app.list_tools()
async def list_tools():
    return [Tool(
        name="greet",
        description="Say hello.",
        inputSchema={
            "type": "object",
            "properties": {"who": {"type": "string"}},
            "required": ["who"],
        },
    )]

@app.call_tool()
async def call_tool(name, arguments):
    if name == "greet":
        return [TextContent(type="text", text=f"Hello, {arguments['who']}!")]
    raise ValueError(f"Unknown tool: {name}")

async def main():
    async with stdio_server() as (r, w):
        await app.run(r, w, app.create_initialization_options())

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
```

---

## Part 2 — Voice

### What ships

- **STT**: `faster-whisper` (OpenAI Whisper, CPU-friendly)
- **TTS**: `piper-tts` (fast, small, natural-sounding)

Both are optional dependencies. If they're not installed, the mic button and
"Speak responses" checkbox are disabled with a tooltip explaining why.

### Installing voice support

```
python -m pip install faster-whisper piper-tts sounddevice numpy
```

On first use, `faster-whisper` downloads a small model (~40 MB for `tiny`,
~150 MB for `base`). `piper-tts` downloads a voice (~20 MB).

### Configuring voice

Settings → Voice:

- **STT engine**: `faster-whisper` (default) or `disabled`
- **STT model**: `tiny`, `base`, `small`, `medium`
- **TTS engine**: `piper` (default) or `disabled`
- **TTS voice**: a list fetched from Piper's voice catalog
- **Speak responses**: read every final answer aloud
- **Push-to-talk key**: default `Ctrl+Space`

### Adding a new STT engine

Subclass `STTEngine` in `voice.py`:

```
class MySTT(STTEngine):
    name = "my-stt"

    def transcribe(self, audio_path: Path) -> str:
        # Return the transcribed text.
        ...
```

Register it in the `STT_ENGINES` dict. The Settings dropdown picks it up.

### Adding a new TTS engine

Same pattern with `TTSEngine`:

```
class MyTTS(TTSEngine):
    name = "my-tts"

    def speak(self, text: str) -> None:
        # Block until playback finishes.
        ...
```

---

## Part 3 — Local models

### What it does

The **Models** dialog lists Ollama models installed on your machine, lets you
pull new ones, delete old ones, and see disk usage. It talks to Ollama's HTTP
API at `http://localhost:11434`.

### Adding another backend

`local_models.py` defines `LocalModelBackend`:

```
class LocalModelBackend:
    name: str

    def list_models(self) -> list[ModelInfo]: ...
    def pull_model(self, name: str, progress_cb) -> None: ...
    def delete_model(self, name: str) -> None: ...
    def is_available(self) -> bool: ...
```

Subclass it for LM Studio, llama.cpp server, or anything else with a similar
API. Register in `BACKENDS`. The GUI reads `local_models.get_backends()`.

---

## Part 4 — The provider pattern

Any new source of tools follows the same three steps:

1. Write a module with:

- `get_<provider>_tool(name: str) -> Callable | None`
- `get_<provider>_schemas() -> list[dict]`
- A `load_<provider>(cfg) -> None` to (re)build the registry
2. Wire it into `tools.py`:

```
def execute_tool(name, args, cfg):
    func = BUILTIN_TOOLS.get(name)
    if func is None:
        func = plugins.get_plugin_tool(name)
    if func is None:
        func = mcp_client.get_mcp_tool(name)
    if func is None:
        func = my_new_provider.get_tool(name)   # <- add this
    ...
```

```
def tool_schemas():
    schemas = list(BUILTIN_SCHEMAS.values())
    schemas.extend(plugins.get_plugin_schemas())
    schemas.extend(mcp_client.get_mcp_schemas())
    schemas.extend(my_new_provider.get_schemas())   # <- and this
    return schemas
```
3. Add a self-test suite. See `selftest.py` for the pattern.

That's the whole protocol. The agent loop never changes.

