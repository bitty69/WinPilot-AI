"""
Example plugin — clipboard.

Copy this file to ~/.winpilot/plugins/ to use it.
"""

from winpilot.plugins import PluginBase, tool

class ClipboardPlugin(PluginBase):
    name = "clipboard"
    version = "1.0.0"
    author = "WinPilot examples"
    description = "Read and write the Windows clipboard."

    @tool(
        description="Read the current text on the Windows clipboard.",
        parameters={},
        required=[],
        destructive=False,
    )
    def read_clipboard(self) -> str:
        try:
            out = self.run_powershell("Get-Clipboard -Raw", timeout=5)
        except Exception as e:
            return f"Error reading clipboard: {e}"
        if out.startswith("Error"):
            return out
        if not out:
            return "(clipboard is empty)"
        return out

    @tool(
        description="Put text onto the Windows clipboard.",
        parameters={
            "text": {
                "type": "string",
                "description": "The text to place on the clipboard.",
            }
        },
        required=["text"],
        destructive=True,
    )
    def write_clipboard(self, text: str) -> str:
        if not isinstance(text, str):
            return "Error: 'text' must be a string."
        if len(text) > 100_000:
            return "Error: text is too large for the clipboard."

        escaped = text.replace("'", "''")
        script = f"Set-Clipboard -Value '{escaped}'"

        try:
            out = self.run_powershell(script, timeout=5)
        except Exception as e:
            return f"Error writing clipboard: {e}"
        if out.startswith("Error"):
            return out
        return f"Copied {len(text)} chars to the clipboard."

    @tool(
        description="Get the number of characters currently on the clipboard.",
        parameters={},
        required=[],
        destructive=False,
    )
    def clipboard_length(self) -> str:
        try:
            out = self.run_powershell(
                "(Get-Clipboard -Raw | Measure-Object -Character).Characters",
                timeout=5,
            )
        except Exception as e:
            return f"Error: {e}"
        if out.startswith("Error"):
            return out
        return f"Clipboard holds {out.strip() or '0'} characters."
