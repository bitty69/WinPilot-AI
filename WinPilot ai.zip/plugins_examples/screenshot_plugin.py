"""
Example plugin — screenshot.

Copy this file to ~/.winpilot/plugins/ to use it.
"""

from datetime import datetime

from winpilot.plugins import PluginBase, tool

class ScreenshotPlugin(PluginBase):
    name = "screenshot"
    version = "1.0.0"
    author = "WinPilot examples"
    description = "Capture the screen to a PNG file in the workspace."

    @tool(
        description=(
            "Take a screenshot of the primary screen and save it as a PNG "
            "in the workspace under 'screenshots/'. Returns the file path."
        ),
        parameters={
            "filename": {
                "type": "string",
                "description": (
                    "Optional file name (without extension). "
                    "Defaults to a timestamp."
                ),
            }
        },
        required=[],
        destructive=False,
    )
    def capture_screen(self, filename: str = "") -> str:
        if filename:
            stem = "".join(c for c in filename
                           if c.isalnum() or c in "-_ ")
            stem = stem.strip().replace(" ", "_")[:60]
        else:
            stem = ""
        if not stem:
            stem = "screenshot_" + datetime.now().strftime("%Y%m%d_%H%M%S")

        relative = f"screenshots/{stem}.png"
        target = str(self.workspace / "screenshots" / f"{stem}.png")
        target_ps = target.replace("'", "''")

        script = (
            "Add-Type -AssemblyName System.Windows.Forms;"
            "Add-Type -AssemblyName System.Drawing;"
            "$b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds;"
            "$bmp = New-Object System.Drawing.Bitmap $b.Width, $b.Height;"
            "$g = [System.Drawing.Graphics]::FromImage($bmp);"
            "$g.CopyFromScreen($b.Location, [System.Drawing.Point]::Empty, $b.Size);"
            f"$bmp.Save('{target_ps}', [System.Drawing.Imaging.ImageFormat]::Png);"
            "$g.Dispose();"
            "$bmp.Dispose();"
            "Write-Output 'OK'"
        )

        try:
            out = self.run_powershell(script, timeout=15)
        except Exception as e:
            return f"Error capturing screen: {e}"

        if out.startswith("Error"):
            return out
        if not self.exists(relative):
            return f"Error: screenshot was not written. PowerShell said: {out}"

        size = (self.workspace / relative).stat().st_size
        return f"Saved screenshot to {relative} ({size // 1024} KB)."

    @tool(
        description="List the screenshots saved in the workspace.",
        parameters={},
        required=[],
        destructive=False,
    )
    def list_screenshots(self) -> str:
        if not self.exists("screenshots"):
            return "No screenshots yet."
        files = [p for p in self.list_files("screenshots")
                 if p.suffix.lower() == ".png"]
        if not files:
            return "No screenshots yet."
        lines = [f"{p.name}  ({p.stat().st_size // 1024} KB)" for p in files]
        return "\n".join(lines)
