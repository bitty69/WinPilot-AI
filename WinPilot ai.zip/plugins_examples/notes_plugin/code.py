"""
Example plugin — notes (folder format).

Copy the whole folder to ~/.winpilot/plugins/ to use it.
"""

import json
from datetime import datetime

from winpilot.plugins import PluginBase, tool

NOTES_FILE = "notes/notes.json"

class NotesPlugin(PluginBase):
    name = "notes"
    version = "1.0.0"
    author = "WinPilot examples"
    description = "Save, list, search, and delete short notes."

    def _load(self) -> list[dict]:
        if not self.exists(NOTES_FILE):
            return []
        try:
            raw = self.read_text(NOTES_FILE)
            data = json.loads(raw)
            if isinstance(data, list):
                return data
        except Exception:
            pass
        return []

    def _save(self, notes: list[dict]) -> None:
        self.write_text(NOTES_FILE, json.dumps(notes, indent=2))

    @tool(
        description="Save a new note with optional tags.",
        parameters={
            "text": {"type": "string", "description": "The note body."},
            "tag": {
                "type": "string",
                "description": "Optional single tag, e.g. 'work'.",
            },
        },
        required=["text"],
        destructive=False,
    )
    def add_note(self, text: str, tag: str = "") -> str:
        if not text or not text.strip():
            return "Error: note text cannot be empty."
        if len(text) > 4000:
            return "Error: note is too long (max 4000 chars)."

        notes = self._load()
        notes.append({
            "id": len(notes) + 1,
            "text": text.strip(),
            "tag": (tag or "").strip(),
            "created": datetime.now().isoformat(timespec="seconds"),
        })
        self._save(notes)
        return f"Saved note #{notes[-1]['id']} ({len(notes)} total)."

    @tool(
        description="List all saved notes, newest first.",
        parameters={},
        required=[],
        destructive=False,
    )
    def list_notes(self) -> str:
        notes = self._load()
        if not notes:
            return "No notes saved yet."
        lines = []
        for n in reversed(notes):
            tag = f" [{n['tag']}]" if n.get("tag") else ""
            text = n["text"].replace("\n", " ")
            if len(text) > 80:
                text = text[:79] + "…"
            lines.append(f"#{n['id']}{tag} {n['created']}: {text}")
        return "\n".join(lines)

    @tool(
        description="Search saved notes for a keyword or phrase.",
        parameters={
            "query": {"type": "string", "description": "Text to search for."}
        },
        required=["query"],
        destructive=False,
    )
    def search_notes(self, query: str) -> str:
        if not query or not query.strip():
            return "Error: query cannot be empty."
        needle = query.lower()
        notes = self._load()
        hits = [n for n in notes
                if needle in n["text"].lower()
                or needle in (n.get("tag") or "").lower()]
        if not hits:
            return f"No notes match '{query}'."
        lines = [f"#{n['id']} [{n.get('tag') or '-'}] {n['text'][:100]}"
                 for n in hits]
        return "\n".join(lines)

    @tool(
        description="Delete a note by its number. Asks for confirmation.",
        parameters={
            "note_id": {"type": "integer", "description": "The note number."}
        },
        required=["note_id"],
        destructive=True,
    )
    def delete_note(self, note_id: int) -> str:
        try:
            note_id = int(note_id)
        except (TypeError, ValueError):
            return "Error: note_id must be an integer."

        notes = self._load()
        remaining = [n for n in notes if n["id"] != note_id]
        if len(remaining) == len(notes):
            return f"Error: no note with number {note_id}."
        self._save(remaining)
        return f"Deleted note #{note_id} ({len(remaining)} remaining)."

    @tool(
        description="Count the saved notes and list the tags in use.",
        parameters={},
        required=[],
        destructive=False,
    )
    def notes_summary(self) -> str:
        notes = self._load()
        if not notes:
            return "No notes saved yet."
        tags: dict[str, int] = {}
        for n in notes:
            t = n.get("tag") or "(untagged)"
            tags[t] = tags.get(t, 0) + 1
        tag_lines = ", ".join(f"{t}: {c}" for t, c in sorted(tags.items()))
        return f"{len(notes)} note(s). Tags: {tag_lines}"
