# MCP Setup — Copy-Paste Configs

Ready-to-use entries for `~/.winpilot/mcp_servers.json`. Copy the ones you
want into the `"servers"` object.

The app creates the file with a template on first launch. Open it with
**File → Open config folder**, then edit `mcp_servers.json`.

---

## Filesystem access (Node)

Lets the agent read and write a specific directory through the official
filesystem server. Requires Node.js.

```json
"filesystem": {
  "command": "npx",
  "args": ["-y", "@modelcontextprotocol/server-filesystem", "C:\\Users\\YOURNAME\\Documents"],
  "enabled": true
}
```

---

## Git repository access (Python)

Read git history, diffs, and commit metadata.

```
"git": {
  "command": "uvx",
  "args": ["mcp-server-git", "--repository", "C:\\path\\to\\repo"],
  "enabled": true
}
```

Requires `uv` (`pip install uv`).

---

## SQLite database queries (Python)

Run read-only SQL against a SQLite file.

```
"sqlite": {
  "command": "uvx",
  "args": ["mcp-server-sqlite", "--db-path", "C:\\path\\to\\data.db"],
  "enabled": true
}
```

---

## Fetch a web page (Python)

Download and convert a URL to markdown. Requires `uv`.

```
"fetch": {
  "command": "uvx",
  "args": ["mcp-server-fetch"],
  "enabled": true
}
```

---

## Current documentation lookup (Node)

The **Context7** server pulls up-to-date library docs so the agent stops
hallucinating APIs.

```
"context7": {
  "command": "npx",
  "args": ["-y", "@upstash/context7-mcp"],
  "enabled": true
}
```

---

## Semantic code editing (Python)

**Serena** turns the agent into a real coding assistant: symbol-level
navigation, refactoring, cross-file edits via language servers.

```
"serena": {
  "command": "uvx",
  "args": ["--from", "git+https://github.com/oraios/serena", "serena", "start-mcp-server"],
  "enabled": true
}
```

---

## Sandboxed code execution (Python)

Run code in an isolated environment instead of using `run_command`.

```
"coderunner": {
  "command": "uvx",
  "args": ["mcp-server-coderunner"],
  "enabled": true
}
```

---

## Remote HTTP server

Any server that speaks streamable HTTP:

```
"my-remote": {
  "url": "https://mcp.example.com/v1",
  "enabled": true
}
```

---

## Full example

`~/.winpilot/mcp_servers.json`:

```
{
  "servers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "C:\\Users\\me\\Documents"],
      "enabled": true
    },
    "fetch": {
      "command": "uvx",
      "args": ["mcp-server-fetch"],
      "enabled": true
    },
    "sqlite": {
      "command": "uvx",
      "args": ["mcp-server-sqlite", "--db-path", "C:\\Users\\me\\data.db"],
      "enabled": false
    }
  }
}
```

After editing, click **Reload MCP** in WinPilot. Connection results appear in
the tool log.

---

## Troubleshooting

| Symptom ↕▾ | Fix ↕▾ |
|---|---|
| −`command not found: npx` | Install Node.js from nodejs.org |
| −`command not found: uvx` | `pip install uv` |
| −`command not found: uv` | `pip install uv` |
| −Server connects but no tools | Check the server's own output; some need args |
| −Timeout on start | The server may be downloading packages on first run; wait and reload |
| −Tools appear but calls fail | Verify the server works standalone first |
⚙

## Notes

- MCP servers run with **your** user privileges. Only add servers you trust.
- The filesystem server is powerful — point it at a specific folder, not
`C:\`.
- Servers marked `"enabled": false` are skipped without being deleted.
- The agent sees MCP tools prefixed with the server name, e.g.
`filesystem__read_file`.

