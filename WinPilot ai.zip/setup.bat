@echo off
setlocal EnableDelayedExpansion

echo ============================================
echo   WinPilot Setup  v0.8
echo ============================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python not found in PATH.
    echo Install Python 3.10+ from https://www.python.org/downloads/
    echo Make sure "Add Python to PATH" is checked.
    pause
    exit /b 1
)

for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo Found Python !PYVER!
echo.

echo [1/5] Upgrading pip...
python -m pip install --upgrade pip --quiet
echo.

echo [2/5] Installing core dependencies...
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Dependency install failed.
    pause
    exit /b 1
)
echo.

echo [3/5] Verifying Tkinter...
python -c "import tkinter; print('Tkinter OK')"
if errorlevel 1 (
    echo [ERROR] Tkinter is missing. Reinstall Python with "tcl/tk and IDLE".
    pause
    exit /b 1
)
echo.

echo [4/5] Optional: install voice support?
echo   This adds ~200 MB (faster-whisper, piper-tts, sounddevice).
set /p VOICE=Install voice? [y/N]
if /i "!VOICE!"=="y" (
    python -m pip install faster-whisper piper-tts sounddevice numpy
)
echo.

echo [5/5] Running self-test...
python -m winpilot.selftest
if errorlevel 1 (
    echo.
    echo [WARN] Some self-tests failed. The app may still run.
    echo Review the output above.
    echo.
)

echo.
echo ============================================
echo   Setup complete.  Launch: python winpilot_gui.py
echo ============================================
echo.
set /p RUNNOW=Launch now? [y/N]
if /i "!RUNNOW!"=="y" (
    python winpilot_gui.py
)
pause
