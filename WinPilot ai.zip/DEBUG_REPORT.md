# v0.2 Static Trace — Bugs Found and Fixed

Nine bugs and four correctness issues found by manual trace. All fixed in
v0.3 and carried forward.

| ID | Where | What | Fix |
|----|-------|------|-----|
| C1 | gui.py | Styles installed after ttk widgets created | Install styles first |
| C2 | gui.py | `_refresh_status` ran before `self.agent` existed | Guarded; deferred |
| C3 | gui.py | `grab_set()` on unmapped window | `wait_visibility()` first |
| C4 | gui.py | First-run dialog before window mapped | `after(150, ...)` |
| C6 | gui.py | Worker died without event → UI stuck busy | `WORKER_DONE` sentinel |
| C7 | gui.py | Cancel did not stop worker | Generation counter |
| W1 | agent.py | History could end with unresolved tool_calls | Validated |
| W6 | gui.py | Switching backend wiped conversation | Preserved |
| W7 | gui.py | Redundant `<Shift-Return>` binding | Removed |

# v0.6 → v0.8 Integration Trace

Traced every new module for import cycles, signature mismatches, and
error paths.

| ID | Where | What | Fix |
|----|-------|------|-----|
| I1 | mcp_client | `_run_async` reused one loop across threads | Fresh loop per call |
| I2 | mcp_client | stdio server killed on cancel left zombie | Noted; SDK handles via context managers |
| I3 | mcp_client | `get_tool` wrapper dropped `cfg` but MCP didn't need it | Documented |
| I4 | voice | `_play_wav` assumed sounddevice present | Falls back to winsound |
| I5 | voice | Piper download API differs by version | Best-effort with clear error |
| I6 | local_models | `urllib` had no timeout on pull | Added 3600s pull timeout |
| I7 | tools | Provider dispatch imported modules at top level → cycle | Late imports in helpers |
| I8 | gui | MCP reload blocked the UI thread | Runs on worker thread |
| I9 | gui | Voice recording blocked the UI thread | Runs on worker thread |
| I10 | selftest | MCP registry test mutated module-level constant | Restored in finally |
| I11 | selftest | Plugin dir mutation leaked between suites | Restored in finally |
| I12 | mcp_registry | `is_valid` didn't reject both-command-and-url | Added check |
| I13 | mcp_client | Schemas had no `required` key when server omitted it | Defaults to [] |
| I14 | voice | `VoiceEngine` raised on unknown engine | Reports unavailable instead |
| I15 | local_models | `size_human` divided by zero on 0 bytes | Guarded |
