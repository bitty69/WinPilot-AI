# Changelog

## v0.8.0 — Local models + integration polish

### Added
- `local_models.py` — Ollama model management (list, pull, delete)
- **Models** dialog: browse, pull, and delete local models
- `INTEGRATION_GUIDE.md` — how to add MCP servers, voice engines, local
  backends
- `MCP_SETUP.md` — copy-paste configs for common MCP servers
- `test_provider_dispatch` — proves `execute_tool` reaches all providers

### Changed
- Status footer now shows MCP server and tool counts
- `/models` slash command opens the Models dialog

## v0.7.0 — Voice I/O

### Added
- `voice.py` — STT and TTS engine abstractions
- `FasterWhisperSTT` (faster-whisper) and `PiperTTS` (piper-tts)
- Mic button in the input row, plus `Ctrl+Space` push-to-talk
- "Speak responses" checkbox in Settings
- Voice status line in Settings showing which packages are installed
- `test_voice` — 15 checks including registry shape and graceful failure

## v0.6.0 — MCP support

### Added
- `mcp_registry.py` — load/save `~/.winpilot/mcp_servers.json`
- `mcp_client.py` — stdio and HTTP transports, tool discovery, dispatch
- MCP tools appear in `tool_schemas()` alongside built-ins and plugins
- MCP menu: Reload, List, Open config
- `Ctrl+M` reloads MCP
- `test_mcp_registry` (18 checks) and `test_mcp_client` (8 checks)

## v0.5.0 — Plugin system

See the v0.5 changelog (unchanged).

## v0.3.0 — Static-trace fixes

See `DEBUG_REPORT.md`.

## v0.2.0 — GUI

See `FIXES.md`.

## v0.1.0 — CLI

Original terminal agent.
