# WinPilot Developer Guide

Read this before editing anything. It explains the architecture, how to add
a tool, how to add an MCP server, how to add a voice engine, and how to test.

---

## 1. Mental model

Five layers, stacked. Each talks only to the layer below.

```

┌──────────────────────────────────────────────────────────┐
│  gui.py                                                  │  The window.
│  Draws widgets, forwards input to the Agent.             │
└──────────────────────┬───────────────────────────────────┘
│  Agent.run(text)
┌──────────────────────▼───────────────────────────────────┐
│  agent.py                                                │  The brain.
│  Loop: ask LLM → run tool → feed result back.            │
└───────┬────────────────────────────────┬─────────────────┘
│  llm.chat()                    │  execute_tool()
┌───────▼──────────────┐   ┌─────────────▼─────────────────┐
│  llm.py              │   │  tools.py                     │  The hands.
│  Talks to the API.   │   │  Built-in tools.              │
└──────────────────────┘   └─────────────┬─────────────────┘
│
┌────────────────────┼────────────────────┐
│                    │                    │
┌───────────▼────────┐ ┌─────────▼─────────┐ ┌────────▼────────┐
│  plugins.py        │ │  mcp_client.py    │ │  voice.py       │
│  User plugins      │ │  MCP servers      │ │  STT / TTS      │
└───────────┬────────┘ └─────────┬─────────┘ └─────────────────┘
│                    │
└──────────┬─────────┘
│
┌───────────▼───────────┐
│  paths.py             │  Safety.
│  Blocks bad paths.    │
└───────────────────────┘

Side modules:
config.py        — settings from ~/.winpilot/config.json
mcp_registry.py  — MCP server list from ~/.winpilot/mcp_servers.json
local_models.py  — Ollama management
rag.py           — document index for /ask
ui_theme.py      — colours and fonts only
selftest.py      — run before committing

```

### Provider pattern

Three things can add tools to the agent: **built-ins**, **plugins**, and
**MCP servers**. Each is a *provider*. The agent does not care which is
which — it calls `tool_schemas()` to get the list, and `execute_tool(name)`
to run one. `tools.py` dispatches:

```python
func = BUILTIN_TOOLS.get(name)
if func is None:
    func = plugins.get_plugin_tool(name)
if func is None:
    func = mcp_client.get_mcp_tool(name)
```

**Adding a new provider** (say, a remote HTTP tool service) means:

1. Write a module with `get_<provider>_tool(name)` and `get_<provider>_schemas()`.
2. Add two lines to `execute_tool` and `tool_schemas`.
3. Add a test suite.

Nothing else changes. The agent loop is provider-agnostic by design.

---

## 2. File reference

| File ↕▾ | Owns ↕▾ | Safe to edit? ↕▾ |
|---|---|---|
| −`winpilot_gui.py` | Entry point, 25 lines | Rarely |
| −`config.py` | `Config` + backend URLs | **Yes** — add backends |
| −`paths.py` | Path safety | Carefully |
| −`llm.py` | API wrapper | Rarely |
| −`tools.py` | Built-in tools + dispatch | **Yes** — add tools |
| −`plugins.py` | Plugin loader + sandbox | Carefully |
| −`mcp_client.py` | MCP connection + tools | Carefully |
| −`mcp_registry.py` | MCP server list | **Yes** — add servers |
| −`voice.py` | STT/TTS engines | **Yes** — swap engines |
| −`local_models.py` | Ollama management | **Yes** |
| −`rag.py` | Document index | Yes |
| −`agent.py` | ReAct loop | Carefully |
| −`gui.py` | Tkinter widgets | **Yes** — add UI |
| −`ui_theme.py` | Colours, fonts | **Yes** — safe to tweak |
| −`selftest.py` | Smoke tests | **Yes** — add tests |
⚙

---

## 3. Add a built-in tool (3 steps, one file)

See `tools.py`. Every tool has the same shape:

```
def my_tool(argument_one: str, cfg: Config) -> str:
    """
    One-line summary. Becomes the description the LLM sees.

    Args:
        argument_one: What it is.
        cfg: Injected automatically.

    Returns:
        A string. Start with "Error: " on failure.
    """
    root = cfg.effective_workspace()
    path = resolve_and_check(argument_one, root, must_exist=True)
    _confirm("My tool", f"About to do X to {path}", cfg)
    return f"Did the thing to {path}"
```

Register it in `BUILTIN_TOOLS` and add a schema via `_schema(...)` in
`BUILTIN_SCHEMAS`. Then add a test to `selftest.py`.

---

## 4. Add an MCP server

The user does this by editing `~/.winpilot/mcp_servers.json`:

```
{
  "servers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/path"],
      "enabled": true
    },
    "remote": {
      "url": "https://example.com/mcp",
      "enabled": true
    }
  }
}
```

Stdio servers (with `command`) are spawned as subprocesses. HTTP servers
(with `url`) are connected over streamable HTTP. Both are handled in
`mcp_client.py`.

To **code** a new MCP transport, see `MCPClient._connect_stdio` and
`MCPClient._connect_http`. Each returns a session object with
`list_tools()` and `call_tool()`.

---

## 5. Add a voice engine

`voice.py` defines two abstract classes:

```
class STTEngine:
    def transcribe(self, audio_path: Path) -> str: ...

class TTSEngine:
    def speak(self, text: str) -> None: ...
```

Two concrete implementations ship: `FasterWhisperSTT` and `PiperTTS`. To add
a new engine, subclass the abstract class and register it in `ENGINES` at the
bottom of the file. The GUI reads `voice.get_available_engines()` to populate
the Settings dropdown.

---

## 6. Add a local model backend

`local_models.py` wraps the Ollama HTTP API. To add another backend (LM Studio,
llama.cpp server), subclass `LocalModelBackend` and register it in
`BACKENDS`. See the existing `OllamaBackend` for the pattern.

---

## 7. Change the GUI

Layout is built in `gui.py::_build_layout()`, split into marked sections:

```
# ---- left: chat ----
# ---- right: tool log ----
```

| Want to... ↕▾ | Do this ↕▾ |
|---|---|
| −Change colours | Edit `ui_theme.py` only |
| −Resize window | `Config.window_geometry` default |
| −Widen tool log | `right = Frame(..., width=400)` |
| −Add a toolbar button | `bar = Frame(...)` section |
| −Add a menu item | `_build_menu()` |
| −React to agent events | `_handle_event()` — one `elif` per event |
| −Add a mic button | See `_build_input_row()` in `_build_layout` |
⚙

**The event system:** the agent runs on a worker thread and never touches
widgets. It calls `self.event_cb(kind, data)`, which pushes to a queue. The
main thread polls every 60 ms in `_poll_events()` and calls `_handle_event()`.

**Golden rule:** never touch a widget from a worker thread. Use
`self.after(0, fn)` or push to the queue.

---

## 8. Testing

```
python -m winpilot.selftest
```

Suites:

| Suite ↕▾ | Checks ↕▾ |
|---|---|
| −Imports | Every module imports |
| −Config | Round-trip, clamping, validation |
| −Paths | Escapes blocked, in-workspace allowed |
| −Chunker | Terminates on pathological input |
| −RAG | Builds, searches, saves, loads |
| −Tools registry | Every tool has schema + cfg param |
| −Tools behaviour | Real operations on a temp workspace |
| −Plugin sandbox | Forbidden imports blocked, allowed pass |
| −Plugin loading | Good plugin loads, bad plugin rejected |
| −Example plugins | All three ship-load cleanly |
| −Agent history | Pruning keeps shape valid |
| −MCP registry | Config load/save round-trips |
| −MCP client | Tool dispatch works (mocked) |
| −Voice engines | Registry is well-formed |
| −Local models | Ollama backend schema is correct |
| −Integration wiring | `execute_tool` reaches all providers |
⚙

Add a test:

```
def test_my_feature() -> list[TestResult]:
    results = []
    with temp_workspace() as (root, cfg):
        r = my_module.do_something(cfg)
        results.append(check("returns expected value", r == "ok", r))
    return results
```

Then add it to `SUITES` at the bottom of `selftest.py`.

---

## 9. Coding conventions

- One responsibility per function.
- Type hints everywhere: `def f(x: str) -> str:`
- Docstrings on public functions.
- No global mutable state except the documented callbacks.
- No bare `except:`. Catch specific exceptions or `Exception`.
- Tools return strings and never raise; `execute_tool` catches everything.
- Comments explain *why*. The code says *what*.

### Naming

- Files: `lowercase.py`
- Classes: `CamelCase`
- Functions, variables: `snake_case`
- Constants: `UPPER_SNAKE_CASE`

---

## 10. Safety lives in four places

1. `paths.py::resolve_and_check` — every filesystem tool.
2. `tools.py::_confirm` — destructive tools.
3. `plugins.py::PluginSandbox` — plugins can't reach `os`/`sys`/`socket`.
4. `mcp_registry.py` — servers are explicitly listed; no auto-discovery.

---

## 11. Common pitfalls

| Symptom ↕▾ | Cause ↕▾ | Fix ↕▾ |
|---|---|---|
| −GUI freezes | Widget touched from worker thread | `self.after(0, ...)` |
| −Tool never runs | Name mismatch with registry | Must be identical |
| −LLM ignores the tool | Vague `description` | Write a clear one-liner |
| −`TypeError: missing cfg` | Forgot `cfg: Config` | Add it |
| −Path rejected | Outside `workspace_root` | Widen root in Settings |
| −Plugin not loading | Import error | Check the tool log |
| −MCP server not connecting | Wrong command/args | Check `mcp_servers.json` |
| −Voice model missing | First use downloads it | Wait; check the log |
| −`TclError: grab failed` | `grab_set()` before mapped | `wait_visibility()` first |
⚙

---

## 12. The 60-second tour

1. `winpilot_gui.py` — 25 lines.
2. `config.py` — `BACKEND_DEFAULTS`, `Config`.
3. `agent.py` — read `run()`.
4. `tools.py` — read `list_directory`, then `execute_tool`.
5. `plugins.py` — read `PluginBase` and `load_plugins`.
6. `mcp_client.py` — read `MCPClient` and `get_mcp_tool`.
7. `gui.py` — read `_build_layout()`, then `_handle_event()`.

You now understand the program.

